package project.resources.Problem;

public class problems {
    public static String math_p1_answer = "";
    public static void setAnswer() {
        math_p1_answer = "";
    }
}
