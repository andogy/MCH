package project.resources.UI.Color;

import project.Community.Command.ini;
import project.Community.Community;
import project.Community.Events.Errors;
import project.Community.Events.LoadAssembly;
import project.Community.Times.times;
import project.resources.UI.MchUI;
import project.resources.UI.MenuUI;
import project.resources.UI.exit;

import java.awt.*;

public class colors extends Thread {
    @Override
    public void run() {
        System.out.println("[" + times.format + "]\n" + "colors:色彩就绪");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadSucceed: color\n");
        while (true) {
            if (Errors.CannotHandle) {
                break;
            }
            try {
                Color();
            } catch (NullPointerException ignored) {
            }
        }
    }

    public static void Color() {
//        使用线程休眠减少CPU负担,15ms时间可以减少相当大的CPU负载,且用户无法察觉延迟
        try {
            Thread.sleep(15);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

//        去除button边框
        MchUI.menu.setBorderPainted(false);
        MchUI.menu.setFocusPainted(false);

        exit.buttonEXIT.setBorderPainted(false);
        exit.buttonEXIT.setFocusPainted(false);
        exit.buttonEXITNot.setBorderPainted(false);
        exit.buttonEXITNot.setFocusPainted(false);

        MenuUI.randomProblem.setBorderPainted(false);
        MenuUI.randomProblem.setFocusPainted(false);
        MenuUI.White.setBorderPainted(false);
        MenuUI.White.setFocusPainted(false);
        MenuUI.Black.setBorderPainted(false);
        MenuUI.Black.setFocusPainted(false);
        MenuUI.Chinese.setBorderPainted(false);
        MenuUI.Chinese.setFocusPainted(false);
        MenuUI.English.setBorderPainted(false);
        MenuUI.English.setFocusPainted(false);
        MenuUI.exButtonExit.setBorderPainted(false);
        MenuUI.exButtonExit.setFocusPainted(false);
        MenuUI.exButtonNarrow.setBorderPainted(false);
        MenuUI.exButtonNarrow.setFocusPainted(false);
        MenuUI.fastLoadYes.setBorderPainted(false);
        MenuUI.fastLoadYes.setFocusPainted(false);
        MenuUI.fastLoadNo.setBorderPainted(false);
        MenuUI.fastLoadNo.setFocusPainted(false);
        MenuUI.onTop.setBorderPainted(false);
        MenuUI.onTop.setFocusPainted(false);
        MenuUI.noOnTop.setBorderPainted(false);
        MenuUI.noOnTop.setFocusPainted(false);

        ini.Chinese.setBorderPainted(false);
        ini.Chinese.setFocusPainted(false);
        ini.Black.setFocusPainted(false);
        ini.Black.setBorderPainted(false);
        ini.White.setFocusPainted(false);
        ini.White.setBorderPainted(false);
        ini.English.setBorderPainted(false);
        ini.English.setFocusPainted(false);
        ini.FastLoad.setBorderPainted(false);
        ini.FastLoad.setFocusPainted(false);
        ini.SafeLoad.setBorderPainted(false);
        ini.SafeLoad.setFocusPainted(false);
        ini.GoHelp.setBorderPainted(false);
        ini.GoHelp.setFocusPainted(false);
        ini.GoMchUI.setBorderPainted(false);
        ini.GoMchUI.setFocusPainted(false);

//        创建颜色
        Color Black = new Color(0, 0, 0);
        Color White = new Color(214, 214, 214);
        Color Black_Background = new Color(43, 43, 43);
        Color Black_Input = new Color(49, 51, 53);
        Color Black_Button = new Color(60, 63, 65);
        Color Black_Tip = new Color(58, 58, 58);

//        固定颜色配置界面(初始化引导)
        ini.jt.setForeground(White);
        ini.Chinese.setForeground(White);
        ini.English.setForeground(White);
        ini.Black.setForeground(White);
        ini.White.setForeground(White);
        ini.FastLoad.setForeground(White);
        ini.SafeLoad.setForeground(White);
        ini.GoMchUI.setForeground(White);
        ini.GoHelp.setForeground(White);

        ini.jf.getContentPane().setBackground(Black_Background);
        ini.jt.setBackground(Black_Background);
        ini.Chinese.setBackground(Black_Button);
        ini.English.setBackground(Black_Button);
        ini.Black.setBackground(Black_Button);
        ini.White.setBackground(Black_Button);
        ini.FastLoad.setBackground(Black_Button);
        ini.SafeLoad.setBackground(Black_Button);
        ini.GoHelp.setBackground(Black_Button);
        ini.GoMchUI.setBackground(Black_Button);

//        以下为颜色设置
//            ID=0为白色
        if (Community.ColorID == 0) {
            MchUI.jFrame.getContentPane().setBackground(Color.white);
            MenuUI.jFrame.getContentPane().setBackground(Color.white);
            exit.jFrame.getContentPane().setBackground(Color.white);

            MchUI.tips.setBackground(Color.white);
            MchUI.input_Command.setBackground(White);
            MchUI.menu.setBackground(White);
            MchUI.command1.setBackground(Color.white);

            exit.buttonEXIT.setBackground(White);
            exit.buttonEXITNot.setBackground(White);
            exit.jTextArea.setBackground(Color.white);

            MenuUI.randomProblem.setBackground(White);
            MenuUI.Black.setBackground(White);
            MenuUI.White.setBackground(Color.white);
            MenuUI.User_Color.setBackground(White);

            switch (Community.LangID) {
                case 0: {
                    MenuUI.Chinese.setBackground(Color.white);
                    MenuUI.English.setBackground(White);
                    break;
                }
                case 1: {
                    MenuUI.Chinese.setBackground(White);
                    MenuUI.English.setBackground(Color.white);
                    break;
                }
            }

            if (Community.onTop) {
                MenuUI.onTop.setBackground(Color.white);
                MenuUI.noOnTop.setBackground(White);
            } else {
                MenuUI.onTop.setBackground(White);
                MenuUI.noOnTop.setBackground(Color.white);
            }

            if (Community.exitButtonWillExit) {
                MenuUI.exButtonNarrow.setBackground(White);
                MenuUI.exButtonExit.setBackground(Color.white);
            } else {
                MenuUI.exButtonNarrow.setBackground(Color.white);
                MenuUI.exButtonExit.setBackground(White);
            }

            if (Community.fastLoad) {
                MenuUI.fastLoadYes.setBackground(Color.white);
                MenuUI.fastLoadNo.setBackground(White);
            } else {
                MenuUI.fastLoadYes.setBackground(White);
                MenuUI.fastLoadNo.setBackground(Color.white);
            }

            MchUI.tips.setForeground(Black);
            MchUI.input_Command.setForeground(Black);
            MchUI.menu.setForeground(Black);
            MchUI.command1.setForeground(Black);

            exit.buttonEXIT.setForeground(Black);
            exit.buttonEXITNot.setForeground(Black);
            exit.jTextArea.setForeground(Black);

            MenuUI.Problem.setForeground(Black);
            MenuUI.randomProblem.setForeground(Black);
            MenuUI.User_Color.setForeground(Black);
            MenuUI.White.setForeground(Black);
            MenuUI.Black.setForeground(Black);
            MenuUI.Color.setForeground(Black);
            MenuUI.PATH.setForeground(Black);
            MenuUI.Color.setForeground(Black);
            MenuUI.Language.setForeground(Black);
            MenuUI.Chinese.setForeground(Black);
            MenuUI.English.setForeground(Black);
            MenuUI.exButton.setForeground(Black);
            MenuUI.exButtonExit.setForeground(Black);
            MenuUI.exButtonNarrow.setForeground(Black);
            MenuUI.fastLoad.setForeground(Black);
            MenuUI.fastLoadNo.setForeground(Black);
            MenuUI.fastLoadYes.setForeground(Black);
            MenuUI.Ver.setForeground(Black);
            MenuUI.onTops.setForeground(Black);
            MenuUI.onTop.setForeground(Black);
            MenuUI.noOnTop.setForeground(Black);
        } else if (Community.ColorID == 1) {
//            ID=1为黑色
            MchUI.jFrame.getContentPane().setBackground(Black_Background);
            MenuUI.jFrame.getContentPane().setBackground(Black_Background);
            exit.jFrame.getContentPane().setBackground(Black_Background);

            MchUI.tips.setBackground(Black_Tip);
            MchUI.input_Command.setBackground(Black_Input);
            MchUI.menu.setBackground(Black_Button);
            MchUI.command1.setBackground(Black_Background);

            exit.buttonEXIT.setBackground(Black_Button);
            exit.buttonEXITNot.setBackground(Black_Button);
            exit.jTextArea.setBackground(Black_Background);

            MenuUI.randomProblem.setBackground(Black_Button);
            MenuUI.White.setBackground(Black_Button);
            MenuUI.User_Color.setBackground(Black_Button);
            MenuUI.Color.setBackground(Black_Button);
            MenuUI.Black.setBackground(Black_Background);
            MenuUI.White.setBackground(Black_Button);

            switch (Community.LangID) {
                case 0: {
                    MenuUI.Chinese.setBackground(Black_Background);
                    MenuUI.English.setBackground(Black_Button);
                    break;
                }
                case 1: {
                    MenuUI.Chinese.setBackground(Black_Button);
                    MenuUI.English.setBackground(Black_Background);
                    break;
                }
            }

            if (Community.onTop) {
                MenuUI.onTop.setBackground(Black_Background);
                MenuUI.noOnTop.setBackground(Black_Button);
            } else {
                MenuUI.onTop.setBackground(Black_Button);
                MenuUI.noOnTop.setBackground(Black_Background);
            }

            if (Community.exitButtonWillExit) {
                MenuUI.exButtonNarrow.setBackground(Black_Button);
                MenuUI.exButtonExit.setBackground(Black_Background);
            } else {
                MenuUI.exButtonNarrow.setBackground(Black_Background);
                MenuUI.exButtonExit.setBackground(Black_Button);
            }

            if (Community.fastLoad) {
                MenuUI.fastLoadYes.setBackground(Black_Background);
                MenuUI.fastLoadNo.setBackground(Black_Button);
            } else {
                MenuUI.fastLoadYes.setBackground(Black_Button);
                MenuUI.fastLoadNo.setBackground(Black_Background);
            }

            MchUI.tips.setForeground(White);
            MchUI.input_Command.setForeground(White);
            MchUI.menu.setForeground(White);
            MchUI.command1.setForeground(White);

            exit.buttonEXIT.setForeground(White);
            exit.buttonEXITNot.setForeground(White);
            exit.jTextArea.setForeground(White);

            MenuUI.Problem.setForeground(White);
            MenuUI.randomProblem.setForeground(White);
            MenuUI.User_Color.setForeground(White);
            MenuUI.White.setForeground(White);
            MenuUI.Black.setForeground(White);
            MenuUI.Color.setForeground(White);
            MenuUI.PATH.setForeground(White);
            MenuUI.Color.setForeground(White);
            MenuUI.Black.setForeground(White);
            MenuUI.White.setForeground(White);
            MenuUI.Language.setForeground(White);
            MenuUI.Chinese.setForeground(White);
            MenuUI.English.setForeground(White);
            MenuUI.exButton.setForeground(White);
            MenuUI.exButtonExit.setForeground(White);
            MenuUI.exButtonNarrow.setForeground(White);
            MenuUI.fastLoad.setForeground(White);
            MenuUI.fastLoadNo.setForeground(White);
            MenuUI.fastLoadYes.setForeground(White);
            MenuUI.Ver.setForeground(White);
            MenuUI.onTops.setForeground(White);
            MenuUI.onTop.setForeground(White);
            MenuUI.noOnTop.setForeground(White);
        }
    }
}