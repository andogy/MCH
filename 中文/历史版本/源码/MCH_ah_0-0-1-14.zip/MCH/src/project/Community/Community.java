package project.Community;

import project.Community.Command.ini;
import project.Community.Events.IniHas;
import project.Community.Events.LoadAssembly;
import project.Community.Events.historyReader;
import project.Community.Times.times;
import project.resources.UI.Color.colors;
import project.resources.UI.MchUI;
import project.resources.UI.exit;

public class Community {

    public static int ColorID = 0;
    public static int LangID = 0;
    public static boolean exitButtonWillExit = true;
    public static boolean fastLoad = false;
    public static boolean onTop = false;

    public static void main(String[] args) {
        new times().start();

        System.out.println("[" + times.format + "]\n" + "exit:exit事件就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: exit\n");
        new exit();

        System.out.println("[" + times.format + "]\n" + "ini:配置文件就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: ini\n");
        new ini();

        //        加载颜色
        System.out.println("[" + times.format + "]\n" + "colors:色彩就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: color\n");
        new colors().start();

        new IniHas().start();

        new historyReader().start();

        /*
        预加载部分
         */

//        显示UI
        System.out.println("[" + times.format + "]\n" + "MchUI:UI就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: MchUI\n");
        if (ini.canStartUI) {
            new MchUI().start();
        } else {
            System.out.println("[" + times.format + "]\n" + "MchUI:UI无法就绪");
            LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadFail: MchUI\n");
        }
    }
}
