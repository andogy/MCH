package project.Community.Command.Tree.gameCommand.Selector;

import project.Community.Command.Parsing;
import project.Community.Command.textLibrary.commandLibrary;
import project.Community.Community;
import project.resources.UI.Lang.language;
import project.resources.UI.MchUI;

public class selector {
    public static String tip = "";

    public static void select(String Select) {
        boolean selector = false;

//        去除空格方便进行处理
        Select = Select.replace(" ", "");
        if (Select.contains(",")) {
            tip = Select.substring(Select.lastIndexOf(",")).replace(",", "");
        } else {
            tip = Select.replace("[", "");
        }

//        将多余的符号变为一个

        if (Select.contains("[[") || Select.contains("!!") || Select.contains("]]")) {
            String slash = MchUI.input_Command.getText().replace("[[", "[").replace("!!", "!").replace("]]", "]");
            MchUI.input_Command.setText(slash);
        }

//        匹配结束选择器参数的符号
        if (!tip.contains("]")) {
//            匹配不到则进行选择器参数符号匹配
            if (tip.equals("")) {
                {
                    if (!Select.contains("x=")) {
                        Parsing.display = commandLibrary.x + language.x + "\n";
                    }
                    if (!Select.contains("y=")) {
                        Parsing.display = Parsing.display + commandLibrary.y + language.y + "\n";
                    }
                }
            } else {
                if (language.x.contains(tip)) {
                    selector = true;

                    Parsing.display = commandLibrary.x + language.x + "\n";
                } else if (tip.contains("x=")) {
                    selector = true;

                    Parsing.display = "~" + language.relative + "\nPrecise coordinates(精确坐标)";
                    if (tip.equals("x=~")) {
                        Parsing.display = "~" + language.relative;
                    } else if (tip.length() >= 3){
                        Parsing.display = "Precise coordinates(精确坐标)";
                    }
                }

                if (language.y.contains(tip)) {
                    selector = true;

                    Parsing.display = Parsing.display + commandLibrary.y + language.y + "\n";
                } else if (tip.contains("y=")) {
                    selector = true;

                    Parsing.display = "~" + language.relative + "\nPrecise coordinates(精确坐标)";
                }

                if (!selector) {
                    if (Community.LangID == 0) {
                        Parsing.display = "无法为:\"" + tip + "\"匹配到可用选择器参数 ";
                    }
                }
            }
        }
    }
}
