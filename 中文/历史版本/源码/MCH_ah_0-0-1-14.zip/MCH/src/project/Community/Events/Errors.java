package project.Community.Events;

import project.Community.Command.ini;
import project.Community.Times.times;
import project.resources.UI.MchUI;
import project.resources.UI.MenuUI;
import project.resources.UI.exit;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class Errors {
    public static JFrame jFrame = new JFrame();
    public static JTextArea jTextArea = new JTextArea();

    public static boolean CannotHandle = false;

    public static void errors(Exception e,boolean cannotHandle,String exceptionSource) {
        CannotHandle = cannotHandle;
        jFrame.setTitle("Error Now");
        jFrame.setSize(300,120);

        jFrame.add(jTextArea);

        jTextArea.setBounds(0,0,340,160);
        jTextArea.setEditable(false);

        if (CannotHandle) {

            historyReader.BreakRead = true;

            historyReader.history = null;

            exit.jFrame.setVisible(false);
            MchUI.jFrame.setVisible(false);
            MenuUI.jFrame.setVisible(false);
            ini.jf.setVisible(false);

            jFrame.setVisible(true);
        }

        System.gc();

        jFrame.setResizable(false);

        //获得屏幕大小

        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

        String er = Arrays.toString(e.getStackTrace()).replace("  "," ").replace("[","    at ").replace("]","").replace(",","\n    at ");
        if (er.substring(er.indexOf("at")).equals("at ")) {
            er = er.replace("at ","no Local");
        }

            FileWriter fr = null;
            try {
                fr = new FileWriter(ini.path + "history.txt",false);
            } catch (IOException exception) {
                exception.printStackTrace();
            }
            try {
                assert fr != null;
                fr.write("");
            } catch (IOException exception) {
                exception.printStackTrace();
            }

        System.out.println("[" + times.format + "]\n" + "Errors:出现错误");
            if (CannotHandle) {
                LoadAssembly.loadAssembly("[" + times.format + "]\n" + "Errors: try Crash the MCH\n");
            }
        System.out.println(e + "\n" + er);

        try {
            FileWriter fw = new FileWriter(ini.path + "errors.log",true);
            fw.write("[" + times.format + "]\n" + e + "\n" + er + "\nSourceAt:" + exceptionSource + "\n" +
                    "");
            fw.close();
        } catch (IOException exception) {
            exception.printStackTrace();
        }

        if (CannotHandle) {
            try {
                Thread.sleep(10000);
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
            exit.Ex();
        }
    }
}