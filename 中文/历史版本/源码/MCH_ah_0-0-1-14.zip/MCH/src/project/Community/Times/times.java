package project.Community.Times;

import java.text.SimpleDateFormat;
import java.util.Date;

public class times extends Thread{
    public static Date date = new Date();
    public static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
    public static String format = df.format(date);

    public void run() {
        while (true) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            date = new Date();
            df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");

            format = df.format(date);
        }
    }
}
