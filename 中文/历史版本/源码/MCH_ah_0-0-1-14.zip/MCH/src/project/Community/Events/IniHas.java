package project.Community.Events;

import project.Community.Command.ini;
import project.resources.UI.MenuUI;

import java.io.FileReader;

public class IniHas extends Thread {
    public void run() {
        while (true) {
            if (Errors.CannotHandle) {
                break;
            }
            try {
                Thread.sleep(50);
                ini.parsing();
                FileReader file = new FileReader(ini.path + ini.sets);
                file.close();
            } catch (Exception e) {
                MenuUI.jFrame.setVisible(false);
            }
        }
    }
}
