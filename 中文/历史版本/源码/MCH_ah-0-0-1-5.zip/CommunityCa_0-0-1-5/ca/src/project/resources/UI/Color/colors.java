package project.resources.UI.Color;

import project.Community.Community;
import project.resources.UI.CaUI;

import java.awt.*;

public class colors extends Thread{
    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            CaUI.menu.setBorderPainted(false);
            CaUI.menu.setFocusPainted(false);
            
            Color Black = new Color(0, 0, 0);
            Color White = new Color(214, 214, 214);


//            ID=0为白色
            if (Community.ColorID == 0) {
                CaUI.input_Command.setBackground(White);
                CaUI.menu.setBackground(White);
            }else if(Community.ColorID == 1){
            //简洁明了，黑色
            CaUI.input_Command.setBackgroud(Black);
            CaUi.menu.setBackgroud(Black);
            }

        }
    }
}
