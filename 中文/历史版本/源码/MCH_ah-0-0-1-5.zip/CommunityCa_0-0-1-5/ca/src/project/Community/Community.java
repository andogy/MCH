package project.Community;

import project.resources.UI.CaUI;

public class Community {

    public static int ColorID = 0;
    public static int LangID = 0;

    public static void main(String[] args) {
        /*
        预加载部分
         */

//        显示UI
        new CaUI();
    }
}