package project.Community;

import project.resources.UI.CaUI;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class EXIT {
    static boolean small = false;
    public EXIT() {
        Exit();
    }

    public static void Exit() {
        CaUI.jFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {

                if (small) {
                    CaUI.jFrame.setSize(500,300);
                    small = false;
                } else {
                    CaUI.jFrame.setSize(CaUI.jFrame.getWidth(), 0);
                    small = true;
                }

            }
        });
    }