package project.resources.UI;

import javax.swing.*;

public class MenuUI {
    public static JTextArea menu = new JTextArea();

    public MemuUI() {
        MenuUI();
    }

    public static void MenuUI() {
        JFrame jFrame = new JFrame();

        jFrame.add(menu);
    }
}
