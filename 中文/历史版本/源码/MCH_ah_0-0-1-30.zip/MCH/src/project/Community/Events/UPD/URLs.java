package project.Community.Events.UPD;

import project.Community.Community;
import project.Community.Events.Errors;
import project.Community.Events.filesOperator;
import project.Community.Times.times;
import project.Community.UI.MenuUI;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class URLs extends Thread {
    public static boolean UPD = false;
    public static boolean nowUPD = false;

    public static boolean timeOut = false;

    public static boolean checkUPD = false;
    public static OutputStream out;
    static File file = null;

    public static boolean checkUPD () {
        StringBuilder result = new StringBuilder();
        if (!Community.updFromGithub) {

            OutputStreamWriter out = null;
            BufferedReader in = null;
            HttpURLConnection conn = null;

            try {
                URL url;
                url = new URL("http://caibiwangluo.eu5.org/mch/atupdc.code");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                //发送POST请求必须设置为true
                conn.setDoOutput(true);
                conn.setDoInput(true);
                //设置连接超时时间和读取超时时间
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                //获取输出流
                out = new OutputStreamWriter(conn.getOutputStream());

                //取得输入流，并使用Reader读取
                if (200 == conn.getResponseCode()) {
                    in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } else {
                    MenuUI.checkReturn.setText("ResponseCode is an error code:" + conn.getResponseCode());
                    timeOut = true;
                    return false;
                }
            } catch (Exception e) {
                if (Community.LangID == 0) {
                    countTime.cannotUPD_connectFail();
                }
                timeOut = true;
                return false;
            } finally {
                try {
                    if (out != null) {
                        out.close();
                    }
                    if (in != null) {
                        in.close();
                    }
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }
                conn.disconnect();
            }
        } else {
            try {
                //                从Github获取下载代码需要下载代码缓存
                UPD(true);

                //                读取缓存
                BufferedReader fr = new BufferedReader(new FileReader("C:\\.MCH\\UPD.cache"));
                String s;
                while ((s = fr.readLine()) != null) {
                    result.append(s);
                }

                //                关闭流
                fr.close();

                //                删除缓存
                File file = new File("C:\\.MCH\\UPD.cache");
                File file1 = new File("C:\\.MCH\\save\\cache");
                if (Community.saveCache) {
                    filesOperator.saveCache(file, file1, "UPD");
                } else {
                    file.delete();
                }
            } catch (Exception e) {

            }
        }

        //        如果获取不到符合规格的更新代码,则返回false,拒绝下载更新包
        if (result.toString().length() < 3) {
            return false;
        }


        System.out.println(result);
        timeOut = false;
        //        如果本地ID和网络ID不一致,则有更新
        //        因为网络ID始终是最新版,本地ID除非是开发人员,不然不可能比网络ID更新
        return !result.toString().equals(Community.UPD_ID);
    }

    public static void UPD (boolean check) {
        String downloadDir = "C:\\.MCH\\";
        String fileFullName = "UPD.cache";

        try {

            String urlPath;
            if (Community.updFromGithub) {
                githubConnect.writeHosts();
                urlPath = "https://raw.githubusercontent.com/andogy/MCH/main/Public/MCH.jar";
            } else {
                urlPath = "http://caibiwangluo.eu5.org/mch/MCH.jar";
            }

            //            使用下载方式检查代码防止被github拒绝连接
            if (check) {
                urlPath = "https://raw.githubusercontent.com/andogy/MCH/main/Public/atudpc.code";
            }

            //            urlPath = "http://speed.hetzner.de/1GB.bin";

            // 统一资源
            URL url = new URL(urlPath);
            // 连接类的父类，抽象类
            URLConnection urlConnection = url.openConnection();
            // http的连接类
            HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;

            //设置超时
            httpURLConnection.setConnectTimeout(10000);

            //设置请求方式
            httpURLConnection.setRequestMethod("GET");

            // 设置字符编码
            httpURLConnection.setRequestProperty("Charset", "UTF-8");


            countTime.startDUP_count = true;

            // 打开到此 URL引用的资源的通信链接（如果尚未建立这样的连接）
            httpURLConnection.connect();

            if (countTime.startDUP_count) {

                countTime.startDUP_count = false;

                // 获取文件大小
                int fileLength = httpURLConnection.getContentLength();

                // 建立链接从请求中获取数据
                url.openConnection();
                BufferedInputStream bin = new BufferedInputStream(httpURLConnection.getInputStream());

                // 指定存放位置
                String path = downloadDir + File.separatorChar + fileFullName;
                file = new File(path);

                // 校验文件夹目录是否存在，不存在就创建一个目录
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }

                if (!check) {
                    if (Community.LangID == 0) {
                        MenuUI.checkReturn.setText("检查下载请求中");
                    } else if (Community.LangID == 1) {
                        MenuUI.checkReturn.setText("Checking Download request");
                    }
                    //                    Thread.sleep(1000);

                    if (Community.LangID == 0) {
                        MenuUI.checkReturn.setText("尝试下载中");
                    } else if (Community.LangID == 1) {
                        MenuUI.checkReturn.setText("trying Download");
                    }

                    //                    Thread.sleep(1000);
                }

                //            System.out.println(fileFullName.length());
                //            if (file.length() > 10240) {
                out = new FileOutputStream(file);
                int size = 0;
                int len = 0;
                byte[] buf = new byte[8192];
                while ((size = bin.read(buf)) != -1) {
                    //                    Thread.sleep(1);
                    len += size;
                    out.write(buf, 0, size);
                    // 控制台打印文件下载的百分比情况
                    if (!check) {
                        String download = String.valueOf((float) (len) / 1024 / 1024);
                        String downloadFilePercentage = String.valueOf((float) (len) / fileLength * 100);
                        String downloadSource = String.valueOf((float) (fileLength) / 1024 / 1024);
                        download = download.substring(0, download.substring(0, download.indexOf(".")).length() + download.substring(download.indexOf(".")).length() / 2);
                        downloadFilePercentage = downloadFilePercentage.substring(0, downloadFilePercentage.substring(0, downloadFilePercentage.indexOf(".")).length() + downloadFilePercentage.substring(downloadFilePercentage.indexOf(".")).length() / 2);
                        downloadSource = downloadSource.substring(0, downloadSource.substring(0, downloadSource.indexOf(".")).length() + downloadSource.substring(downloadSource.indexOf(".")).length() / 2);
                        if (Community.LangID == 0) {
                            MenuUI.checkReturn.setText("下载中:\n" + download + "MB / " + downloadSource + "MB\n" + downloadFilePercentage + "%");
                        } else if (Community.LangID == 1) {
                            MenuUI.checkReturn.setText("Downloading:\n" + download + "MB / " + downloadSource + "MB\n" + downloadFilePercentage + "%");
                        }
                    }
                }

                // 关闭资源
                bin.close();
                out.close();

                if (!check) {
                    //                    Thread.sleep(500);

                    if (Community.LangID == 0) {
                        MenuUI.checkReturn.setText("下载完成");
                    } else if (Community.LangID == 1) {
                        MenuUI.checkReturn.setText("Download Finished");
                    }

                    //                    Thread.sleep(500);

                    if (Community.LangID == 0) {
                        MenuUI.checkReturn.setText("尝试复制文件中");
                    } else if (Community.LangID == 1) {
                        MenuUI.checkReturn.setText("trying copy file...");
                    }

                    //                    Thread.sleep(1000);

                    try (InputStream input = new FileInputStream("C:\\.MCH\\UPD.cache"); OutputStream output = new FileOutputStream(getJar.getOldPath())) {
                        //                        Thread.sleep(1);
                        byte[] buff = new byte[128];
                        int bytesRead;
                        while ((bytesRead = input.read(buff)) > 0) {
                            output.write(buff, 0, bytesRead);

                            if (Community.LangID == 0) {
                                MenuUI.checkReturn.setText("复制了:\n" + new File(getJar.getOldPath()).length() + "Bytes/" + new File("C:\\.MCH\\UPD.cache").length() + "Bytes");
                            } else if (Community.LangID == 1) {
                                MenuUI.checkReturn.setText("copied\n" + new File(getJar.getOldPath()).length() + "Bytes/" + new File("C:\\.MCH\\UPD.cache").length() + "Bytes");
                            }
                        }
                    }

                    //                    Thread.sleep(1000);


                    File file = new File(downloadDir + fileFullName);
                    File file1 = new File("C:\\.MCH\\save\\cache");
                    if (Community.saveCache) {
                        filesOperator.saveCache(file, file1, "UPD");
                    } else {
                        file.delete();
                    }
                }

                if (!check) {
                    if (Community.LangID == 0) {
                        MenuUI.checkReturn.setText("安装中...");
                    } else if (Community.LangID == 1) {
                        MenuUI.checkReturn.setText("installing...");
                    }

                    //                    Thread.sleep(1500);

                    if (Community.LangID == 0) {
                        MenuUI.checkReturn.setText("尝试重启中...");
                    } else if (Community.LangID == 1) {
                        MenuUI.checkReturn.setText("trying restart...");
                    }

                    //                    Thread.sleep(1000);

                    Runtime.getRuntime().exec("cmd.exe /k java -Xmx100M -Xms100M -jar " + getJar.getOldPath());

                    System.exit(0);
                }
            }
        } catch (Exception e) {
            File file = new File(downloadDir + fileFullName);
            File file1 = new File("C:\\.MCH\\save\\cache");
            if (Community.saveCache) {
                filesOperator.saveCache(file, file1, "UPD");
            } else {
                file.delete();
            }
            Errors.errors(null, e, false, "UPD");
            if (Community.LangID == 0) {
                MenuUI.checkReturn.setText("更新失败:\n" + "更新行为被拒绝");
            } else if (Community.LangID == 1) {
                MenuUI.checkReturn.setText("update Fail :\n" + "access denied");
            }
        }

    }

    public void run () {
        while (true) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (checkUPD) {
                //                检查更新代码,判断是否可以更新
                UPD = checkUPD();

                countTime.startDUP_count = false;

                //                if (!timeOut) {
                String Return = "";
                if (Community.LangID == 0) {
                    if (UPD) {
                        Return = "有版本更新可以下载";
                        Community.canUPD = true;
                    } else {
                        Return = "没有可用更新";
                        Community.canUPD = false;
                    }

                    Return += "\n\n检查时间:\n" + times.format;
                } else if (Community.LangID == 1) {
                    if (UPD) {
                        Return = "Can UPD now";
                        Community.canUPD = true;
                    } else {
                        Return = "Cannot UPD now";
                        Community.canUPD = false;
                    }

                    Return += "\n\ncheck Time:\n" + times.format;
                }

                //                输出提示
                MenuUI.checkReturn.setText(Return);
                //                } else {
                //                    countTime.cannotUPD_connectFail();
                //                }

                checkUPD = false;
            }

            if (nowUPD) {
                UPD(false);
                nowUPD = false;
            }
        }
    }
}