package project.Community.UI;

import project.Community.Community;
import project.Community.Events.Errors;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Launcher {
    public static boolean mcRunning = false;

    public static JFrame jFrame = new JFrame();

    public static JLabel McBe = new JLabel();

    public static JButton turnOnMcBe = new JButton();
    public static JButton turnOffMcBe = new JButton();

    public static JTextArea McBeStatus = new JTextArea();

    public Launcher() {
        McBeStatus.setEditable(false);

        jFrame.setSize(640, 360);
        jFrame.setResizable(false);

        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        jFrame.setLocation(width / 2 - jFrame.getWidth() / 2, height / 2 - jFrame.getHeight() / 2);

        jFrame.setLayout(new LayoutManager() {
            @Override
            public void addLayoutComponent(String name, Component comp) { }
            @Override
            public void removeLayoutComponent(Component comp) { }
            @Override
            public Dimension preferredLayoutSize(Container parent) { return null; }
            @Override
            public Dimension minimumLayoutSize(Container parent) { return null; }

            @Override
            public void layoutContainer(Container parent) {
                McBe.setBounds(5,5,80,30);
                turnOnMcBe.setBounds(85,5,80,30);
                turnOffMcBe.setBounds(175,5,80,30);
                McBeStatus.setBounds(5,jFrame.getHeight() - 200,250,150);
            }
        });

        jFrame.add(McBe);
        jFrame.add(turnOnMcBe);
        jFrame.add(turnOffMcBe);
        jFrame.add(McBeStatus);

        turnOnMcBe.addActionListener(e -> {
            try {
                Runtime.getRuntime().exec("cmd.exe /k start minecraft:");
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        });

        turnOffMcBe.addActionListener(e -> {
            try {
                Runtime.getRuntime().exec("cmd.exe /k taskkill /f /im minecraft.windows.exe");
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        });

        jFrame.setVisible(true);
    }

    public static class minecraftListener extends Thread {
        @Override
        public void run() {
            Runtime r = Runtime.getRuntime();
            while (true) {
                try {
                    Process p = r.exec("cmd.exe /c tasklist");
                    BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));

                    String s = "";
                    String all = "";
                    while ((s = br.readLine()) != null) {

                        s = s.toLowerCase();

                        all += s + "\n";

                        String displayString = "";
                        displayString = "Minecraft状态\n\n";

                        if (s.contains("minecraft.windows.exe")) {
                            String s1;
                            int c = 0;
                            while (s.contains(" ")) {
                                c++;
                                s1 = s.substring(0, s.indexOf(" "));

                                s = s.substring(s.indexOf(" "));
                                while (s.substring(0, 1).contains(" ")) {
                                    s = s.replaceFirst(" ", "");
                                }

                                if (Community.LangID == 0) {
                                    switch (c) {
                                        case 1: {
                                            displayString += "软件包名: " + s1 + "\n";
                                            break;
                                        }
                                        case 2: {
                                            displayString += "PID: " + s1 + "\n";
                                            break;
                                        }
                                        case 5: {
                                            displayString += "占用内存: " + s1 + " KB\n";
                                            break;
                                        }
                                    }
                                } else {
                                    displayString = "Minecraft status\n\n";
                                    switch (c) {
                                        case 1: {
                                            displayString += "minecraft name: " + s1 + "\n";
                                            break;
                                        }
                                        case 2: {
                                            displayString += "PID: " + s1 + "\n";
                                            break;
                                        }
                                        case 5: {
                                            displayString += "minecraft ram: " + s1 + "kb\n";
                                            break;
                                        }
                                    }
                                }

                                McBeStatus.setText(displayString);

                                if (c >= 5) {
                                    break;
                                }
                            }
                        }
                    }

                    if (!all.contains("minecraft.windows.exe")) {
                        mcRunning = false;
                        if (Community.LangID == 0) {
                            McBeStatus.setText("Minecraft基岩版未在运行");
                        } else if (Community.LangID == 1) {
                            McBeStatus.setText("Minecraft Bedrock Edition is not running");
                        }
                    } else {
                        mcRunning = true;
                    }

                    System.gc();

                    Thread.sleep(100);
                    if (Errors.CannotHandle) {
                        break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
