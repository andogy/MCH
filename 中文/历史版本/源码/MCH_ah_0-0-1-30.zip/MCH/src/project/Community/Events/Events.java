package project.Community.Events;

import project.Community.Command.ini;
import project.Community.Community;
import project.Community.Events.UPD.URLs;
import project.Community.Events.UPD.countTime;
import project.Community.FunctionEditor.Editor;
import project.Community.Times.times;
import project.Community.UI.MchUI;
import project.Community.UI.MenuUI;
import project.Community.UI.MenuUI2;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class Events {
    public static void menu() {
        new MenuUI();
        new MenuUI2();
    }

    public static void Copy() {
        StringSelection selection = new StringSelection(MchUI.input_Command.getText());
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(selection, null);

        try {
            FileWriter fileWriter = new FileWriter(ini.path + "history.txt", true);
            String write = MchUI.input_Command.getText().replace("\\", "").replace("\r", "").replace("\n", "");
            if (!write.equals("")) {
                write += "\n";

                if (!Community.functionEditing) {
                    System.out.println("[" + times.format + "]\n" + "Events/Copy: 复制字符 = " + Arrays.toString(write.getBytes(StandardCharsets.UTF_8)));
                    System.out.println("Events/Copy: 复制结果 = [" + write.replace("\n", "") + "]");
                    System.out.println("Events/Copy: 复制" + write.length() + "个字符");
                    LoadAssembly.loadAssembly("[" + times.format + "]\n" + "Events/Copy: copy chars = " + Arrays.toString(write.getBytes(StandardCharsets.UTF_8)) + "\n");
                    LoadAssembly.loadAssembly("Events/Copy: copy result = [" + write.replace("\n", "") + "]\n");
                    LoadAssembly.loadAssembly("Events/Copy: copy " + write.length() + " chars");
                    fileWriter.write(write);
                } else {
                    Editor.jTextArea.setText(Editor.jTextArea.getText() + write);
                }

                fileWriter.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (OutOfMemoryError e) {
            Errors.errors(e, null, true, "Copy-DANGER");
        }
    }

    public static void switchColor(int ColorID) {
        switch (ColorID) {
            case 0: {
                Community.ColorID = 0;
                ini.colorSet = "Color@White";
                break;
            }
            case 1: {
                Community.ColorID = 1;
                ini.colorSet = "Color@Black";
                break;
            }
            case 2: {
                Community.ColorID = 2;
                ini.colorSet = "Color@Hades";
                break;
            }
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchLanguage(int LangID) {
        switch (LangID) {
            case 0: {
                Community.LangID = 0;
                ini.languageSet = "Language@Chinese";
                break;
            }
            case 1: {
                Community.LangID = 1;
                ini.languageSet = "Language@English";
                break;
            }
            case 2: {
//                繁体中文或其他语言,目前未定
                Community.LangID = 2;
                break;
            }
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchExButtonWillExit(boolean exButton) {
        if (exButton) {
            Community.exitButtonWillExit = true;
            ini.exButtonSet = "Button@Ex.Exit";
        } else {
            Community.exitButtonWillExit = false;
            ini.exButtonSet = "Button@Ex.Smaller";
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchFastLoad(boolean fastLoad) {
        if (fastLoad) {
            Community.fastLoad = true;
            ini.fastLoadSet = "Load@Fast";
        } else {
            Community.fastLoad = false;
            ini.fastLoadSet = "Load@Safe";
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchOnTop(boolean onTop) {
        if (onTop) {
            Community.onTop = true;
            ini.onTopSet = "Display@OnTop";
        } else {
            Community.onTop = false;
            ini.onTopSet = "Display@Default";
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchUpdSource(boolean Github) {
        if (Github) {
            Community.updFromGithub = true;
            ini.updSource = "Update@Github";
        } else {
            Community.updFromGithub = false;
            ini.updSource = "Update@CbNet";
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchCacheProcess(boolean save) {
        if (save) {
            Community.saveCache = true;
            ini.saveCache = "Cache@Save";
        } else {
            Community.saveCache = false;
            ini.saveCache = "Cache@Delete";
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchSaveRunLog(boolean save) {
        if (save) {
            Community.saveRunLog = true;
            ini.saveRunLog = "RunLog@Save";
        } else {
            Community.saveRunLog = false;
            ini.saveRunLog = "RunLog@Delete";
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchSaveErrorLog(boolean save) {
        if (save) {
            Community.saveErrorLog = true;
            ini.saveErrorLog = "ErrorLog@Save";
        } else {
            Community.saveErrorLog = false;
            ini.saveErrorLog = "ErrorLog@Delete";
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void checkUPD() {
        URLs.checkUPD = true;
        countTime.startDUP_count = true;
//        if (Community.LangID == 0) {
//            MenuUI.checkReturn.setText("尝试于服务器建立连接中\n" +
//                    "这个过程最多10秒");
//        }
    }

    public static void closeStreamOfUPD() {
        //        关闭更新时的流
        try {
            URLs.out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}