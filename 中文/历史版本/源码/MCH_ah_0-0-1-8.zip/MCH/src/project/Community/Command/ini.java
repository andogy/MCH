package project.Community.Command;

import project.Community.Community;
import project.Community.Events.Events;
import project.Community.Times.times;
import project.resources.UI.*;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class ini {
    public static JTextArea jt = new JTextArea();
    public static JFrame jf = new JFrame();
    public static JButton Chinese = new JButton();
    public static JButton English = new JButton();
    public static JButton Black = new JButton();
    public static JButton White = new JButton();

    public static boolean iniHas = false;

    public static String colorSet = "";
    public static String languageSet = "";

    public static boolean canStartUI = true;

    public static String sets = "settings.ini";
    public static String path = "C:\\MCH\\";

    public ini() {
        iniHas = false;
        create();
        parsing();
    }

    public static void parsing() {
        try {

            String src = path + sets;
            File ini = new File(src);

            // 构造一个BufferedReader类来读取文件
            BufferedReader br = new BufferedReader(new FileReader(ini));
            String s;

            // 使用readLine方法，一次读一行
            while ((s = br.readLine()) != null) {

                int re = s.indexOf("/*");

                if (re == -1) {
                    Reads(s);
                }
            }

            br.close();
        } catch (Exception ignored) {
        }

        System.out.println("[" + times.format + "]\n" + "ini:配置文件就绪");
    }

    public static void create() {
        try {
            FileReader fr = new FileReader(path + sets);
            try {
                fr.close();
                iniHas = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            //获得屏幕大小
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            Dimension screenSize = toolkit.getScreenSize();
            int width = screenSize.width;
            int height = screenSize.height;

            //设置窗口位置
            jf.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

            jf.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

            canStartUI = false;

            jf.setSize(500,320);

            jf.setResizable(false);

            jf.setTitle("Minecraft Commands Helper");

            jt.setText("出现这个界面可能是因为缺少配置文件\n" +
                    "这不需要你去补全任何文件,只需要照问题选择即可\n" +
                    "请选择此程序的默认语言\n\n" +
                    "This interface May Appear Due To a Lack of Configuration File\n" +
                    "This Does not Require You to Complete the File, Just Choose According to The Question\n" +
                    "Please Select the Display Language of This Program");

            Chinese.setText("中文(Chinese)");
            English.setText("英文(English)");
            Black.setText("黑色(Black)");
            White.setText("白色(White)");

            Chinese.setVisible(true);
            English.setVisible(true);

            Black.setVisible(false);
            White.setVisible(false);

            jt.setEditable(false);

            LayoutManager layoutManager = new LayoutManager() {
                @Override
                public void addLayoutComponent(String name, Component comp) { }
                @Override
                public void removeLayoutComponent(Component comp) { }
                @Override
                public Dimension preferredLayoutSize(Container parent) { return null; }
                @Override
                public Dimension minimumLayoutSize(Container parent) { return null; }

                @Override
                public void layoutContainer(Container parent) {
                    jt.setBounds(0,0,500,200);

                    Chinese.setBounds(50,200,150,30);
                    English.setBounds(50,240,150,30);
                    Black.setBounds(50,200,150,30);
                    White.setBounds(50,240,150,30);

                }
            };

            jf.setLayout(layoutManager);

            jf.setVisible(true);

            jf.add(jt);
            jf.add(Chinese);
            jf.add(English);
            jf.add(Black);
            jf.add(White);

            Chinese.addActionListener(e1 -> {
                Events.switchLanguage(0);
                setDefaultColor();
            });
            English.addActionListener(e1 -> {
                Events.switchLanguage(1);
                setDefaultColor();
            });
            Black.addActionListener(e1 -> {
                Events.switchColor(1);
                defaultIniSetOver();
            });
            White.addActionListener(e1 -> {
                Events.switchColor(0);
                defaultIniSetOver();
            });

//            Events.createNewIniFile();
        }
    }
    public static void setDefaultColor() {
        jt.setText("出现这个界面可能是因为缺少配置文件\n" +
                "这不需要你去补全任何文件,只需要照问题选择即可\n" +
                "请选择此程序的默认颜色\n\n" +
                "This interface May Appear Due To a Lack of Configuration File\n" +
                "This Does not Require You to Complete the File, Just Choose According to The Question\n" +
                "Please Select the Display Color of This Program");
        Chinese.setVisible(false);
        English.setVisible(false);

        Black.setVisible(true);
        White.setVisible(true);
    }
    public static void defaultIniSetOver() {
        System.out.println("[" + times.format + "]\n" + "MchUI:UI重新就绪中");
        if (!MchUI.jFrame.isVisible()) {
            new MchUI();
        }
        jf.setVisible(false);
        iniHas = true;
        if (MenuUI.OpenMenu) {
            new MenuUI();
        }
    }

    public static void WriteIni() throws Exception {
        FileWriter fl = new FileWriter(path + sets,false);
        fl.write(colorSet + "\n" + languageSet + "\n");
        fl.close();
    }

    public static void Reads(String s) {
        //            将大写字母全替换为小写
        s = s.replace("A", "a").replace("B", "b").replace("C", "c").replace("D", "d").replace("E", "e").replace("F", "f").replace("G", "g").replace("H", "i").replace("J", "j").replace("K", "k").replace("L", "l").replace("M", "m").replace("N", "n").replace("O", "o").replace("P", "p").replace("Q", "q").replace("R", "r").replace("S", "s").replace("T", "t").replace("U", "u").replace("V", "v").replace("W", "w").replace("X", "x").replace("Y", "y").replace("Z", "z");

        {
            int color = s.indexOf("color");
            int User_color = s.indexOf("color_config");

            if (color != 1 && User_color == -1) {
                int Black = s.indexOf("black");
                int White = s.indexOf("white");

                if (!(Black != -1 & White != -1)) {
                    if (Black != -1) {
                        Community.ColorID = 1;
                        colorSet = "Color = Black";
                    }

                    if (White != -1) {
                        Community.ColorID = 0;
                        colorSet = "Color = White";
                    }
                } else {
                    Community.ColorID = 1;
                    colorSet = "Color = White";
                }
            }
        }


        {
            int Lang = s.indexOf("language");

            if (Lang != -1) {

                int Chinese = s.indexOf("chinese");
                int English = s.indexOf("english");

                if (!(Chinese != -1 & English != -1)) {
                    if (Chinese != -1) {
                        Community.LangID = 0;
                        languageSet = "Language = Chinese";
                    }

                    if (English != -1) {
                        Community.LangID = 1;
                        languageSet = "Language = English";
                    }
                } else {
                    Community.LangID = 0;
                    languageSet = "Language = Chinese";
                }
            }
        }
    }
}
