package project.Community.Command;

import project.Community.Community;
import project.Community.Events.Events;
import project.Community.Exits;
import project.resources.UI.Lang.language;
import project.resources.UI.MchUI;
import project.resources.UI.exit;

public class Parsing extends Thread {
    public static String historyCommands;

    public static String display = "";

    public static String gamemode_Tip = "gamemode    " + language.gamemode + "\n";
    public static String gamemode = "gamemode ";
    public static String gamerule_Tip = "gamerule    " + language.gamerule + "\n";
    public static String gamerule = "gamerule ";
    public static String exit_ = ".exit";
    public static String adventure = "adventure";
    public static String creative = "creative";
    public static String defaults = "default";
    public static String survival = "survival";

    public void run() {
        parsing();
    }

    private static void parsing() {
        while (true) {
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (!Exits.small) {
                if (MchUI.jFrame.getWidth() < 500) {
                    MchUI.jFrame.setSize(500, MchUI.jFrame.getHeight());
                }
                if (MchUI.jFrame.getHeight() < 300) {
                    MchUI.jFrame.setSize(MchUI.jFrame.getWidth(), 300);
                }
            }

            if (Exits.small) {
                if (MchUI.jFrame.getHeight() > 40) {
                    Exits.small = false;
                }
            }

//          获取输入
            String str = MchUI.input_Command.getText();
            //            将大写字母全替换为小写
            str = str.replace("A", "a").replace("B", "b").replace("C", "c").replace("D", "d").replace("E", "e").replace("F", "f").replace("G", "g").replace("H", "h").replace("I", "i").replace("J", "j").replace("K", "k").replace("L", "l").replace("M", "m").replace("N", "n").replace("O", "o").replace("P", "p").replace("Q", "q").replace("R", "r").replace("S", "s").replace("T", "t").replace("U", "u").replace("V", "v").replace("W", "w").replace("X", "x").replace("Y", "y").replace("Z", "z");
//            将两个以上的空格转为一个,方便处理
            str = str.replace("  ", " ");

            if (str.equals(".exit")) {
                exit.jFrame.setSize(500, 300);
                exit.jFrame.setVisible(true);
                MchUI.input_Command.setText("");
            }

            if (str.contains("\n")) {
                Events.Copy();
                MchUI.input_Command.setText("");
            }

            if (str.contains("  ")) {
                str = str.replace("  ", " ");
                MchUI.input_Command.setText(str);
            }
            if (str.indexOf(" ") == 0) {
                str = str.substring(1);
                MchUI.input_Command.setText(str);
            }

            display = "";

            MchUI.command1.setText("");

//            用来判断是否存在命令显示的
            boolean commands = false;
            boolean child_command = false;

            boolean CanParsing = true;

            if (str.indexOf("exit") == 0) {
                if (str.contains("\t")) {
                    str = ".exit";
                    MchUI.input_Command.setText(str);
                }
                commands = true;
                display = language.guess + "\n .exit ?";
            }

//            空输入时键入tab快捷输入斜杠
            if (str.equals("\t")) {
                MchUI.input_Command.setText("/");
            } else if (str.contains("\t")) {
                str = str.replace("\t", "");
                MchUI.input_Command.setText(str);
            }

            if (str.indexOf(".") != 0 && str.contains(".")) {
                CanParsing = false;
                if (Community.LangID == 0) {
                    display = "无法找到\"" + MchUI.input_Command.getText() + "\"的相关指令或用法";
                } else if (Community.LangID == 1) {
                    display = "Cannot Find usage for \"" + MchUI.input_Command.getText() + "\"";
                }
            } else if (str.indexOf(".") == 0) {

                if (exit_.contains(str)) {
                    commands = true;
                    display = display + ".exit    " + language.exi + "\n";
                }

            }

            //            在有输入的情况下才进行提示
            if (!str.equals(""))
//            {
//                if (str.indexOf("/") != 0 && str.contains("/")) {
//                    CanParsing = false;
//                    if (Community.LangID == 0) {
//                        display = "无法找到\"" + MchUI.input_Command.getText() + "\"的相关指令或用法";
//                    } else if (Community.LangID == 1) {
//                        display = "Cannot Find usage for \"" + MchUI.input_Command.getText() + "\"";
//                    }
//                }
//                if (CanParsing) {
//                    str = str.replace("/", "");
//
////                    else {
////
////                        str = str.replace("/", "");
////
////                        if (str.length() >= 8) {
////                            if (gamemode_Tip.contains(str.substring(0, 8))) {
////
//////                            进入显示,command改为true
////                                command = true;
////
////                                if (str.contains("gamemode @")) {
////                                    display = "此处不允许使用@";
////                                } else {
////                                    if (str.contains("gamemode ")) {
////                                        boolean select = false;
////
////                                        display = "adventure" + "\n" +
////                                                "creative" + "\n" +
////                                                "default" + "\n" +
////                                                "survival" + "\n";
////
////                                        if (select) {
////                                            display = "@a  *全部玩家\n" +
////                                                    "@e  *全部实体\n" +
////                                                    "@r  *随机玩家\n" +
////                                                    "@s  *选择自己\n" +
////                                                    "@p  *最近玩家";
////                                        }
////                                    } else {
////                                        if (str.length() >= 9) {
////                                            if (!str.substring(9).equals(" ")) {
////                                                command = false;
////                                            }
////                                        }
////                                        display = display + gamemode_Tip;
////                                    }
////                                }
////                            }
////
////                            if (gamerule_Tip.contains(str)) {
//////                            进入显示,command改为true
////                                command = true;
////                                display = display + gamerule_Tip;
////                            }
////
////                        } else if (str.length() < 8) {
////
////                            if (gamemode_Tip.contains(str)) {
////
//////                            进入显示,command改为true
////                                command = true;
////
//////                            如果在gamemode后面直接使用选择器,则提示错误
////                                if (str.contains("gamemode @")) {
////                                    if (Community.LangID == 0) {
////                                        display = "此处不允许使用@";
////                                    } else if (Community.LangID == 1) {
////                                        display = "Here Cannot used the @";
////                                    }
////                                }
////
////                                if (str.contains("gamemode ")) {
////                                    boolean select = false;
////
////                                    display = "adventure\n" +
////                                            "creative\n" +
////                                            "default\n" +
////                                            "survival\n";
////
////                                    if (select) {
////                                        display = "@a  *全部玩家\n" +
////                                                "@e  *全部实体\n" +
////                                                "@r  *随机玩家\n" +
////                                                "@s  *选择自己\n" +
////                                                "@p  *最近玩家";
////                                    }
////                                } else {
////                                    display = display + gamemode_Tip;
////                                }
////                            }
////
////                            if (gamerule_Tip.contains(str)) {
////
//////                            进入显示,command改为true
////                                command = true;
////                                display = display + gamerule_Tip;
////                            }
////
////                        }
////
//////                    如果没有显示上面的,则这个指令不在库中,提示无法找到
////                        if (!command) {
////                            if (Community.LangID == 0) {
////                                display = "无法找到\"" + MchUI.input_Command.getText() + "\"的相关指令或用法";
////                            } else if (Community.LangID == 1) {
////                                display = "Cannot Find usage for \"" + MchUI.input_Command.getText() + "\"";
////                            }
////                        }
////
////                    }
////
////                }
////            } else {
////                display = historyCommands;
////            }
//
//                    {
//                        if (gamemode.contains(str)) {
//                            command = true;
//                            display = display + gamemode_Tip;
//                        }
//
//                        if (gamerule.contains(str)) {
//                            command = true;
//                            display = display + gamerule_Tip;
//                        }
//                    }
//
//                    try {
//                        if (str.substring(0, str.indexOf(" ")).equals("gamemode")) {
//                            command = true;
//                            display = "adventure    -冒险模式\n" +
//                                    "creative    -创造模式\n" +
//                                    "default    -默认模式\n" +
//                                    "survival    -生存模式";
//                            if (str.length() > str.indexOf(" ") + 1) {
//                                if (str.substring(str.indexOf(" ") + 1).equals(adventure)) {
//                                    System.out.println("@s");
//                                }
//                            }
//                            if (!str.substring(str.indexOf(" ")).equals(" ")) {
//                                try {
//                                    if (adventure.contains(str.substring(str.indexOf(" a")).replace(" ", ""))) {
//                                        child_command = true;
//                                        display = "adventure    -冒险模式";
//                                    }
//                                } catch (Exception ignored) {
//                                }
//
//                                try {
//                                    if (creative.contains(str.substring(str.indexOf(" c")).replace(" ", ""))) {
//                                        child_command = true;
//                                        display = "creative    -创造模式";
//                                    }
//                                } catch (Exception ignored) {
//                                }
//
//                                try {
//                                    if (defaults.contains(str.substring(str.indexOf(" d")).replace(" ", ""))) {
//                                        child_command = true;
//                                        display = "default    -默认模式";
//                                    }
//                                } catch (Exception ignored) {
//                                }
//
//                                try {
//                                    if (survival.contains(str.substring(str.indexOf(" s")).replace(" ", ""))) {
//                                        child_command = true;
//                                        display = "survival    -生存模式";
//                                    }
//                                } catch (Exception ignored) {
//                                }
//
//                                if (!child_command) {
//                                    if (Community.LangID == 0) {
//                                        display = "gamemode不支持输入的修饰";
//                                    } else if (Community.LangID == 1) {
//                                        display = "There are no modifiers in gamemode that match the input";
//                                    }
//                                }
//                            }
//                        }
//
//                        if (str.substring(0, str.indexOf(" ")).equals("gamerule")) {
//                            command = true;
//                            display = "主条目:游戏规则";
//                        }
//                    } catch (Exception ignored) {
//                    }
//                }
//                if (!command) {
//                    if (Community.LangID == 0) {
//                        display = "无法找到\"" + MchUI.input_Command.getText() + "\"的相关指令或用法";
//                    } else if (Community.LangID == 1) {
//                        display = "Cannot Find usage for \"" + MchUI.input_Command.getText() + "\"";
//                    }
//                }
//                child_command = false;
//                command = false;
//            }
//            显示提示
            MchUI.command1.setText(display);
        }
    }
}
