package project.Community.Events;

public class Gc extends Thread{
    public void run() {
        while (true) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.gc();
        }
    }
}
