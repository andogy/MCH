package project.Community.Help;

import project.Community.Community;
import project.Community.Events.Errors;

import java.awt.*;
import java.net.URI;

public class Helps {
    public static void Helps() {
        try {
            String url = null;
            if (Community.LangID == 0) {
                url = "http://caibiwangluo.eu5.org/mch/helps.php";
            } else if (Community.LangID == 1) {
                url = "http://caibiwanglup.eu5.org/mch/helps.php";
            }
            assert url != null;
            URI uri = URI.create(url);
            // 获取当前系统桌面扩展
            Desktop dp = Desktop.getDesktop();
            // 判断系统桌面是否支持要执行的功能
            if (dp.isSupported(Desktop.Action.BROWSE)) {
                dp.browse(uri);// 获取系统默认浏览器打开链接
            }
        } catch (Exception e) {
            Errors.errors(null,e,false,"Helps");
        }
    }
    public static void agreement() {
        String url = null;

        try {
//            if (Community.LangID == 0) {
                url = "http://caibiwangluo.eu5.org/mch/yhxy.php";
//            } else if (Community.LangID == 1) {
//                url = "http://github.com/";
//            }
            assert url != null;
            URI uri = URI.create(url);
            Desktop dp = Desktop.getDesktop();
            if (dp.isSupported(Desktop.Action.BROWSE)) {
                dp.browse(uri);
            }
        } catch (Exception e) {
            Errors.errors(null,e,false,"Helps");
        }
    }
    public static void gayhub() {
        try {
            String url = null;
            if (Community.LangID == 0) {
                url = "https://github.com/andogy/MCH/tree/main/%E4%B8%AD%E6%96%87";
            } else if (Community.LangID == 1) {
                url = "https://github.com/andogy/MCH/tree/main/English";
            }
            assert url != null;
            URI uri = URI.create(url);
            Desktop dp = Desktop.getDesktop();
            if (dp.isSupported(Desktop.Action.BROWSE)) {
                dp.browse(uri);
            }
        } catch (Exception e) {
            Errors.errors(null,e,false,"Helps");
        }
    }
}
