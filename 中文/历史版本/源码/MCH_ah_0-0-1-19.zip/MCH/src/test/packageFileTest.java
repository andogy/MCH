package test;

import java.net.URL;

public class packageFileTest {
    public static void main(String[] args) throws Exception {
        URL file = new URL("resources/az/aaa.java");

        System.out.println(file.getFile());
    }
}
