package test;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Ket extends Frame {
    public Ket() {
        addKeyListener(new KeyAdapter() {
                           public void keyPressed(KeyEvent ke) {
                               System.out.println(ke.getKeyCode());
                               if (ke.getID() == 10) {
                                   System.exit(1);
                               }


                           }
                       }
        );
    }

    public static void main(String[] args) {
        new Ket();
    }
}
