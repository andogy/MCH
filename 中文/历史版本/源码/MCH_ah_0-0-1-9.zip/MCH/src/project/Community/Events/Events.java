package project.Community.Events;

import project.Community.Command.*;
import project.Community.*;
import project.resources.UI.*;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Events {
    public static void menu() {
        new MenuUI();
    }

    public static void Copy() {
        StringSelection selection = new StringSelection(MchUI.input_Command.getText());
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(selection, null);

        try {
            FileWriter fileWriter = new FileWriter(ini.path + "history.txt", true);
            fileWriter.write(MchUI.input_Command.getText());
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void createNewIniFile() {
        File file = new File(ini.path);
        file.mkdirs();

        String iniS = "Color = White\n" +
                "Language = Chinese";

        try {
            FileWriter file1 = new FileWriter(ini.path + ini.sets);
            file1.write(iniS);
            file1.close();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    public static void switchColor(int ColorID) {
        switch (ColorID) {
            case 0: {
                Community.ColorID = 0;
                ini.colorSet = "Color@White";
                break;
            }
            case 1: {
                Community.ColorID = 1;
                ini.colorSet = "Color@Black";
                break;
            }
            case 2: {
                //        用户自定义颜色,不过暂时还没做
                Community.ColorID = 2;
                break;
            }
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchLanguage(int LangID) {
        switch (LangID) {
            case 0: {
                Community.LangID = 0;
                ini.languageSet = "Language@Chinese";
                break;
            }
            case 1: {
                Community.LangID = 1;
                ini.languageSet = "Language@English";
                break;
            }
            case 2: {
//                繁体中文或其他语言,目前未定
                Community.LangID = 2;
                break;
            }
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switchExButtonWillExit(boolean exButton) {
        if (exButton) {
            Community.exitButtonWillExit = true;
            ini.exButtonSet = "Button@Ex.Exit";
        } else {
            Community.exitButtonWillExit = false;
            ini.exButtonSet = "Button@Ex.Smaller";
        }

        try {
            ini.WriteIni();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
