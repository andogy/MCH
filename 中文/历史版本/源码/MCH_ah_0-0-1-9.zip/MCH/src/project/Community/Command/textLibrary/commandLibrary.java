package project.Community.Command.textLibrary;

public class commandLibrary {
    public static String gamemode = "gamemode ";
    public static String gamerule = "gamerule ";
    public static String adventure = "adventure";
    public static String creative = "creative";
    public static String defaults = "default";
    public static String survival = "survival";
    public static String exit_ = ".exit";
}
