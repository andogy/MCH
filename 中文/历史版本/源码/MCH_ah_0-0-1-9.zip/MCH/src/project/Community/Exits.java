package project.Community;

import project.Community.Times.times;
import project.resources.UI.MchUI;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Exits {
    public static boolean small = false;

    public static int h;
    public static int w;

    public Exits() {
        System.out.println("[" + times.format + "]\n" + "Exit:退出按钮事件就绪");
        Exit_Button();
    }

    public static void Exit_Button() {
        MchUI.jFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {

                if (Community.exitButtonWillExit) {
                    System.exit(1);
                } else {
                    if (small) {
                        MchUI.jFrame.setSize(w, h);
                        small = false;
                    } else {
                        h = MchUI.jFrame.getHeight();
                        w = MchUI.jFrame.getWidth();
                        MchUI.jFrame.setSize(MchUI.jFrame.getWidth(), 0);
                        small = true;
                    }

                }
            }
        });
    }
}