package project.Community.Command.Tree;

import project.Community.Command.Tree.Slash.slash;

public class mainCommand {
    public static void parsingCommand(String command) {
        if (command.equals("/")) {
            slash.slashEntry();
        }

        if (command.equals(".")) {

        }
    }
}
