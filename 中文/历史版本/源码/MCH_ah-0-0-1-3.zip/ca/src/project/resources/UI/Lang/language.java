package project.resources.UI.Lang;

import project.Community.Community;
import project.resources.UI.CaUI;

public class language extends Thread{
    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

//            ID=0为中文
            if (Community.LangID == 0) {
                CaUI.help.setText("帮助");
            }

        }
    }
}
