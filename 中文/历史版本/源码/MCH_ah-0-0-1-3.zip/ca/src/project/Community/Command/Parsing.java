package project.Community.Command;

import project.resources.UI.CaUI;

public class Parsing extends Thread {

    public static boolean err = false;

    public void run() {
        parsing();
    }

    private static void parsing() {
        while (true) {
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            String str = CaUI.input_Command.getText();

            boolean g;
            boolean s;

            if (str.indexOf("g") == 0 || str.indexOf("/g") == 0) {

                g = true;

                if (err) {
                    CaUI.command1.setText("未找到\"" + CaUI.input_Command.getText() + "\"指令");
                    err = false;
                }

                if (str.length() >= 1 & !err) {
                    if (str.substring(0, 1).equals("g")) {
                        if (str.length() >= 2 & !err) {
                            if (!str.substring(0, 2).equals("ga")) {
                                err = true;
                            }
                        }
                        if (str.length() >= 3 & !err) {
                            if (!str.substring(0, 3).equals("gam")) {
                                err = true;
                            }
                        }
                        if (str.length() >= 4 & !err) {
                            if (!str.substring(0, 4).equals("game")) {
                                err = true;
                            }
                        }
                        if (str.length() >= 5 & !err) {
                            if ((!str.substring(0, 5).equals("gamem")) && (!str.substring(0, 5).equals("gamer"))) {
                                err = true;
                            }
                        }
                        if (str.length() >= 6 & !err) {
                            if ((!str.substring(0, 6).equals("gamemo")) && (!str.substring(0, 6).equals("gameru"))) {
                                err = true;
                            }
                        }
                        if (str.length() >= 7 & !err) {
                            if ((!str.substring(0, 7).equals("gamemod")) && (!str.substring(0, 7).equals("gamerul"))) {
                                err = true;
                            }
                            if (str.length() >= 8 & !err) {
                                if ((!str.substring(0, 8).equals("gamemode")) && (!str.substring(0, 8).equals("gamerule"))) {
                                    err = true;
                                }
                            }
                            int gm = str.indexOf("gamem");
                            int gr = str.indexOf("gamer");

                            if (gm == -1 & !err) {
                                CaUI.command1.setText("gamerule");
                            }
                            if (gr == -1 & !err) {
                                CaUI.command1.setText("gamemode @a\ngamemode @p\ngamemode @r\ngamemode @e\ngamemode @s");
                            }
                            if (gr == -1 & gm == -1 & !err) {
                                CaUI.command1.setText("gamemode \n gamerule");
                            }
                        }
                    }
                }
            }
        }
    }
}