package project.Community.Command;

import project.resources.UI.CaUI;
import project.resources.UI.Lang.language;

public class Parsing extends Thread {

    public static boolean err = false;

    public void run() {
        parsing();
    }

    private static void parsing() {
        while (true) {
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            String str = CaUI.input_Command.getText();

            if (str.contains("  ")) {
                str = str.replace("  ", " ");
                CaUI.input_Command.setText(str);
            }
            if (str.indexOf(" ") == 0) {
                str = str.substring(1);
                CaUI.input_Command.setText(str);
            }

            String display = "";

            String gamemode = "gamemode    " + language.gamemode + "\n";
            String gamerule = "gamerule    " + language.gamerule + "\n";

            CaUI.command1.setText("");

//            将大写字母全替换为小写
            str = str.replace("A", "a").replace("B", "b").replace("C", "c").replace("D", "d").replace("E", "e").replace("F", "f").replace("G", "g").replace("H", "i").replace("J", "j").replace("K", "k").replace("L", "l").replace("M", "m").replace("N", "n").replace("O", "o").replace("P", "p").replace("Q", "q").replace("R", "r").replace("S", "s").replace("T", "t").replace("U", "u").replace("V", "v").replace("W", "w").replace("X", "x").replace("Y", "y").replace("Z", "z");

//            用来判断是否存在命令显示的
            boolean command = false;

//            在有输入的情况下才进行提示
            if (!str.equals("")) {
                if (str.equals("/")) {
                    display = gamemode + gamerule + "";
                } else {
                    str = str.replace("/", "");

                    if (str.length() >= 8) {
                        if (gamemode.contains(str.substring(0, 8))) {

//                            进入显示,command改为true
                            command = true;

                            if (str.contains("gamemode @")) {
                                display = "此处不允许使用@";
                            } else {
                                if (str.contains("gamemode ")) {
                                    boolean select = false;

                                    display = "adventure" + "\n" +
                                            "creative" + "\n" +
                                            "default" + "\n" +
                                            "survival" + "\n";

                                    if (select) {
                                        display = "@a  *全部玩家\n" +
                                                "@e  *全部实体\n" +
                                                "@r  *随机玩家\n" +
                                                "@s  *选择自己\n" +
                                                "@p  *最近玩家";
                                    }
                                } else {
                                    if (str.length() >= 9) {
                                        if (!str.substring(9).equals(" ")) {
                                            command = false;
                                        }
                                    }
                                    display = display + gamemode;
                                }
                            }
                        }

                        if (gamerule.contains(str)) {
//                            进入显示,command改为true
                            command = true;
                            display = display + gamerule;
                        }

                    } else if (str.length() < 8) {
                        if (gamemode.contains(str)) {

//                            进入显示,command改为true
                            command = true;

//                            如果在gamemode后面直接使用选择器,则提示错误
                            if (str.contains("gamemode @")) {
                                display = "此处不允许使用@";
                            }

                            if (str.contains("gamemode ")) {
                                boolean select = false;

                                display = "adventure\n" +
                                        "creative\n" +
                                        "default\n" +
                                        "survival\n";

                                if (select) {
                                    display = "@a  *全部玩家\n" +
                                            "@e  *全部实体\n" +
                                            "@r  *随机玩家\n" +
                                            "@s  *选择自己\n" +
                                            "@p  *最近玩家";
                                }
                            } else {
                                display = display + gamemode;
                            }
                        }

                        if (gamerule.contains(str)) {

//                            进入显示,command改为true
                            command = true;
                            display = display + gamerule;
                        }

                    }

//                    如果没有显示上面的,则这个指令不在库中,提示无法找到
                    if (!command) {
                        display = "无法找到\"" + CaUI.input_Command.getText() + "\"的相关指令或用法";
                    }

                }

            }
//            显示提示
            CaUI.command1.setText(display);
        }
    }
}