package project.resources.UI.Lang;

import project.Community.Community;
import project.resources.UI.CaUI;

public class language extends Thread{
    public static String gamemode = "";
    public static String gamerule = "";

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

//            ID=0为中文
            if (Community.LangID == 0) {
                CaUI.help.setText("帮助");

                gamemode = "-设定游戏模式";
                gamerule = "-设定游戏规则";
            } else if (Community.LangID == 1) {
                CaUI.help.setText("Helps");

                gamemode = "-Set gameMode";
                gamerule = "-Set gameRules";
            }

        }
    }
}
