package project.resources.UI.Color;

import project.Community.Community;
import project.resources.UI.CaUI;

import java.awt.*;

public class colors extends Thread{
    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            CaUI.help.setBorderPainted(false);
            CaUI.help.setFocusPainted(false);

            Color button_Color_White = new Color(227,227,227);

//            ID=0为白色
            if (Community.ColorID == 0) {
                CaUI.input_Command.setBackground(new Color(214, 214, 214));
                CaUI.help.setBackground(button_Color_White);
            }

        }
    }
}
