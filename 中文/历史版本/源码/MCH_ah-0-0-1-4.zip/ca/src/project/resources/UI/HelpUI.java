package project.resources.UI;

import javax.swing.*;

public class HelpUI {
    public static JTextArea help = new JTextArea();

    public HelpUI() {
        helpUI();
    }

    public static void helpUI() {
        JFrame jFrame = new JFrame();

        jFrame.add(help);
    }
}
