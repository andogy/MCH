package project.Community.Events;

import project.Community.Events.UPD.getJar;
import project.Community.UI.exit;

public class reStart {
    public static boolean restart() {
        try {
//            运行一个新的MCH
            Runtime.getRuntime().exec("cmd.exe /k java -Xmx100M -Xms100M -jar " + getJar.getOldPath());
        } catch (Exception e) {
            e.printStackTrace();
        }

//        重启
        exit.Ex();

//        如果退出不成功,返回一个布尔
        return true;
    }
}
