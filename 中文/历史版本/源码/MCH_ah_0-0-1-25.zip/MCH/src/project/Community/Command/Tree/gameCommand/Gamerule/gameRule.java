package project.Community.Command.Tree.gameCommand.Gamerule;

import project.Community.Command.Parsing;

public class gameRule {
    public static void gamerule(String rule) {
        System.out.println(rule);
        Parsing.display = rule;
    }
}
