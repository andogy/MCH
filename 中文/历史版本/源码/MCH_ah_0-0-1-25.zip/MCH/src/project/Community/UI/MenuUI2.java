package project.Community.UI;

import javax.swing.*;
import java.awt.*;

public class MenuUI2 {
    public static JFrame jFrame = new JFrame();

    public MenuUI2() {
        UI();
    }

    public static void UI() {
        Container c1 = new Container();

        c1.setLayout(layoutManagerOfC1());

        Container c2 = new Container();

        jFrame.setContentPane(c1);

        jFrame.setVisible(false);
    }

    public static LayoutManager layoutManagerOfC1() {

        return new LayoutManager() {
            @Override
            public void addLayoutComponent(String name, Component comp) { }
            @Override
            public void removeLayoutComponent(Component comp) { }
            @Override
            public Dimension preferredLayoutSize(Container parent) { return null; }
            @Override
            public Dimension minimumLayoutSize(Container parent) { return null; }

            @Override
            public void layoutContainer(Container parent) {

            }
        };
    }

}
