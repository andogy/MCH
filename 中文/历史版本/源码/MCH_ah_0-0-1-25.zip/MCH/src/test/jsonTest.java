package test;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;

public class jsonTest {
    public static void main(String[] args) {
        JSONObject pkg = new JSONObject("{'title':'test','author':'一个憨憨','description':'this is test','item':{'command':[{'/kill':{'tree':'/kill [sel]'}},{'/do':{'tree':'/do test'}}]}}");
        String bt = pkg.getString("title");//获取标题
        String des = pkg.getString("description");//获取描述
        String au = pkg.getString("author");//获取作者
        JSONObject item = pkg.getJSONObject("item");//获取项目jsonob
        JSONArray command = item.getJSONArray("command");//获取command项目（使用jsonarray是因为简易遍历性）
        System.out.println("主json:\n" + pkg + "\n\n标题: " + bt + "\n作者: " + au + "\n描述: " + des + "\n\n项目JSON: " + item + "\n\n命令JSON: " + command + "\n");//主要信息
        System.out.println("指令树:");//指令树打印
        if (command.length() > 0){
            int cl = command.length();
            int i = 0;
            for (;i<cl;i++){
                JSONObject commandtree = command.getJSONObject(i);//遍历指令
                System.out.println(commandtree);
                Iterator<String> Iterator = commandtree.keys();//检测器
                while (Iterator.hasNext()) //检测是否有下一个jsonob
                {
                    String key =  Iterator.next();//指令
                    JSONObject val = commandtree.getJSONObject(key);//tree结构
                    String value = val.getString("tree");//tree结构解析
                    System.out.println("指令: " + key + " 结构: " + value);
                }
            }
        }
    }
}
