package project.Community.Command.Tree.gameCommand.Selector;

import project.Community.Command.Parsing;
import project.Community.Community;
import project.Community.UI.Lang.language;
import project.Community.UI.MchUI;

public class selector {
    public static String tip = "";
    public static String select = "";

    public static void select(String Select) {
        if (Select.indexOf("[") != Select.lastIndexOf("[")) {
            if (Community.LangID == 0) {
                Parsing.display = "从第一个左方括号([)开始算起,在第" + (Select.lastIndexOf("[") + 1) + "位字符有重复的左方括号";
            } else if (Community.LangID == 1) {
                Parsing.display = "Start From the First Left Bracket ([),There is A Repeating Left Bracket in The" + (Select.lastIndexOf("[") + 1) + "Character";
            }
        } else {

            boolean selector = false;

//        去除空格方便进行处理
            Select = Select.replace(" ", "");

//        判断是否有未结束参数
            if (Select.contains("=,")) {
                if (Community.LangID == 0) {
                    Parsing.display = "有一个参数未结束";
                } else if (Community.LangID == 1) {
                    Parsing.display = "Have An Unfinished Parameter";
                }
            } else {
                if (Select.indexOf("\"") != Select.lastIndexOf("\"")) {
                    System.out.println(Select);
                    Select = Select.substring(0, Select.indexOf("\"")) + Select.substring(Select.lastIndexOf("\""));
                    System.out.println(Select);
                }

                if (Select.contains(",")) {
                    tip = Select.substring(Select.lastIndexOf(",")).replace(",", "");
                } else {
                    tip = Select.replace("[", "");
                }

//        将多余的符号变为一个

                if (Select.contains("[[") || Select.contains("!!") || Select.contains("]]")) {
                    String slash = MchUI.input_Command.getText().replace("[[", "[").replace("!!", "!").replace("]]", "]");
                    MchUI.input_Command.setText(slash);
                }

//        匹配结束选择器参数的符号
                if (!tip.contains("]")) {
//            匹配不到则进行选择器参数符号匹配
                    if (tip.equals("")) {
                        {
//                        匹配不存在的参数,已有的不给予提示
                            if (!Select.contains("x=")) {
                                Parsing.display = "x" + language.x + "\n";
                            }
                            if (!Select.contains("y=")) {
                                Parsing.display = Parsing.display + "y" + language.y + "\n";
                            }
                            if (!Select.contains("z=")) {
                                Parsing.display = Parsing.display + "z" + language.z + "\n";
                            }
                            if (!Select.contains("r=")) {
                                Parsing.display = Parsing.display + "r" + language.r + "\n";
                            }
                            if (!Select.contains("rm=")) {
                                Parsing.display = Parsing.display + "rm" + language.rMin + "\n";
                            }
                            if (!Select.contains("c=")) {
                                Parsing.display = Parsing.display + "c" + language.c + "\n";
                            }
                            if (!Select.contains("type")) {

                            }
                        }
                    } else {
                        if (language.x.contains(tip) || "x".contains(tip)) {
                            selector = true;

                            Parsing.display = "x" + language.x + "\n";
                        } else if (tip.contains("x=")) {
                            selector = true;

                            Parsing.display = "~" + language.relative + "\nNumber(数值)";

                            if (tip.equals("x=~")) {
                                Parsing.display = "~" + language.relative;
                            }

                            if (tip.substring(tip.indexOf("=")).length() > 1) {
                                if (!tip.substring(tip.indexOf("=") + 1).equals("~")) {
                                    notAllowType();
                                }
                            }

                            if (Select.indexOf("x=") != Select.lastIndexOf("x=")) {
                                Parsing.display = "重复的x参数";
                            }
                        }
                        if (language.y.contains(tip) || "y".contains(tip)) {
                            selector = true;

                            Parsing.display = Parsing.display + "y" + language.y + "\n";

                        } else if (tip.contains("y=")) {
                            selector = true;

                            Parsing.display = "~" + language.relative + "\nNumber(数值)";

                            if (tip.substring(tip.indexOf("=")).length() > 1) {
                                if (!tip.substring(tip.indexOf("=") + 1).equals("~")) {
                                    notAllowType();
                                }
                            }

                            if (tip.equals("y=~")) {
                                Parsing.display = "~" + language.relative;
                            }

                            if (Select.indexOf("y=") != Select.lastIndexOf("y=")) {
                                Parsing.display = "重复的y参数";
                            }
                        }
                        if (language.z.contains(tip) || "z".contains(tip)) {
                            selector = true;

                            Parsing.display = Parsing.display + "z" + language.z + "\n";

                        } else if (tip.contains("z=")) {
                            selector = true;

                            Parsing.display = "~" + language.relative + "\nNumber(数值)";

                            if (tip.substring(tip.indexOf("=")).length() > 1) {
                                if (!tip.substring(tip.indexOf("=") + 1).equals("~")) {
                                    notAllowType();
                                }
                            }

                            if (tip.equals("z=~")) {
                                Parsing.display = "~" + language.relative;
                            }

                            if (Select.indexOf("z=") != Select.lastIndexOf("z=")) {
                                Parsing.display = "重复的z参数";
                            }
                        }
                        if (language.r.contains(tip) || "r".contains(tip)) {
                            selector = true;

                            Parsing.display = "r" + language.r + "\n";
                        } else if (tip.contains("r=")) {
                            selector = true;

                            Parsing.display = "Number(数值)";

                            if (tip.substring(tip.indexOf("=")).length() > 1) {
                                notAllowType();
                            }

                            if (Select.indexOf("r=") != Select.lastIndexOf("r=")) {
                                Parsing.display = "zz";
                            }
                        }
                        if (language.rMin.contains(tip) || "rm".contains(tip)) {
                            selector = true;

                            Parsing.display = Parsing.display + "rm" + language.rMin + "\n";

                        } else if (tip.contains("rm=")) {
                            selector = true;

                            Parsing.display = "Number(数值)";

                            if (tip.substring(tip.indexOf("=")).length() > 1) {
                                notAllowType();
                            }

                            if (Select.indexOf("rm=") != Select.lastIndexOf("rm=")) {
                                Parsing.display = "重复的z参数";
                            }
                        }
                        if (language.c.contains(tip) || "c".contains(tip)) {
                            selector = true;

                            Parsing.display = Parsing.display + "c" + language.c + "\n";

                        } else if (tip.contains("c=")) {
                            selector = true;

                            Parsing.display = "Number(数值)";

                            if (tip.substring(tip.indexOf("=")).length() > 1) {
                                    notAllowType();
                            }

                            if (Select.indexOf("c=") != Select.lastIndexOf("c=")) {
                                Parsing.display = "重复的c参数";
                            }
                        }


                        if (!selector) {
                            if (Community.LangID == 0) {
                                if (tip.contains("=")) {
                                    Parsing.display = "无法为\"" + tip.substring(0,tip.indexOf("=") - 1) + "\"匹配到可用选择器";
                                } else {
                                    Parsing.display = "无法为\"" + tip + "\"匹配到可用选择器参数 ";
                                }
                            } else if (Community.LangID == 1) {
                                if (tip.contains("=")) {
                                    Parsing.display = "Cannot matching parameter for \"" + tip.substring(0,tip.indexOf("=") - 1) + "\"";
                                } else {
                                    Parsing.display = "Cannot matching parameter for \"" + tip + "\"";
                                }
                            }
                        }
                    }
                }
            }
        }
        notFinished();
        select = Select;
    }

    public static void notAllowType() {
        for (int i = tip.substring(tip.indexOf("=")).length(); i > 1; i--) {
            String c = String.valueOf(tip.charAt(i));
            if (!(c.equals("0") || c.equals("1") || c.equals("2") || c.equals("3") || c.equals("4") || c.equals("5") || c.equals("6") || c.equals("7") || c.equals("8") || c.equals("9"))) {
                System.out.println(c);
                System.out.println(i);
                if (Community.LangID == 0) {
                    Parsing.display = "不允许的类型出现在:\n" +
                            tip.substring(0, i + 1) + "←\n" +
                            tip + "\n" +
                            "\n" +
                            "第" + (Community.commandLength - tip.length() + i) + "个字符";
//                    Parsing.display = "从等于号(=)开始算起,在第" + i + "位字符出现不允许的类型 \"" + c + "\"";
                } else if (Community.LangID == 1) {
                    Parsing.display = "Type of Not Allow At Here:\n" +
                            tip.substring(0, i + 1) + "←\n" +
                            tip + "\n" +
                            "\n" +
                            "At " + (Community.commandLength - i + 2) + " Characters";
//                    Parsing.display = "Start From the Equal sign(=),Have A Type of Not Allow At" + i + "Character";
                }
            }
        }
    }

    public static void notFinished() {
        String s = select.replace("[", "");
        String notPoint = "";
        String nullPoint = "";
        String nullAt = "";
        int count = 0;
        while (true) {
            if (s.contains(",")) {
//                    System.out.println(s);

                notPoint = s.substring(0, s.indexOf(",") - 1);

                if (!notPoint.contains("=")) {
                    count++;

                    if (count > 1) {
                        nullPoint = notPoint + " , " + nullPoint;
                    } else {
                        nullPoint = notPoint;
                    }

                    if (Community.LangID == 0) {
                        Parsing.display = "有" + nullPoint + "共" + count + "个参数没有结束";
                    } else if (Community.LangID == 1) {
                        Parsing.display = "There are " + count + " parameters :" + nullPoint + " ,that have no end";
                    }
                }

                if (s.replaceFirst(",", "").contains(",")) {
                    s = s.substring(s.indexOf(",") + 1);
                } else {
                    break;
                }
            } else {
                break;
            }
        }
    }
}
