package project.Community.Help;

import project.Community.Community;
import project.Community.Events.Errors;

import java.awt.*;
import java.net.URI;

public class Helps {
    public static void Helps() {
        try {
            String url = null;
            if (Community.LangID == 0) {
                url = "C:/.MCH/Helps/cn.html";
            } else if (Community.LangID == 1) {
                url = "C:/.MCH/Helps/en.html";
            }
            assert url != null;
            URI uri = URI.create(url);
            // 获取当前系统桌面扩展
            Desktop dp = Desktop.getDesktop();
            // 判断系统桌面是否支持要执行的功能
            if (dp.isSupported(Desktop.Action.BROWSE)) {
                dp.browse(uri);// 获取系统默认浏览器打开链接
            }
        } catch (Exception e) {
            Errors.errors(null,e,false,"Helps");
        }


//        JFrame jf = new JFrame();
//        //获得屏幕大小
//        Toolkit toolkit = Toolkit.getDefaultToolkit();
//        Dimension screenSize = toolkit.getScreenSize();
//        int width = screenSize.width;
//        int height = screenSize.height;
//
//        //设置窗口位置
//        jf.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);
//
//        jf.setVisible(true);
    }
}
