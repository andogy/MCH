package test;

public class hash {
    public static void main(String[] args) {

    }
}
