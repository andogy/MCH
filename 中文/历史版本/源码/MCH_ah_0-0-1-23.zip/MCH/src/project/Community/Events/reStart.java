package project.Community.Events;

import project.Community.Events.UPD.countTime;
import project.Community.Events.UPD.getJar;

import java.io.File;
import java.io.IOException;

public class reStart {

    public static boolean restart() {
        try {
            Runtime.getRuntime().exec("cmd.exe /k java -Xmx100M -Xms100M -jar " + getJar.getOldPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (countTime.startDUP_count) {
            File file1 = new File("C:\\.MCH\\UPD.cache");
            file1.delete();
        }

        System.exit(0);

        return true;
    }
}
