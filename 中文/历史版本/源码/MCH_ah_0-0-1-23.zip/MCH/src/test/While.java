package test;

public class While {
    public static void main(String[] args) {
        int cl = 2;
        int i = 0;
        for (;i<cl;i++) {
            // az
        }
    }
}
