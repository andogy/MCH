package test;

import org.apache.commons.lang.builder.HashCodeBuilder;
import org.java_websocket.WebSocket;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.*;
import java.rmi.server.UID;
import java.util.UUID;

public class az {
    public static void main(String[] args) throws MalformedURLException {

    }
}
