package project.Community.lib;

import project.Community.UI.Lang.initLanguage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class fixResources {
    public static void fixResource(String resource, String fixTarget) {
        try {
            URL res = initLanguage.class.getResource(resource);
            BufferedReader br = new BufferedReader(new FileReader(new File(res.toURI()), StandardCharsets.UTF_8));
            String out = "";

            FileWriter writer = new FileWriter(fixTarget);

            while((out = br.readLine()) != null) {
                writer.write(out.replace("  ","").replace(" \"","\"").replace(" [","[").replace(" {","{"));
            }

            br.close();
            writer.close();
        } catch (Exception ignored) {

        }
    }
}
