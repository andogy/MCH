package project.Community.UI.randomProblem;

import javax.swing.*;

public class Problem {
    public static void problem() {
        ui();
    }

    public static void ui() {
        JFrame jFrame = new JFrame();

        jFrame.setResizable(false);
        jFrame.setVisible(true);
    }
}
