package project.Community.Command.Tree.gameCommand.Gamemode;

import project.Community.Command.Parsing;
import project.Community.Command.textLibrary.commandLibrary;
import project.Community.Community;
import project.Community.UI.MchUI;

public class gameMode {
    public static void gamemode(String childCommand) {

        if (Community.LangID == 0) {
            MchUI.tips.setText("gamemode <模式> <选择器>[选择器参数]");
        } else if (Community.LangID == 1) {
            MchUI.tips.setText("gamemode <mode> <selector>[parameter]");
        }

        Parsing.display = "adventure    -冒险模式\n" +
                "creative    -创造模式\n" +
                "default    -默认模式\n" +
                "survival    -生存模式\n";

//            无输入不进行匹配
        if (!childCommand.equals("")) {

//            留空为匹配提示做准备
            Parsing.display = "";

//            如果匹配到@则提示语法错误
            if (childCommand.equals("@")) {
                if (Community.LangID == 0) {
                    Parsing.display = "@的位置不应该在此处";
                } else if (Community.LangID == 1) {
                    Parsing.display = "There Cannot Use The @";
                }
            } else {
//                如果匹配不到@,则进行模式匹配

                if (!childCommand.contains(" ")) {

//                以下为提示匹配

//                匹配到后将此设为true,以此判断是否判断成功
                    boolean HasThisMode = false;

                    if (commandLibrary.adventure.contains(childCommand)) {
                        Parsing.display = Parsing.display + "adventure    -冒险模式\n";
                        HasThisMode = true;
                    }
                    if (commandLibrary.creative.contains(childCommand)) {
                        Parsing.display = Parsing.display + "creative    -创造模式\n";
                        HasThisMode = true;
                    }
                    if (commandLibrary.defaults.contains(childCommand)) {
                        Parsing.display = Parsing.display + "default    -默认模式\n";
                        HasThisMode = true;
                    }
                    if (commandLibrary.survival.contains(childCommand)) {
                        Parsing.display = Parsing.display + "survival    -生存模式\n";
                        HasThisMode = true;
                    }

//                如果HasThisMode为false,则匹配全都不到
                    if (!HasThisMode) {
//                如果都匹配不到,则说明此模式不在库中或不存在
                        if (Community.LangID == 0) {
                            Parsing.display = "无法为\"" + childCommand + "\"匹配到可用模式";
                        } else if (Community.LangID == 1) {
                            Parsing.display = "Cannot matching mode for \"" + childCommand + "\"";
                        }
                    }
                } else {

                    //                以下为全匹配

                    //                匹配到后将此设为true,以此判断是否判断成功
                    boolean HasThisMode = false;

                    String AtString = "";

                    if (childCommand.contains(" ")) {
                        AtString = childCommand.substring(childCommand.indexOf(" ")).replaceFirst(" ", "");
                        childCommand = childCommand.substring(0,childCommand.indexOf(" ") + 1);
                    }

                    if (childCommand.equals(commandLibrary.adventure)) {
                        gamemodeAt.gamemode_at(AtString);
                        HasThisMode = true;
                    }
                    if (childCommand.equals(commandLibrary.creative)) {
                        gamemodeAt.gamemode_at(AtString);
                        HasThisMode = true;
                    }
                    if (childCommand.equals(commandLibrary.defaults)) {
                        gamemodeAt.gamemode_at(AtString);
                        HasThisMode = true;
                    }
                    if (childCommand.equals(commandLibrary.survival)) {
                        gamemodeAt.gamemode_at(AtString);
                        HasThisMode = true;
                    }

                    //                如果HasThisMode为false,则匹配全都不到
                    if (!HasThisMode) {
//                如果都匹配不到,则说明此模式不在库中或不存在
                        if (Community.LangID == 0) {
                            Parsing.display = "无法为\"" + childCommand + "\"<a>匹配到可用模式</a>";
                        } else if (Community.LangID == 1) {
                            Parsing.display = "Cannot matching mode for \"" + childCommand + "\"";
                        }
                    }
                }
            }
        }
    }
}
