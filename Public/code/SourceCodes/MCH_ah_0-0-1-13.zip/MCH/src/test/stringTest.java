package test;

import java.util.Arrays;

public class stringTest {
    public static void main(String[] args) {
        String[] strings = new String[128];

        System.out.println(Arrays.toString(strings).replace(",","\n"));
    }
}