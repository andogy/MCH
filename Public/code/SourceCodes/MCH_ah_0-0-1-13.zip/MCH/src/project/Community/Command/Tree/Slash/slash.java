package project.Community.Command.Tree.Slash;

import project.Community.Command.Parsing;
import project.Community.Command.textLibrary.commandLibrary;
import project.resources.UI.Lang.language;

public class slash {
    public static void slashEntry() {
        Parsing.display = commandLibrary.gamemode + language.gamemode + commandLibrary.gamerule + language.gamerule + commandLibrary.give + language.give;
    }
}
