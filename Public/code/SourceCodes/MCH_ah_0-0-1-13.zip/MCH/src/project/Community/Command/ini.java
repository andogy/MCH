package project.Community.Command;

import project.Community.Community;
import project.Community.Events.Events;
import project.Community.Events.LoadAssembly;
import project.Community.Times.times;
import project.resources.UI.MchUI;
import project.resources.UI.MenuUI;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class ini {
    public static JTextArea jt = new JTextArea();
    public static JFrame jf = new JFrame();
    public static JButton Chinese = new JButton();
    public static JButton English = new JButton();
    public static JButton Black = new JButton();
    public static JButton White = new JButton();

    public static boolean iniHas = false;

    public static String colorSet = "";
    public static String languageSet = "";
    public static String exButtonSet = "";
    public static String fastLoadSet = "";

    public static boolean canStartUI = true;

    public static String sets = "settings.ini";
    public static String path = "C:\\.MCH\\";

    public ini() {
        //获得屏幕大小
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jf.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

        System.out.println("[" + times.format + "]\n" + "ini:配置文件就绪");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadSucceed: ini\n");
//        while (true) {
//                if (Errors.CannotHandle) {
//                    break;
//                }
                try {
                    Thread.sleep(20);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                iniHas = false;
                create();
                parsing();
//        }
    }

    public static void parsing() {
        try {

            String src = path + sets;
            File ini = new File(src);

            // 构造一个BufferedReader类来读取文件
            BufferedReader br = new BufferedReader(new FileReader(ini));
            String s;

            // 使用readLine方法，一次读一行
            while ((s = br.readLine()) != null) {

                int re = s.indexOf("/*");

                if (re == -1) {
                    Reads(s);
                }
            }

            br.close();
        } catch (Exception ignored) {
        }
    }

    public static void create() {
        try {
            FileReader fr = new FileReader(path + sets);
            try {
                fr.close();
                iniHas = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            File f = new File(path);
            f.mkdirs();

            jf.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

            canStartUI = false;

            jf.setSize(500,320);

            jf.setResizable(false);

            jf.setTitle("Minecraft Commands Helper");

            jt.setText("出现这个界面可能是因为缺少配置文件\n" +
                    "这不需要你去补全任何文件,只需要照问题选择即可\n" +
                    "请选择此程序的默认语言\n\n" +
                    "This interface May Appear Due To a Lack of Configuration File\n" +
                    "This Does not Require You to Complete the File, Just Choose According to The Question\n" +
                    "Please Select the Display Language of This Program");

            Chinese.setText("中文(Chinese)");
            English.setText("英文(English)");
            Black.setText("黑色(Black)");
            White.setText("白色(White)");

            Chinese.setVisible(true);
            English.setVisible(true);

            Black.setVisible(false);
            White.setVisible(false);

            jt.setEditable(false);

            LayoutManager layoutManager = new LayoutManager() {
                @Override
                public void addLayoutComponent(String name, Component comp) { }
                @Override
                public void removeLayoutComponent(Component comp) { }
                @Override
                public Dimension preferredLayoutSize(Container parent) { return null; }
                @Override
                public Dimension minimumLayoutSize(Container parent) { return null; }

                @Override
                public void layoutContainer(Container parent) {
                    jt.setBounds(0,0,500,200);

                    Chinese.setBounds(50,200,150,30);
                    English.setBounds(50,240,150,30);
                    Black.setBounds(50,200,150,30);
                    White.setBounds(50,240,150,30);

                }
            };

            jf.setLayout(layoutManager);

            jf.setVisible(true);

            jf.add(jt);
            jf.add(Chinese);
            jf.add(English);
            jf.add(Black);
            jf.add(White);

            Chinese.addActionListener(e1 -> {
                Events.switchLanguage(0);
                setDefaultColor();
            });
            English.addActionListener(e1 -> {
                Events.switchLanguage(1);
                setDefaultColor();
            });
            Black.addActionListener(e1 -> {
                Events.switchColor(1);
                defaultIniSetOver();
            });
            White.addActionListener(e1 -> {
                Events.switchColor(0);
                defaultIniSetOver();
            });

        }
    }
    public static void setDefaultColor() {
        jt.setText("出现这个界面可能是因为缺少配置文件\n" +
                "这不需要你去补全任何文件,只需要照问题选择即可\n" +
                "请选择此程序的默认颜色\n\n" +
                "This interface May Appear Due To a Lack of Configuration File\n" +
                "This Does not Require You to Complete the File, Just Choose According to The Question\n" +
                "Please Select the Display Color of This Program");
        Chinese.setVisible(false);
        English.setVisible(false);

        Black.setVisible(true);
        White.setVisible(true);
    }
    public static void defaultIniSetOver() {
        System.out.println("[" + times.format + "]\n" + "MchUI:UI重新就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: MchUI\n");
        if (!MchUI.jFrame.isVisible()) {
            new MchUI().start();
        }
        jf.setVisible(false);
        iniHas = true;
        if (MenuUI.OpenMenu) {
            new MenuUI();
        }
    }

    public static void WriteIni() throws Exception {
        FileWriter fl = new FileWriter(path + sets,false);
        fl.write(colorSet + "\n" + languageSet + "\n" + exButtonSet + "\n" + fastLoadSet);
        fl.close();
    }

    public static void Reads(String s) {
        //            将大写字母全替换为小写
        s = s.replace("A", "a").replace("B", "b").replace("C", "c").replace("D", "d").replace("E", "e").replace("F", "f").replace("G", "g").replace("H", "i").replace("J", "j").replace("K", "k").replace("L", "l").replace("M", "m").replace("N", "n").replace("O", "o").replace("P", "p").replace("Q", "q").replace("R", "r").replace("S", "s").replace("T", "t").replace("U", "u").replace("V", "v").replace("W", "w").replace("X", "x").replace("Y", "y").replace("Z", "z");

        {
            int User_color = s.indexOf("color@config");

                int Black = s.indexOf("color@black");
                int White = s.indexOf("color@white");

                if (!(Black != -1 & White != -1)) {
                    if (Black != -1) {
                        Community.ColorID = 1;
                        colorSet = "Color@Black";
                    }

                    if (White != -1) {
                        Community.ColorID = 0;
                        colorSet = "Color@White";
                    }
                } else {
                    Community.ColorID = 1;
                    colorSet = "Color@White";
                }
        }


        {
                int Chinese = s.indexOf("language@chinese");
                int English = s.indexOf("language@english");

                if (!(Chinese != -1 & English != -1)) {
                    if (Chinese != -1) {
                        Community.LangID = 0;
                        languageSet = "Language@Chinese";
                    }

                    if (English != -1) {
                        Community.LangID = 1;
                        languageSet = "Language@English";
                    }
                } else {
                    Community.LangID = 0;
                    languageSet = "Language@Chinese";
                }
        }

        {
            int exit = s.indexOf("button@ex.exit");
            int exitNot = s.indexOf("button@ex.smaller");

            if (!(exit != -1 & exitNot != -1)) {
                if (exit != -1) {
                    Community.exitButtonWillExit = true;
                    exButtonSet = "Button@Ex.Exit";
                }
                if (exitNot != -1) {
                    Community.exitButtonWillExit = false;
                    exButtonSet = "Button@Ex.Smaller";
                }
            }
        }

        {
            int fast = s.indexOf("load@fast");
            int safe = s.indexOf("load@safe");

            if (!(fast != -1 & safe != -1)) {
                if (fast != -1) {
                    Community.fastLoad = true;
                    fastLoadSet = "Load@Fast";
                }
                if (safe != -1) {
                    Community.fastLoad = false;
                    fastLoadSet = "Load@Safe";
                }
            }
        }
    }
}
