package test;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.HashMap;
import java.util.Iterator;

public class json {
    /*
     本解析系统制作者:警告！本系统为无限嵌套解析器，如修改任何一参数，本系统将会全体报废！请勿随意更改参数！！
     */
    public static void main (String[] args) throws JSONException {
        String pkg_text = "{'title':'test','author':'一个憨憨','description':'this is test','item':{'command':[{'/kill':{'tree':'/kill [sel]'}},{'/gamemode':[{'tree':'/gamemode [sel] [mode]'},{'tree':'/gamemode [mode]'}]}]}}";
        JSONObject pkg = new JSONObject(pkg_text.replace("'", "\""));
        String bt = pkg.getString("title");//获取标题
        String des = pkg.getString("description");//获取描述
        String au = pkg.getString("author");//获取作者
        HashMap<Integer, String> value_map = new HashMap<Integer, String>();//哈市马屁
        value_map.clear();//刷新哈市马屁
        JSONObject item = pkg.getJSONObject("item");//获取项目jsonob
        JSONArray command = item.getJSONArray("command");//获取command项目（使用jsonarray是因为简易遍历性）
        System.out.println("主json:\n" + pkg + "\n\n标题: " + bt + "\n作者: " + au + "\n描述: " + des + "\n\n项目JSON: " + item + "\n\n命令JSON: " + command + "\n");//主要信息
        System.out.println("指令树:");//指令树打印
        if (command.length() > 0) {
            int cl = command.length();
            int i = 0;
            for (; i < cl; i++) {
                try {
                    JSONObject commandtree = command.getJSONObject(i);//遍历指令
                    System.out.println(commandtree);
                    Iterator<String> Iterator = commandtree.keys();//检测器
                    while (Iterator.hasNext()) //检测是否有下一个json阿伟
                    {
                        String key = Iterator.next();//指令
                        String val = commandtree.getString(key);//tree结构
                        Object jsonTn = new JSONTokener(val).nextValue();//解析json类型
                        if (jsonTn instanceof JSONObject) {//jsonob解析
                            value_map.put(1, "jsonob");//注入value map
                            JSONObject a = new JSONObject(val);//动态解析为jsonob
                            String b = a.getString("tree");
                        } else if (jsonTn instanceof JSONArray) {//json阿伟解析
                            value_map.put(1, "jsonarray");//注入value map
                            JSONArray a = new JSONArray(val);//动态解析为json阿伟
                            int b = a.length();
                            if (b > 0) {//再度进行遍历解析
                                for (int c = 0; c < b; c++) {
                                    JSONObject d = a.getJSONObject(c);//遍历tree结构
                                    Iterator<String> e = d.keys();//检测器
                                    System.out.println(e.hasNext());
                                }
                            }
                        }
                        System.out.println("指令: " + key + " 结构: " + val + " 结构拆分: " + null + " 类型解析: " + value_map.get(1) + "\n");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
