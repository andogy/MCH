package project.Community.UI;

import project.Community.Command.ini;
import project.Community.Community;
import project.Community.Events.Events;
import project.Community.Events.LoadAssembly;
import project.Community.Events.UPD.URLs;
import project.Community.Events.filesOperator;
import project.Community.Events.reStart;
import project.Community.Help.Helps;
import project.Community.Times.times;
import project.Community.UI.Color.colors;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class MenuUI {
    public static JLabel PATH = new JLabel();
    public static JFrame jFrame = new JFrame();

    public static boolean OpenMenu = false;
//    public static boolean OpeningMenu = false;

    public static JLabel mchDirSize = new JLabel();

    public static JLabel Color = new JLabel();
    public static JButton Black = new JButton();
    public static JButton White = new JButton();
    public static JButton Hades = new JButton();
    public static JButton User_Color = new JButton();
    public static JButton feedback = new JButton();

    public static JLabel exButton = new JLabel();
    public static JButton exButtonExit = new JButton();
    public static JButton exButtonNarrow = new JButton();

    public static JLabel Problem = new JLabel();
    public static JButton randomProblem = new JButton();

    public static JLabel Language = new JLabel();
    public static JButton Chinese = new JButton();
    public static JButton English = new JButton();

    public static JLabel fastLoad = new JLabel();
    public static JButton fastLoadYes = new JButton();
    public static JButton fastLoadNo = new JButton();

    public static JLabel onTops = new JLabel();
    public static JButton onTop = new JButton();
    public static JButton noOnTop = new JButton();

    public static JButton deleteData = new JButton();

    public static JButton helps = new JButton();
    public static JButton user = new JButton();
    public static JButton gayhub = new JButton("Github");

    public static JButton checkUPD = new JButton();
    public static JTextArea checkReturn = new JTextArea();

    public static JButton launcher = new JButton();

    public static JButton restart = new JButton();

    public static JButton ADVANCED = new JButton();

    public static JLabel Ver = new JLabel();

    public MenuUI() {
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "MenuUI:Read ini\n");
        OpenMenu = true;
        menuUI();
    }

    public static void menuUI() {
        ini.parsing();

        if (ini.iniHas) {

            OpenMenu = false;

            jFrame.setSize(640, 360);
            jFrame.setResizable(false);

            //        窗口初始化设置
            //获得屏幕大小
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            Dimension screenSize = toolkit.getScreenSize();
            int width = screenSize.width;
            int height = screenSize.height;

            //设置窗口位置
            jFrame.setLocation(width / 2 - jFrame.getWidth() / 2, height / 2 - jFrame.getHeight() / 2);

            jFrame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

            //显示窗口
            jFrame.setVisible(true);

            Hades.setVisible(false);

            checkReturn.setEditable(false);

            LayoutManager layoutManager = new LayoutManager() {
                @Override
                public void addLayoutComponent(String name, Component comp) {
                }

                @Override
                public void removeLayoutComponent(Component comp) {
                }

                @Override
                public Dimension preferredLayoutSize(Container parent) {
                    return null;
                }

                @Override
                public Dimension minimumLayoutSize(Container parent) {
                    return null;
                }

                @Override
                public void layoutContainer(Container parent) {
                    PATH.setBounds(0, 0, 150, 30);
                    Ver.setBounds(160, 0, 150, 30);
                    mchDirSize.setBounds(320,0,300,30);

                    Color.setBounds(0, 35, 40, 30);
                    Black.setBounds(60, 35, 80, 30);
                    White.setBounds(60 + 80 + 10, 35, 80, 30);
                    Hades.setBounds(60 + 80 + 80 + 10 + 10, 35, 80, 30);

                    fastLoad.setBounds(350, 35, 60, 30);
                    fastLoadYes.setBounds(360 + 60 + 10, 35, 80, 30);
                    fastLoadNo.setBounds(360 + 60 + 10 + 80 + 10, 35, 80, 30);

                    onTops.setBounds(350, 35 + 40, 60, 30);
                    onTop.setBounds(360 + 60 + 10, 35 + 40, 80, 30);
                    noOnTop.setBounds(360 + 60 + 10 + 80 + 10, 35 + 40, 80, 30);

                    Language.setBounds(0, 40 + 35, 60, 30);
                    Chinese.setBounds(60, 35 + 40, 80, 30);
                    English.setBounds(60 + 80 + 10, 35 + 40, 80, 30);

                    exButton.setBounds(0, 40 + 35 + 30, 200, 30);
                    exButtonExit.setBounds(0, 40 + 35 + 30 + 30, 100, 30);
                    exButtonNarrow.setBounds(100 + 10, 40 + 35 + 30 + 30, 100, 30);

                    Problem.setBounds(0, 40 + 35 + 100, 110, 30);
                    randomProblem.setBounds(0, 40 + 35 + 100 + 30, 80, 30);

                    deleteData.setBounds(0, 40 + 35 + 100 + 30 + 40, 110, 30);

                    restart.setBounds(0, 40 + 35 + 100 + 30 + 40 + 30 + 10, 110, 30);

                    helps.setBounds(120, 40 + 35 + 100 + 30 + 40, 80, 30);

                    user.setBounds(210, 40 + 35 + 100 + 30 + 40, 100, 30);

                    launcher.setBounds(320,245,90,30);

                    feedback.setBounds(320,285,90,30);

                    ADVANCED.setBounds(210, 40 + 35 + 100 + 30 + 40 + 30 + 10, 100, 30);

                    gayhub.setBounds(120, 40 + 35 + 100 + 30 + 40 + 30 + 10, 80, 30);

                    checkUPD.setBounds(420, 40 + 100 + 30, 100, 30);
                    checkReturn.setBounds(420, 40 + 110 + 30 + 30, 220, 135);
                }
            };

            jFrame.setLayout(layoutManager);

            jFrame.add(PATH);
            jFrame.add(Ver);
            jFrame.add(Problem);
            jFrame.add(randomProblem);
            jFrame.add(Color);
            jFrame.add(Black);
            jFrame.add(White);
            jFrame.add(Hades);
            jFrame.add(Language);
            jFrame.add(Chinese);
            jFrame.add(English);
            jFrame.add(exButton);
            jFrame.add(exButtonExit);
            jFrame.add(exButtonNarrow);
            jFrame.add(fastLoad);
            jFrame.add(fastLoadYes);
            jFrame.add(fastLoadNo);
            jFrame.add(onTops);
            jFrame.add(onTop);
            jFrame.add(noOnTop);
            jFrame.add(deleteData);
            jFrame.add(helps);
            jFrame.add(user);
            jFrame.add(gayhub);
            jFrame.add(checkUPD);
            jFrame.add(checkReturn);
            jFrame.add(restart);
            jFrame.add(ADVANCED);
            jFrame.add(mchDirSize);
            jFrame.add(launcher);
            jFrame.add(feedback);

            Hades.addActionListener(e -> {
                Events.switchColor(2);

                colors.hadesColor();
            });
            Black.addActionListener(e -> Events.switchColor(1));
            White.addActionListener(e -> Events.switchColor(0));

            Chinese.addActionListener(e -> Events.switchLanguage(0));
            English.addActionListener(e -> Events.switchLanguage(1));

            exButtonNarrow.addActionListener(e -> Events.switchExButtonWillExit(false));
            exButtonExit.addActionListener(e -> Events.switchExButtonWillExit(true));

            fastLoadYes.addActionListener(e -> Events.switchFastLoad(true));
            fastLoadNo.addActionListener(e -> Events.switchFastLoad(false));

            onTop.addActionListener(e -> Events.switchOnTop(true));
            noOnTop.addActionListener(e -> Events.switchOnTop(false));

            deleteData.addActionListener(e -> {
                File runLog = new File(ini.path + "run.log");
                runLog.delete();

                File[] caches = new File(ini.path).listFiles();

                filesOperator.DeleteFiles(caches);
            });

            helps.addActionListener(e -> Helps.Helps());
            user.addActionListener(e -> Helps.agreement());
            gayhub.addActionListener(e -> Helps.gayhub());
            checkUPD.addActionListener(e -> {
                if (Community.canUPD) {
                    URLs.nowUPD = true;
                } else {
                    Events.checkUPD();
                }
            });
            restart.addActionListener(e -> reStart.restart());

            ADVANCED.addActionListener(e -> MenuUI2.jFrame.setVisible(true));

            launcher.addActionListener(e -> new Launcher());

            feedback.addActionListener(e -> Helps.feedback());
        }

        System.gc();
    }
}