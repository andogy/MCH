package project.Community.UI;

import project.Community.Events.Events;

import javax.swing.*;
import java.awt.*;

public class MenuUI2 {
    public static JFrame jFrame = new JFrame();
    public static JPanel c1 = new JPanel();

    public static JLabel saveCacheOrNot = new JLabel();
    public static JButton saveCache = new JButton();
    public static JButton notSaveCache = new JButton();

    public static JLabel saveErrorLogsOrNot = new JLabel();
    public static JButton saveErrorLogs = new JButton();
    public static JButton notSaveErrorLogs = new JButton();

    public static JLabel saveRunLogsOrNot = new JLabel();
    public static JButton saveRunLogs = new JButton();
    public static JButton notSaveRunLogs = new JButton();

    public static JLabel autoUpdOrNot = new JLabel();
    public static JButton autoUPD = new JButton();
    public static JButton noAutoUPD = new JButton();

    public static JLabel saveHistoryOrNot = new JLabel();
    public static JButton saveHistory = new JButton();
    public static JButton saveAllHistory = new JButton();
    public static JButton notSaveHistory = new JButton();

    static Container c2 = new Container();

    public MenuUI2 () {
        UI();
    }

    public static void UI () {

        jFrame.setSize(650, 350);

        //        窗口初始化设置
        //获得屏幕大小
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jFrame.setLocation(width / 2 - jFrame.getWidth() / 2, height / 2 - jFrame.getHeight() / 2);

        jFrame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        jFrame.setResizable(false);

        {

            c1.add(saveCacheOrNot);
            c1.add(saveCache);
            c1.add(notSaveCache);

            c1.add(saveErrorLogsOrNot);
            c1.add(saveErrorLogs);
            c1.add(notSaveErrorLogs);

            c1.add(saveRunLogsOrNot);
            c1.add(saveRunLogs);
            c1.add(notSaveRunLogs);

            c1.add(autoUpdOrNot);
            c1.add(autoUPD);
            c1.add(noAutoUPD);

            c1.add(saveHistoryOrNot);
            c1.add(saveAllHistory);
            c1.add(saveHistory);
            c1.add(notSaveHistory);

            c1.setLayout(new LayoutManager() {
                @Override
                public void addLayoutComponent (String name, Component comp) {
                }

                @Override
                public void removeLayoutComponent (Component comp) {
                }

                @Override
                public Dimension preferredLayoutSize (Container parent) {
                    return null;
                }

                @Override
                public Dimension minimumLayoutSize (Container parent) {
                    return null;
                }

                @Override
                public void layoutContainer (Container parent) {
                    saveCacheOrNot.setBounds(0, 5, 80, 30);

                    saveCache.setBounds(80, 5, 80, 30);
                    notSaveCache.setBounds(170, 5, 80, 30);

                    saveErrorLogsOrNot.setBounds(0, 45, 80, 30);

                    saveErrorLogs.setBounds(80, 45, 80, 30);
                    notSaveErrorLogs.setBounds(170, 45, 80, 30);

                    saveRunLogsOrNot.setBounds(0, 85, 80, 30);

                    saveRunLogs.setBounds(80, 85, 80, 30);
                    notSaveRunLogs.setBounds(170, 85, 80, 30);

                    autoUpdOrNot.setBounds(0,125,80,30);
                    autoUPD.setBounds(80,125,80,30);
                    noAutoUPD.setBounds(170,125,80,30);

                    saveHistoryOrNot.setBounds(270,5,80,30);
                    saveAllHistory.setBounds(340,5,80,30);
                    saveHistory.setBounds(430,5,100,30);
                    notSaveHistory.setBounds(540,5,80,30);
                }
            });

            saveCache.addActionListener(e -> Events.switchSaveUpdCache(true));
            notSaveCache.addActionListener(e -> Events.switchSaveUpdCache(false));

            saveErrorLogs.addActionListener(e -> Events.switchSaveErrorLog(true));
            notSaveErrorLogs.addActionListener(e -> Events.switchSaveErrorLog(false));

            saveRunLogs.addActionListener(e -> Events.switchSaveRunLog(true));
            notSaveRunLogs.addActionListener(e -> Events.switchSaveRunLog(false));

            autoUPD.addActionListener(e -> Events.switchAutoUPD(true));
            noAutoUPD.addActionListener(e -> Events.switchAutoUPD(false));

            saveAllHistory.addActionListener(e -> Events.switchHistorySaveID(0));
            saveHistory.addActionListener(e -> Events.switchHistorySaveID(1));
            notSaveHistory.addActionListener(e -> Events.switchHistorySaveID(2));
        }


        jFrame.setContentPane(c1);

        jFrame.setVisible(false);
    }
}
