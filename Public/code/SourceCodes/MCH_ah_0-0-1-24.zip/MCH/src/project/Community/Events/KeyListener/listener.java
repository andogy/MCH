package project.Community.Events.KeyListener;

import project.Community.Community;
import project.Community.Events.Errors;
import project.Community.Events.Events;
import project.Community.Events.UPD.URLs;
import project.Community.Events.reStart;
import project.Community.Help.Helps;
import project.Community.UI.MchUI;
import project.Community.UI.exit;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class listener extends Thread {
    public void run() {
        new inputs();
        new ex();
        new mainFrame();
    }

}

class inputs {
    public static String readingHistory = "";
    public static Set<Integer> c = new HashSet<>();

    public inputs() {
        try {
            MchUI.input_Command.addKeyListener(new KeyListener() {

                @Override
                public void keyTyped(KeyEvent e) {

                }

                @Override
                public void keyPressed(KeyEvent e) {
                    try {
                        getC().add(e.getKeyCode());
                        if (getC().size() > 1) {
//                        System.out.println(c);
                            String s = Arrays.toString(getC().toArray()).replace("[","|").replace("]","|").replace(",","|").replace(" ","");
                            System.out.println(s);

                            if ((s.contains("|18|") & s.contains("|47|")) || (s.contains("|17|") & s.contains("|47|"))) {
                                if (MchUI.input_Command.getText().equals("")) {
                                    MchUI.input_Command.setText("/");
                                }
                            }

                            if (s.contains("|127|") & s.contains("|17|")) {
                                MchUI.input_Command.setText("");
                            }

                            if (s.contains("|27|") & s.contains("|18|")) {
                                exit.Ex();
                            }

                            if ((s.contains("|82|") & s.contains("|17|")) || (s.contains("|82|") & s.contains("|18|"))) {
                                reStart.restart();
                            }

                            if ((s.contains("|67|") & s.contains("|18|")) || (s.contains("|17|") & s.contains("|18|"))) {
                                if (Community.ColorID == 0) {
                                    Events.switchColor(1);
                                } else if (Community.ColorID == 1) {
                                    Events.switchColor(0);
                                }
                            }

                            if (s.contains("|76|") & s.contains("|18|")) {
                                if (Community.LangID == 0) {
                                    Events.switchLanguage(1);
                                } else if (Community.LangID == 1) {
                                    Events.switchLanguage(0);
                                }
                            }
                            getC().clear();
                        } else if (getC().size() == 1) {
                            String s = Arrays.toString(getC().toArray()).replace("[","|").replace("]","|").replace(",","|").replace(" ","");
                            System.out.println(s);
                        }
                    } catch (Exception ex) {

                    }
                }

                @Override
                public void keyReleased(KeyEvent e) {
                    c.clear();
//                    System.out.println(e.getKeyCode() + ":" + e.getKeyCode());

                }
            });
        } catch (Error er) {
            Errors.errors(er, null, false, "KeyListener");
        }
    }

    public Set<Integer> getC() {
        return c;
    }

    public void setC(Set<Integer> c) {
        this.c = c;
    }
}

class ex {
    public static Set<Integer> c = new HashSet<>();

    public ex() {
        exit.jTextArea.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                c.add(e.getKeyCode());
                String s = Arrays.toString(c.toArray()).replace("[","|").replace("]","|");

                System.out.println(s);
                if (s.contains("|10|")) {
                    exit.Ex();
                }

                if (s.contains("|8|")) {
                    exit.jFrame.setVisible(false);
                }

                c.clear();
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });
    }
}

class mainFrame {
    public static Set<Integer> c = new HashSet<>();

    public mainFrame() {
        MchUI.command1.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                try {
                    c.add(e.getKeyCode());

                    String s = Arrays.toString(c.toArray()).replace("[","|").replace("]","|").replace(",","|").replace(" ","");
                    System.out.println(s);

                    if (c.size() > 1) {
                        if (s.contains("|27|") & s.contains("|17|")) {
                            exit.Ex();
                        }

                        if (s.contains("|77|") & s.contains("|17|")) {
                            Events.menu();
                        }

                        if (s.contains("|71|") & s.contains("17")) {
                            Helps.gayhub();
                        }

                        if ((s.contains("|82|") & s.contains("|17|")) || (s.contains("|82|") & s.contains("|18|"))) {
                            reStart.restart();
                        }

                        if ((s.contains("|67|") & s.contains("|18|")) || (s.contains("|17|") & s.contains("|18|"))) {
                            if (Community.ColorID == 0) {
                                Events.switchColor(1);
                            } else if (Community.ColorID == 1) {
                                Events.switchColor(0);
                            }
                        }

                        if (s.contains("|76|") & s.contains("|18|")) {
                            if (Community.LangID == 0) {
                                Events.switchLanguage(1);
                            } else if (Community.LangID == 1) {
                                Events.switchLanguage(0);
                            }
                        }

                        if (s.contains("|122|") & s.contains("|123|")) {
                            System.out.println("\033[40;1m\033[32;1m" +
                                    "T" +
                                    "\033[0;1m\033[33;1m" +
                                    "h" +
                                    "\033[43;1m\033[34;1m" +
                                    "i" +
                                    "\033[40;1m\033[35;1m" +
                                    "s\033[0;0m " +
                                    "\u001B[41;1m\033[36;1m" +
                                    "a\u001B[0;0m " +
                                    "\u001B[40;1m\033[37;1m" +
                                    "c" +
                                    "\u001B[44;1m\033[38;1m" +
                                    "o" +
                                    "\u001B[46;1m\033[39;1m" +
                                    "l" +
                                    "\u001B[42;1m\033[31;1m" +
                                    "o" +
                                    "\u001B[47;1m\033[39;1m" +
                                    "r" +
                                    "\u001B[48;1m\033[31;1m" +
                                    "e" +
                                    "\u001B[43;1m\033[35;1m" +
                                    "g" +
                                    "\u001B[47;1m\033[30;1m" +
                                    "g" +
                                    "\033[0;0m");
                        }

                        if (s.contains("|17|") & s.contains("|85|")) {
                            URLs.checkUPD = true;
                        }

                        c.clear();
                    }

                } catch (Exception ex) {

                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                c.clear();
            }
        });
    }
}