package project.Community.FunctionEditor;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.io.File;

public class Editor {
    public static JTextArea jTextArea = new JTextArea();
    public static JFrame jFrame = new JFrame("FunctionEditor");

    public static JButton saveFunc = new JButton();

    public Editor () {
        {
            //        窗口初始化设置
            //获得屏幕大小
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            Dimension screenSize = toolkit.getScreenSize();
            int width = screenSize.width;
            int height = screenSize.height;

            //设置窗口位置
            jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

            jFrame.setSize(500, 300);
        }
        LayoutManager layoutManager = new LayoutManager() {
            @Override
            public void addLayoutComponent (String name, Component comp) {
            }

            @Override
            public void removeLayoutComponent (Component comp) {
            }

            @Override
            public Dimension preferredLayoutSize (Container parent) {
                return null;
            }

            @Override
            public Dimension minimumLayoutSize (Container parent) {
                return null;
            }

            @Override
            public void layoutContainer (Container parent) {
                int Height = jFrame.getHeight();
                int Width = jFrame.getWidth();

                jTextArea.setBounds(0, 0, Width - (Width / 3), Height);
                saveFunc.setBounds(Width - (Width / 3) + 10, 0, 100, 30);
            }
        };

        jFrame.setLayout(layoutManager);

        jFrame.add(jTextArea);
        jFrame.add(saveFunc);

        saveFunc.addActionListener(e -> saveFunction());

        jFrame.setVisible(false);
    }

    public static void saveFunction () {
        int result = 0;
        new File("");
        String path = null;
        JFileChooser fileChooser = new JFileChooser();
        FileSystemView fsv = FileSystemView.getFileSystemView();
        fileChooser.setCurrentDirectory(fsv.getHomeDirectory());
        fileChooser.setDialogTitle("选择保存路径");
        fileChooser.setApproveButtonText("确定");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        result = fileChooser.showOpenDialog(jFrame);
        if (JFileChooser.APPROVE_OPTION == result) {
            path = fileChooser.getSelectedFile().getPath();
            System.out.println("path: " + path);
        }
    }
}
