package project.resources.UI.Color;

import project.Community.Community;
import project.Community.Times.times;
import project.resources.UI.CaUI;
import project.resources.UI.MenuUI;
import project.resources.UI.exit;

import java.awt.*;

public class colors extends Thread {
    @Override
    public void run() {
        System.out.println("[" + times.format + "]\n" + "colors:色彩就绪");
        while (true) {
            try {
                Color();
            } catch (NullPointerException ignored) {
                System.out.println("?");
            }
        }
    }

    public static void Color() {
        try {
            Thread.sleep(15);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        CaUI.menu.setBorderPainted(false);
        CaUI.menu.setFocusPainted(false);

        exit.buttonEXIT.setBorderPainted(false);
        exit.buttonEXIT.setFocusPainted(false);
        exit.buttonEXITNot.setBorderPainted(false);
        exit.buttonEXITNot.setFocusPainted(false);

        Color Black = new Color(0, 0, 0);
        Color White = new Color(214, 214, 214);
        Color Black_Background = new Color(43,43,43);
        Color Black_Input = new Color(49,51,53);
        Color Black_Button = new Color(60,63,65);
        Color Black_Tip = new Color(58,58,58);


//            ID=0为白色
        if (Community.ColorID == 0) {
            CaUI.jFrame.getContentPane().setBackground(Color.white);
            MenuUI.jFrame.getContentPane().setBackground(Color.white);
            exit.jFrame.getContentPane().setBackground(Color.white);

            CaUI.tips.setBackground(Color.white);
            CaUI.input_Command.setBackground(White);
            CaUI.menu.setBackground(White);
            CaUI.command1.setBackground(Color.white);

            exit.buttonEXIT.setBackground(White);
            exit.buttonEXITNot.setBackground(White);
            exit.jTextArea.setBackground(Color.white);

            MenuUI.Black.setBackground(White);
            MenuUI.White.setBackground(White);
            MenuUI.User_Color.setBackground(White);


            CaUI.tips.setForeground(Black);
            CaUI.input_Command.setForeground(Black);
            CaUI.menu.setForeground(Black);
            CaUI.command1.setForeground(Black);

            exit.buttonEXIT.setForeground(Black);
            exit.buttonEXITNot.setForeground(Black);
            exit.jTextArea.setForeground(Black);

            MenuUI.User_Color.setForeground(Black);
            MenuUI.White.setForeground(Black);
            MenuUI.Black.setForeground(Black);
            MenuUI.Color.setForeground(Black);
            MenuUI.PATH.setForeground(Black);
        } else if (Community.ColorID == 1) {
            CaUI.jFrame.getContentPane().setBackground(Black_Background);
            MenuUI.jFrame.getContentPane().setBackground(Black_Background);
            exit.jFrame.getContentPane().setBackground(Black_Background);

            CaUI.tips.setBackground(Black_Tip);
            CaUI.input_Command.setBackground(Black_Input);
            CaUI.menu.setBackground(Black_Button);
            CaUI.command1.setBackground(Black_Background);

            exit.buttonEXIT.setBackground(Black_Button);
            exit.buttonEXITNot.setBackground(Black_Button);
            exit.jTextArea.setBackground(Black_Background);

            MenuUI.Black.setBackground(Black_Button);
            MenuUI.White.setBackground(Black_Button);
            MenuUI.User_Color.setBackground(Black_Button);


            CaUI.tips.setForeground(White);
            CaUI.input_Command.setForeground(White);
            CaUI.menu.setForeground(White);
            CaUI.command1.setForeground(White);

            exit.buttonEXIT.setForeground(White);
            exit.buttonEXITNot.setForeground(White);
            exit.jTextArea.setForeground(White);

            MenuUI.User_Color.setForeground(White);
            MenuUI.White.setForeground(White);
            MenuUI.Black.setForeground(White);
            MenuUI.Color.setForeground(White);
            MenuUI.PATH.setForeground(White);
        }

    }
}