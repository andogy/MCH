package project.resources.UI.Lang;

import project.Community.Command.ini;
import project.Community.Community;
import project.Community.Times.times;
import project.resources.UI.CaUI;
import project.resources.UI.MenuUI;
import project.resources.UI.exit;

public class language extends Thread {
    public static String gamemode = "";
    public static String gamerule = "";
    public static String exi = "";
    public static String guess = "";

    @Override
    public void run() {
        System.out.println("[" + times.format + "]\n" + "language:语言就绪");
        while (true) {
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Language();
        }
    }

    public static void Language() {

//            ID=0为中文
        if (Community.LangID == 0) {
            CaUI.menu.setText("菜单");
            CaUI.jFrame.setTitle("Minecraft命令助手");

            MenuUI.jFrame.setTitle("菜单页");

            gamemode = "-设定游戏模式";
            gamerule = "-设定游戏规则";

            exi = "-退出程序";

            guess = "是否想输入:";

            exit.jTextArea.setText("\".exit\"是一个在此程序中用于退出的命令,并非游戏内指令\n是否要继续退出?");
            exit.buttonEXIT.setText("退出");
            exit.buttonEXITNot.setText("不退出");

            MenuUI.PATH.setText("配置路径:  " + ini.path);
        } else if (Community.LangID == 1) {
            //英文
            CaUI.menu.setText("Menus");
            CaUI.jFrame.setTitle("Minecraft Command Helper");

            MenuUI.jFrame.setTitle("Menu");

            gamemode = "-Set gameMode";
            gamerule = "-Set gameRules";

            exi = "-Exit Command Helper";

            exit.jTextArea.setText("\".exit\" is a command used by this program to exit,This not an in-game command \nDo you want to continue to exit");
            exit.buttonEXIT.setText("Exit");
            exit.buttonEXITNot.setText("Exit Not");

            MenuUI.PATH.setText("Config path:  " + ini.path);
        }

    }
}
