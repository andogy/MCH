package project.resources.UI;

import project.Community.Command.ini;

import javax.swing.*;
import java.awt.*;

public class MenuUI {
    public static JLabel PATH = new JLabel();
    public static JFrame jFrame = new JFrame();

    public static JLabel Color = new JLabel();
    public static JButton Black = new JButton();
    public static JButton White = new JButton();
    public static JButton User_Color = new JButton();

    public MenuUI() {
        menuUI();
    }

    public static void menuUI() {
        new ini();

        //        窗口初始化设置
        //获得屏幕大小
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

        jFrame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        //显示窗口
        jFrame.setVisible(true);

        LayoutManager layoutManager = new LayoutManager() {
            @Override
            public void addLayoutComponent(String name, Component comp) {
            }
            @Override
            public void removeLayoutComponent(Component comp) {
            }
            @Override
            public Dimension preferredLayoutSize(Container parent) {
                return null;
            }
            @Override
            public Dimension minimumLayoutSize(Container parent) {
                return null;
            }

            @Override
            public void layoutContainer(Container parent) {
                PATH.setBounds(0,0,300,30);

                Color.setBounds(0,35,300,30);
            }
        };

        jFrame.setLayout(layoutManager);

        jFrame.setSize(500,300);
        jFrame.setResizable(false);

        jFrame.add(PATH);
    }
}
