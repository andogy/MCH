package project.Community;

import project.Community.Command.ini;
import project.Community.Times.times;
import project.resources.UI.CaUI;
import project.resources.UI.exit;

public class Community {

    public static int ColorID = 0;
    public static int LangID = 0;

    public static void main(String[] args) {
        new times().start();

        System.out.println("[" + times.format + "]\n" + "exit:exit事件就绪中");
        new exit();

        System.out.println("[" + times.format + "]\n" +"ini:配置文件就绪中");
        new ini();
        /*
        预加载部分
         */

//        显示UI
        System.out.println("[" + times.format + "]\n" + "CaUI:UI就绪中");
        new CaUI();
    }
}