package project.Community.Command;

import project.Community.Community;
import project.Community.Times.times;

import java.io.*;

public class ini {
    public static String sets = "settings.ini";
    public static String path = "C:\\MCH\\";

    public ini() {
        create();
        parsing();
    }

    public static void parsing() {
        try {

            String src = path + sets;
            File ini = new File(src);

            // 构造一个BufferedReader类来读取文件
            BufferedReader br = new BufferedReader(new FileReader(ini));
            String s;

            // 使用readLine方法，一次读一行
            while ((s = br.readLine()) != null) {

                int re = s.indexOf("/*");

                if (re == -1) {
                    Reads(s);
                }
            }

            br.close();
        } catch (Exception ignored) {
        }

        System.out.println("[" + times.format + "]\n" + "ini:配置文件就绪");
    }

    public static void create() {
        try {
            FileReader fr = new FileReader(path + sets);
            try {
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            File file = new File(path);
            file.mkdirs();

            String ini = "/* 配置文件对格式要求严格,一般情况下请不要手动修改\n" +
                    "Color = White\n" +
                    "Language = Chinese";
            try {
                FileWriter file1 = new FileWriter(path + sets);
                file1.write(ini);
                file1.close();
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        }
    }

    public static void Reads(String s) {
        //            将大写字母全替换为小写
        s = s.replace("A", "a").replace("B", "b").replace("C", "c").replace("D", "d").replace("E", "e").replace("F", "f").replace("G", "g").replace("H", "i").replace("J", "j").replace("K", "k").replace("L", "l").replace("M", "m").replace("N", "n").replace("O", "o").replace("P", "p").replace("Q", "q").replace("R", "r").replace("S", "s").replace("T", "t").replace("U", "u").replace("V", "v").replace("W", "w").replace("X", "x").replace("Y", "y").replace("Z", "z");

        {
            int color = s.indexOf("color");
            int User_color = s.indexOf("color_config");

            if (color != 1 && User_color == -1) {
                int Black = s.indexOf("black");
                int White = s.indexOf("white");

                if (!(Black != -1 & White != -1)) {
                    if (Black != -1) {
                        Community.ColorID = 1;
                    }

                    if (White != -1) {
                        Community.ColorID = 0;
                    }
                }
            }
        }

        {
            int Lang = s.indexOf("language");

            if (Lang != -1) {

                int Chinese = s.indexOf("chinese");
                int English = s.indexOf("english");

                if (!(Chinese != -1 & English != -1)) {
                    if (Chinese != -1) {
                        Community.LangID = 0;
                    }

                    if (English != -1) {
                        Community.LangID = 1;
                    }
                }
            }
        }

    }
}
