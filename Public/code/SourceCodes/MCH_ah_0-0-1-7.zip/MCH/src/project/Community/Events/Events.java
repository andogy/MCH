package project.Community.Events;

import project.resources.UI.CaUI;
import project.resources.UI.MenuUI;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;

public class Events {
    public static void menu() {
        new MenuUI();
    }

    public static void Copy() {
        StringSelection selection = new StringSelection(CaUI.input_Command.getText());
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(selection,null);
    }

    public static void switchColor() {

    }
}
