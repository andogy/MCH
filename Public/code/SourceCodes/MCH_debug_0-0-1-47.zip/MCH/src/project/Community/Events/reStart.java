package project.Community.Events;

import project.Community.Events.UPD.getJar;
import project.Community.UI.exit;

public class reStart {
    public static boolean newMchIsStarted = false;

    public static String restart() {
        try {
            //            运行一个新的MCH
            Runtime r = Runtime.getRuntime();
            String str = r.exec("cmd.exe /k " + getJar.getOldPath()).toString();
            System.out.println(str);
            if (str.contains("not exited")) {
                System.out.println("restart failed");
            } else {
                newMchIsStarted = true;
            }


            //        重启
            if (newMchIsStarted) {
                exit.Ex();
            } else {
                return str;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
