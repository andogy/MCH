package test.zip;

import java.math.BigDecimal;
import java.util.zip.ZipException;

public class zipThread5 extends Thread{
    public void run() {
        BigDecimal bigDecimal = BigDecimal.valueOf(39999);
        try {
            password.Unzip4j1("G:\\Code-Java\\MCH\\test.zip",bigDecimal , 10000,"4");
        } catch (ZipException e) {
            e.printStackTrace();
        }
    }
}
