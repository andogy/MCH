package test;

public class loop extends Thread {
    public void run() {
        while (true) {

        }
    }

    public static void main(String[] args) {
        while (true) {
            new loop().start();
        }
    }
}
