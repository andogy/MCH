package test;

import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class connect extends Thread{
    public static BigDecimal bigDecimal = new BigDecimal(0);

    public void run() {
        try {
            while (true) {
                // 统一资源
                URL url = new URL("https://www.baidu.com");
                // 连接类的父类，抽象类
                URLConnection urlConnection = url.openConnection();
                // http的连接类
                HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;

                //设置超时
                httpURLConnection.setConnectTimeout(10000);

                //设置请求方式
                httpURLConnection.setRequestMethod("POST");

                // 设置字符编码
                httpURLConnection.setRequestProperty("Charset", "UTF-8");

                // 打开到此 URL引用的资源的通信链接（如果尚未建立这样的连接）
                httpURLConnection.connect();

//                System.out.println(httpURLConnection.getResponseMessage());

                if (httpURLConnection.getResponseMessage().equals("OK")) {
                    bigDecimal = bigDecimal.add(BigDecimal.valueOf(1));
                } else {
//                    System.out.println("a thread cannot connect");
                }
            }
        } catch (Exception e) {
//            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        new connect().start();
        long time = 0;
        while (true) {
            try {
                Thread.sleep(100);
                System.out.println("connect:" + bigDecimal + ",times:" + time / 1000 + "s");
                time += 100;
            } catch (Exception e) {

            }
        }
    }
}
