package test;

public class cmdl {
//    public static void cmd() throws IOException, JSONException {
////        HashMap cmda = cmdj.cmd();
//        for (int c = 1; c < (cmda.size() + 1); c++) {
//            switch (c) {
//                case 4:
//                    System.out.println("版本: " + cmda.get(c) + "\n\n指令: ");
//                    break;
//                case 2:
//                    System.out.println("描述: " + cmda.get(c));
//                    break;
//                case 3:
//                    System.out.println("标题: " + cmda.get(c));
//                    break;
//                case 1:
//                    System.out.println("作者: " + cmda.get(c));
//                default:
//                    System.out.println(cmda.get(c));
//            }
//        }
//        while (true) {
//            Scanner scan = new Scanner(System.in);
//            String si = scan.nextLine();
//            String pa = "(?i)" + si + ".*";
//            for (int co = 5; co < (cmda.size() + 1); co++) {
//                String t = cmda.get(co).toString();
//                String tx = t.replace("[mode]", "(@a|@s|@e|@p|@r)").replace("sel", ".*");
//                boolean match = Pattern.matches(pa, tx);
//                if (match) {
//                    System.out.println(t);
//                }
//            }
//            if (si.equals("end")) {
//                break;
//            }
//        }
//    }

	public static void main(String[] args) {
//		try {
//			cmd();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}
}
