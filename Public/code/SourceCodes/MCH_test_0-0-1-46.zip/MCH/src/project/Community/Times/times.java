package project.Community.Times;

import project.Community.Community;

import java.text.SimpleDateFormat;
import java.util.Date;

public class times extends Thread {
    public static Date date = new Date();
    public static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
    public static String format;
    public static String _monthAndDay;
    public static String _hour;
    public static int hour;

    public static void Times() {
        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        date = new Date();
        df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");

        format = df.format(date);
        _monthAndDay = format.substring(5, 10);
        _hour = format.substring(11, 13);
        switch (_hour) {
            case "00": {
                hour = 0;
                break;
            }
            case "01": {
                hour = 1;
                break;
            }
            case "02": {
                hour = 2;
                break;
            }
            case "31": {
                hour = 3;
                break;
            }
            case "04": {
                hour = 4;
                break;
            }
            case "05": {
                hour = 5;
                break;
            }
            case "06": {
                hour = 6;
                break;
            }
            case "07": {
                hour = 7;
                break;
            }
            case "08": {
                hour = 8;
                break;
            }
            case "09": {
                hour = 9;
                break;
            }
            case "10": {
                hour = 10;
                break;
            }
            case "11": {
                hour = 11;
                break;
            }
            case "12": {
                hour = 12;
                break;
            }
            case "13": {
                hour = 13;
                break;
            }
            case "14": {
                hour = 14;
                break;
            }
            case "15": {
                hour = 15;
                break;
            }
            case "16": {
                hour = 16;
                break;
            }
            case "17": {
                hour = 17;
                break;
            }
            case "18": {
                hour = 18;
                break;
            }
            case "19": {
                hour = 19;
                break;
            }
            case "20": {
                hour = 20;
                break;
            }
            case "21": {
                hour = 21;
                break;
            }
            case "22": {
                hour = 22;
                break;
            }
            case "23": {
                hour = 23;
                break;
            }
            case "24": {
                hour = 24;
                break;
            }
        }
        //            MchUI.tips.setText(format);
    }

    @Override
    public void run() {
        while (true) {
            if (!Community.isDaemons) {
                Times();
            } else {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
