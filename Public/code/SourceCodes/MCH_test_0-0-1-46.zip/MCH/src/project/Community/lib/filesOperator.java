package project.Community.lib;

import project.Community.Community;
import project.Community.Events.LoadAssembly;
import project.Community.Times.times;

import java.io.File;

public class filesOperator {
    public static long fileSize = 0;

    public static void DeleteFiles(File[] path) {
        try {
            for (File f : path) {
                if (f.isFile()) {
                    if (!f.getName().equals("settings.ini") & !f.getName().equals("run.log")) {
                        LoadAssembly.loadAssembly("delete: " + f.getName() + "\n");
                        f.delete();
                    }
                }
                if (f.isDirectory()) {
                    DeleteFiles(f.listFiles());
                    f.delete();
                }
            }
        } catch (Exception ignored) {

        }
    }

    public static long ReadFiles(File[] path, String slow) {
        fileSize = READ(path, slow);
        long size = fileSize;
        fileSize = 0;
        return size;
    }

    public static long READ(File[] path, String slow) {
        try {
            for (File f : path) {
                if (!Community.isDaemons) {
                    if (!Community.fastLoad) {
                        Thread.sleep(1);
                    } else if (slow.equals("slow")) {
                        Thread.sleep(1);
                    }
                    if (f.isFile()) {
                        fileSize += f.length();
                        System.out.println("file:" + f.getName());
                    } else if (f.isDirectory()) {
                        System.out.println("in dir:" + f.getName());
                        READ(f.listFiles(), slow);
                    }
                } else {
                    break;
                }
            }
        } catch (Exception ignored) {
            return 0;
        }
        return fileSize;
    }

    public static void saveCache(File file, File toFile, String name) {
        toFile.mkdirs();
        file.getName();
        file.renameTo(new File(toFile + "\\" + name + "_" + times.format.replace(" ", "_").replace(":", "-") + ".cache"));
    }
}
