package project.resources.UI;

import javax.swing.*;
import java.awt.*;

public class HelpUI {
    public static JTextArea help = new JTextArea();
    public static JFrame jFrame = new JFrame();


    public HelpUI() {
        helpUI();
    }

    public static void helpUI() {

        //        窗口初始化设置
        //获得屏幕大小
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

        //设置退出时不响应操作,因为要使用自定义退出事件
        jFrame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        //设置窗口大小和颜色
        jFrame.setSize(500, 300);
        jFrame.getContentPane().setBackground(Color.white);

        //显示窗口
        jFrame.setVisible(true);

        LayoutManager layoutManager = new LayoutManager() {
            @Override
            public void addLayoutComponent(String name, Component comp) {
            }
            @Override
            public void removeLayoutComponent(Component comp) {
            }
            @Override
            public Dimension preferredLayoutSize(Container parent) {
                return null;
            }
            @Override
            public Dimension minimumLayoutSize(Container parent) {
                return null;
            }

            @Override
            public void layoutContainer(Container parent) {

            }
        };

        jFrame.setLayout(layoutManager);

        jFrame.add(help);


    }
}
