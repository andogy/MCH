package project.resources.UI.Color;

import project.Community.Community;
import project.resources.UI.CaUI;
import project.resources.UI.EXI;

import java.awt.*;

public class colors extends Thread {
    @Override
    public void run() {
        while (true) {
            try {
                Color();
            } catch (NullPointerException ignored) {
                System.out.println("?");
            }
        }
    }

    public static void Color() {
        try {
            Thread.sleep(15);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        CaUI.menu.setBorderPainted(false);
        CaUI.menu.setFocusPainted(false);

        EXI.buttonEXIT.setBorderPainted(false);
        EXI.buttonEXIT.setFocusPainted(false);
        EXI.buttonEXITNot.setBorderPainted(false);
        EXI.buttonEXITNot.setFocusPainted(false);

        Color Black = new Color(0, 0, 0);
        Color White = new Color(214, 214, 214);


//            ID=0为白色
        if (Community.ColorID == 0) {
            CaUI.input_Command.setBackground(White);
            CaUI.menu.setBackground(White);
            EXI.buttonEXIT.setBackground(White);
            EXI.buttonEXITNot.setBackground(White);

            CaUI.input_Command.setForeground(Black);
            CaUI.menu.setForeground(Black);
            EXI.buttonEXIT.setForeground(Black);
            EXI.buttonEXITNot.setForeground(Black);
        } else if (Community.ColorID == 1) {
            //简洁明了，黑色
            CaUI.input_Command.setBackground(Black);
            CaUI.menu.setBackground(Black);
        }

    }
}