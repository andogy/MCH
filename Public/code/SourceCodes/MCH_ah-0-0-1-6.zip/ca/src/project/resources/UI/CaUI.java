package project.resources.UI;

import project.Community.Command.Parsing;
import project.Community.EXIT_Button;
import project.Community.Events.Events;
import project.resources.UI.Color.colors;
import project.resources.UI.Lang.language;

import javax.swing.*;
import java.awt.*;

public class CaUI {
    public CaUI() {
        caUI();
    }

    public static JFrame jFrame = new JFrame();
    public static JTextPane input_Command = new JTextPane();
    public static JButton menu = new JButton();
    public static JTextArea command1 = new JTextArea();

    public static void caUI() {
//        引入退出类
        new EXIT_Button();

//        加载颜色
        new colors().start();

//        加载语言
        new language().start();

//        解析输入
        new Parsing().start();

//        窗口初始化设置
        //获得屏幕大小
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

        //设置退出时不响应操作,因为要使用自定义退出事件
        jFrame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

        //设置窗口大小和颜色
        jFrame.setSize(500, 300);
        jFrame.getContentPane().setBackground(Color.white);

        //显示窗口
        jFrame.setVisible(true);

        LayoutManager layoutManager = new LayoutManager() {
            @Override
            public void addLayoutComponent(String name, Component comp) {
            }
            @Override
            public void removeLayoutComponent(Component comp) {
            }
            @Override
            public Dimension preferredLayoutSize(Container parent) {
                return null;
            }
            @Override
            public Dimension minimumLayoutSize(Container parent) {
                return null;
            }

            @Override
            public void layoutContainer(Container parent) {
                int Height = jFrame.getHeight();
                int Width = jFrame.getWidth();

                command1.setBounds(0,0,200,100);

                input_Command.setBounds(0, Height - 60, Width - 110, 20);
                menu.setBounds(Width - 100 ,Height - 60,80,20);
            }
        };

        jFrame.setLayout(layoutManager);

        jFrame.add(input_Command);
        jFrame.add(menu);
        jFrame.add(command1);

        command1.setLineWrap(true);

        menu.addActionListener(e -> Events.menu());
    }
}
