package project.Community.Command;

import project.Community.Command.Tree.mainCommand;
import project.Community.Community;
import project.Community.Events.Errors;
import project.Community.Events.Events;
import project.Community.Events.historyReader;
import project.Community.Exits;
import project.Community.UI.MchUI;
import project.Community.UI.MenuUI;
import project.Community.UI.exit;

public class Parsing extends Thread {
    public static String display = "";

    public static boolean flushHistory = true;

    public void run() {
        parsing();
    }

    private static void parsing() {
        while (true) {

            MchUI.jFrame.setAlwaysOnTop(Community.onTop);
            MenuUI.jFrame.setAlwaysOnTop(Community.onTop);

            if (Errors.CannotHandle) {
                break;
            }
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (!Exits.small) {
                if (MchUI.jFrame.getWidth() < 500) {
                    MchUI.jFrame.setSize(500, MchUI.jFrame.getHeight());
                }
                if (MchUI.jFrame.getHeight() < 300) {
                    MchUI.jFrame.setSize(MchUI.jFrame.getWidth(), 300);
                }
            }

            if (Exits.small) {
                if (MchUI.jFrame.getHeight() > 40) {
                    Exits.small = false;
                }
            }

//          获取输入
            String str = MchUI.input_Command.getText();
            //            将大写字母全替换为小写
            str = str.replace("A", "a").replace("B", "b").replace("C", "c").replace("D", "d").replace("E", "e").replace("F", "f").replace("G", "g").replace("H", "h").replace("I", "i").replace("J", "j").replace("K", "k").replace("L", "l").replace("M", "m").replace("N", "n").replace("O", "o").replace("P", "p").replace("Q", "q").replace("R", "r").replace("S", "s").replace("T", "t").replace("U", "u").replace("V", "v").replace("W", "w").replace("X", "x").replace("Y", "y").replace("Z", "z");
//            将两个以上的空格转为一个,方便处理
            str = str.replace("  ", " ");

            if (str.equals(".exit")) {
                exit.jFrame.setSize(500, 300);
                exit.jFrame.setVisible(true);
                MchUI.input_Command.setText("");
            }

            if (str.contains("\n")) {
                if (!str.replace("\n", "").contains("\n")) {
                    try {
                        Events.Copy();
                        MchUI.input_Command.setText("");
                    } catch (IllegalStateException e) {
                        Errors.errors(e, true, "copy");
//                        exit.Ex();
                    }
                }
            }

            if (str.contains("  ")) {
                str = str.replace("  ", " ");
                MchUI.input_Command.setText(str);
            }
            if (str.indexOf(" ") == 0) {
                str = str.substring(1);
                MchUI.input_Command.setText(str);
            }

            MchUI.tips.setText("");

            display = "";

//            空输入时键入tab快捷输入斜杠
            if (str.equals("\t")) {
                MchUI.input_Command.setText("/");
            } else if (str.contains("\t")) {
                str = str.replace("\t", "");
                MchUI.input_Command.setText(str);
            }

            if (str.contains("/")) {
                if (str.lastIndexOf("/") != 0) {
                    if (Community.LangID == 0) {
                        Parsing.display = "第" + (str.lastIndexOf("/") + 1) + "位字符的斜杠是非法存在的,请删除它";
                    } else {
                        Parsing.display = "The slash of the " + ((str.lastIndexOf("/")) + 1) + " character is illegal. Please delete it";
                    }
                }
            }

            str = str.replace("\r", "").replace("\n", "");
            //            在有输入的情况下才进行提示
            if (!str.equals("")) {
                if (str.lastIndexOf("/") == 0 || !str.contains("/")) {
                    mainCommand.parsingCommand(str);
                    historyReader.BreakRead = true;
                    flushHistory = true;
                }
                MchUI.command1.setText(display);
                if (MchUI.input_Command.getText().contains("//")) {
                    MchUI.input_Command.setText(MchUI.input_Command.getText().replace("//", "/"));
                }
            } else {
                if (flushHistory) {
                    historyReader.BreakRead = false;
                    flushHistory = false;
                }
            }
        }
    }
}
