package project.Community.Events.UPD;

import project.Community.Community;
import project.Community.Events.Errors;
import project.Community.UI.MenuUI;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class URLs extends Thread {
    public static boolean UPD = false;
    public static boolean nowUPD = false;

    public static boolean checkUPD = false;

    public void run() {
        while (true) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (checkUPD) {
                UPD = checkUPD();
                checkUPD = false;
            }

            if (nowUPD) {
                UPD();
                nowUPD = false;
            }
        }
    }

    public static boolean checkUPD() {
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection conn = null;
        try {
            URL url;
            if (Community.updFromGithub) {
                url = new URL("https://raw.githubusercontent.com/andogy/MCH/main/NewlyUPD/atudpc.php");
            } else {
                url = new URL("http://caibiwangluo.eu5.org/mch/atupdc.php");
            }
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            //发送POST请求必须设置为true
            conn.setDoOutput(true);
            conn.setDoInput(true);
            //设置连接超时时间和读取超时时间
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(10000);
            //获取输出流
            out = new OutputStreamWriter(conn.getOutputStream());
            //取得输入流，并使用Reader读取
            if (200 == conn.getResponseCode()) {
                in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                String line;
                while ((line = in.readLine()) != null) {
                    result.append(line);
                }
            } else {
                MenuUI.checkReturn.setText("ResponseCode is an error code:" + conn.getResponseCode());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
            conn.disconnect();
        }
        return result.toString().equals(Community.UPD_ID);
    }

    public static void UPD() {
        String downloadDir = "C:\\.MCH\\";
        String fileFullName = "UPD.cache";
        try {

            String urlPath;
            if (Community.updFromGithub) {
                urlPath = "https://raw.githubusercontent.com/andogy/MCH/main/NewlyUPD/MCH.jar";
            } else {
                urlPath = "http://caibiwangluo.eu5.org/mch/MCH.jar";
            }
//            urlPath = "http://speed.hetzner.de/1GB.bin";


            File file;
            // 统一资源
            URL url = new URL(urlPath);
            // 连接类的父类，抽象类
            URLConnection urlConnection = url.openConnection();
            // http的连接类
            HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;

            //设置超时
            httpURLConnection.setConnectTimeout(1000 * 5);

            //设置请求方式
            httpURLConnection.setRequestMethod("GET");

            // 设置字符编码
            httpURLConnection.setRequestProperty("Charset", "UTF-8");


            countTime.startDUP_count = true;

            // 打开到此 URL引用的资源的通信链接（如果尚未建立这样的连接）
            httpURLConnection.connect();

            if (countTime.startDUP_count) {

                countTime.startDUP_count = false;

                // 获取文件大小
                int fileLength = httpURLConnection.getContentLength();

                // 建立链接从请求中获取数据
                url.openConnection();
                BufferedInputStream bin = new BufferedInputStream(httpURLConnection.getInputStream());

                // 指定存放位置
                String path = downloadDir + File.separatorChar + fileFullName;
                file = new File(path);

                // 校验文件夹目录是否存在，不存在就创建一个目录
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }

                if (Community.LangID == 0) {
                    MenuUI.checkReturn.setText("检查下载请求中");
                } else if (Community.LangID == 1) {
                    MenuUI.checkReturn.setText("Checking Download request");
                }
                Thread.sleep(1000);

                if (Community.LangID == 0) {
                    MenuUI.checkReturn.setText("尝试下载中");
                } else if (Community.LangID == 1) {
                    MenuUI.checkReturn.setText("trying Download");
                }

                Thread.sleep(1000);

//            System.out.println(fileFullName.length());
//            if (file.length() > 10240) {
                OutputStream out = new FileOutputStream(file);
                int size = 0;
                int len = 0;
                byte[] buf = new byte[8192];
                while ((size = bin.read(buf)) != -1) {
                    Thread.sleep(1);
                    len += size;
                    out.write(buf, 0, size);
                    // 控制台打印文件下载的百分比情况
                    if (Community.LangID == 0) {
                        MenuUI.checkReturn.setText("下载中:\n" + (float) (len) / 1024 / 1024 + "MB / " + (float) (fileLength) / 1024 / 1024 + "MB\n" + (float) (len) / fileLength * 100 + "%");
                    } else if (Community.LangID == 1) {
                        MenuUI.checkReturn.setText("Downloading:\n" + (float) (len) / 1024 / 1024 + "MB / " + (float) (fileLength) / 1024 / 1024 + "MB\n" + (float) (len) / fileLength * 100 + "%");
                    }
                }

                Thread.sleep(500);

                // 关闭资源
                bin.close();
                out.close();
                if (Community.LangID == 0) {
                    MenuUI.checkReturn.setText("下载完成");
                } else if (Community.LangID == 1) {
                    MenuUI.checkReturn.setText("Download Finished");
                }

                Thread.sleep(500);

                if (Community.LangID == 0) {
                    MenuUI.checkReturn.setText("尝试复制文件中");
                } else if (Community.LangID == 1) {
                    MenuUI.checkReturn.setText("trying copy file...");
                }

                Thread.sleep(1000);

                try (InputStream input = new FileInputStream("C:\\.MCH\\UPD.cache"); OutputStream output = new FileOutputStream(getJar.getOldPath())) {
                    Thread.sleep(1);
                    byte[] buff = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = input.read(buff)) > 0) {
                        output.write(buff, 0, bytesRead);

                        if (Community.LangID == 0) {
                            MenuUI.checkReturn.setText("复制了:\n" + new File(getJar.getOldPath()).length() + "Bytes/" + new File("C:\\.MCH\\UPD.cache").length()  + "Bytes");
                        } else if (Community.LangID == 1) {
                            MenuUI.checkReturn.setText("copied\n" + new File(getJar.getOldPath()).length() + "Bytes/" + new File("C:\\.MCH\\UPD.cache").length()  + "Bytes");
                        }
                    }
                }

                File file1 = new File(downloadDir + fileFullName);
                file1.delete();

                Thread.sleep(1000);

                if (Community.LangID == 0) {
                    MenuUI.checkReturn.setText("安装中...");
                } else if (Community.LangID == 1) {
                    MenuUI.checkReturn.setText("installing...");
                }

                Thread.sleep(1500);

                if (Community.LangID == 0) {
                    MenuUI.checkReturn.setText("尝试重启中...");
                } else if (Community.LangID == 1) {
                    MenuUI.checkReturn.setText("trying restart...");
                }

                Thread.sleep(1000);

                FileWriter f = new FileWriter("C:\\.MCH\\start.bat");
                f.write("java -Xmx100M -Xms100M -jar " + getJar.getOldPath());
                f.close();
                Runtime.getRuntime().exec("cmd.exe /k C:\\.MCH\\start.bat");

                System.exit(0);
            }
//            } else {
//                MenuUI.checkReturn.setText("Download Fail:\n" + "Cannot Download UPD File");
//            }
        } catch (FileNotFoundException e) {
            File file1 = new File(downloadDir + fileFullName);
            file1.delete();
            Errors.errors(null, e, false, "UPD");
            if (Community.LangID == 0) {
                MenuUI.checkReturn.setText("下载失败:\n" + "下载行为被拒绝");
            } else if (Community.LangID == 1) {
                MenuUI.checkReturn.setText("Download Fail :\n" + "access denied");
            }
        } catch (Exception ignored) {
        }

    }
}