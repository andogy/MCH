package project.Community.FunctionEditor;

public class Editor {
    //    public static JFrame jFrame = new JFrame("FunctionEditor");
    //
    //    public Editor () {
    //        {
    //            //        窗口初始化设置
    //
    //        }
    //        LayoutManager layoutManager = new LayoutManager() {
    //            @Override
    //            public void addLayoutComponent (String name, Component comp) {
    //            }
    //
    //            @Override
    //            public void removeLayoutComponent (Component comp) {
    //            }
    //
    //            @Override
    //            public Dimension preferredLayoutSize (Container parent) {
    //                return null;
    //            }
    //
    //            @Override
    //            public Dimension minimumLayoutSize (Container parent) {
    //                return null;
    //            }
    //
    //            @Override
    //            public void layoutContainer (Container parent) {
    //                int Height = jFrame.getHeight();
    //                int Width = jFrame.getWidth();
    //            }
    //        };
    //
    //        jFrame.setLayout(layoutManager);
    //
    //        jFrame.add(ExtraUI.functionEdit);
    //        jFrame.add(ExtraUI.saveFunc);
    //
    //
    //        jFrame.setVisible(false);
}

