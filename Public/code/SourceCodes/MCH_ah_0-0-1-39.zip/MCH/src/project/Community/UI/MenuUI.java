package project.Community.UI;

import project.Community.Command.ini;
import project.Community.Community;
import project.Community.Events.Events;
import project.Community.Events.LoadAssembly;
import project.Community.Events.UPD.URLs;
import project.Community.Events.filesOperator;
import project.Community.Events.reStart;
import project.Community.Help.Helps;
import project.Community.Times.times;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class MenuUI {
    public static JLabel PATH = new JLabel();
    public static JFrame jFrame = new JFrame();

    public static boolean OpenMenu = false;
    //    public static boolean OpeningMenu = false;

    public static JLabel mchDirSize = new JLabel();

    public static JButton feedback = new JButton();

    public static JLabel Problem = new JLabel();
    public static JButton randomProblem = new JButton();

    public static JButton deleteData = new JButton();

    public static JButton helps = new JButton();
    public static JButton user = new JButton();
    public static JButton gayhub = new JButton("Github");

    public static JButton checkUPD = new JButton();
    public static JTextArea checkReturn = new JTextArea();

    public static JButton restart = new JButton();

    public static JButton settings = new JButton();

    public static JLabel Ver = new JLabel();

    public MenuUI() {
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "MenuUI:Read ini\n");
        OpenMenu = true;
        menuUI();
    }

    public static void menuUI() {
        ini.parsing();

        if (ini.iniHas) {

            OpenMenu = false;

            jFrame.setSize(640, 360);
            jFrame.setResizable(false);

            //        窗口初始化设置
            //获得屏幕大小
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            Dimension screenSize = toolkit.getScreenSize();
            int width = screenSize.width;
            int height = screenSize.height;

            //设置窗口位置
            jFrame.setLocation(width / 2 - jFrame.getWidth() / 2, height / 2 - jFrame.getHeight() / 2);

            jFrame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

            //显示窗口
            jFrame.setVisible(true);

            MenuUI2.Hades.setVisible(false);

            checkReturn.setEditable(false);

            LayoutManager layoutManager = new LayoutManager() {
                @Override
                public void addLayoutComponent(String name, Component comp) {
                }

                @Override
                public void removeLayoutComponent(Component comp) {
                }

                @Override
                public Dimension preferredLayoutSize(Container parent) {
                    return null;
                }

                @Override
                public Dimension minimumLayoutSize(Container parent) {
                    return null;
                }

                @Override
                public void layoutContainer(Container parent) {
                    PATH.setBounds(0, 0, 150, 30);
                    Ver.setBounds(0, 30, 150, 30);
                    mchDirSize.setBounds(200, 0, 300, 30);

                    Problem.setBounds(0, 40 + 35 + 100, 110, 30);
                    randomProblem.setBounds(0, 40 + 35 + 100 + 30, 80, 30);

                    deleteData.setBounds(0, 40 + 35 + 100 + 30 + 40, 110, 30);

                    restart.setBounds(0, 40 + 35 + 100 + 30 + 40 + 30 + 10, 110, 30);

                    helps.setBounds(120, 40 + 35 + 100 + 30 + 40, 80, 30);

                    user.setBounds(210, 40 + 35 + 100 + 30 + 40, 100, 30);

                    ExtraUI.launcher.setBounds(320, 245, 90, 30);

                    feedback.setBounds(320, 285, 90, 30);

                    settings.setBounds(210, 40 + 35 + 100 + 30 + 40 + 30 + 10, 100, 30);

                    gayhub.setBounds(120, 40 + 35 + 100 + 30 + 40 + 30 + 10, 80, 30);

                    checkUPD.setBounds(420, 40 + 100 + 30, 100, 30);
                    checkReturn.setBounds(420, 40 + 110 + 30 + 30, 220, 135);
                }
            };

            jFrame.setLayout(layoutManager);

            jFrame.add(PATH);
            jFrame.add(Ver);
            jFrame.add(Problem);
            jFrame.add(randomProblem);
            jFrame.add(deleteData);
            jFrame.add(helps);
            jFrame.add(user);
            jFrame.add(gayhub);
            jFrame.add(checkUPD);
            jFrame.add(checkReturn);
            jFrame.add(restart);
            jFrame.add(settings);
            jFrame.add(mchDirSize);
            jFrame.add(ExtraUI.launcher);
            jFrame.add(feedback);

            deleteData.addActionListener(e -> {
                if (!Community.isDaemons) {
                    File runLog = new File(ini.path + "run.log");
                    runLog.delete();

                    File[] caches = new File(ini.path).listFiles();

                    filesOperator.DeleteFiles(caches);
                }
            });

            helps.addActionListener(e -> Helps.Helps());
            user.addActionListener(e -> Helps.agreement());
            gayhub.addActionListener(e -> Helps.gayhub());
            checkUPD.addActionListener(e -> {
                if (Community.canUPD) {
                    URLs.nowUPD = true;
                } else {
                    Events.checkUPD();
                }
            });
            restart.addActionListener(e -> reStart.restart());

            settings.addActionListener(e -> {
                if (!Community.isDaemons) {
                    MenuUI2.jFrame.setVisible(true);
                }
            });

            ExtraUI.launcher.addActionListener(e -> {
                if (!Community.isDaemons) {
                    ExtraUI.jFrame.setVisible(true);
                }
            });

            feedback.addActionListener(e -> Helps.feedback());
        }

        System.gc();
    }
}