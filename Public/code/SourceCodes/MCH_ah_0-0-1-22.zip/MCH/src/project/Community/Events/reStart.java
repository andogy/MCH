package project.Community.Events;

import project.Community.Events.UPD.countTime;
import project.Community.Events.UPD.getJar;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class reStart {

    public static boolean restart() {
        try {
            FileWriter f = new FileWriter("C:\\.MCH\\start.bat");
            f.write("java -Xmx100M -Xms100M -jar " + getJar.getOldPath());
            f.close();
            Runtime.getRuntime().exec("cmd.exe /k C:\\.MCH\\start.bat");
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (countTime.startDUP_count) {
            File file1 = new File("C:\\.MCH\\UPD.cache");
            file1.delete();
        }

        System.exit(0);

        return true;
    }
}
