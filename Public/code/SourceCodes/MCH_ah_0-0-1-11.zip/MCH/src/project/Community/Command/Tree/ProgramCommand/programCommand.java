package project.Community.Command.Tree.ProgramCommand;

import project.Community.Command.Parsing;
import project.Community.Command.textLibrary.commandLibrary;
import project.resources.UI.Lang.language;

public class programCommand {
    public static void program() {
        Parsing.display = commandLibrary.exit_ + language.exi + "\n";
    }
}
