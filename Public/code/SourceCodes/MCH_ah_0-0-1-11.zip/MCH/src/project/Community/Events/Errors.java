package project.Community.Events;

import project.Community.Command.ini;
import project.Community.Times.times;
import project.resources.UI.MchUI;
import project.resources.UI.exit;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class Errors {
    public static JFrame jFrame = new JFrame();
    public static JTextArea jTextArea = new JTextArea();

    public static void errors(Exception e) {
        jFrame.setTitle("Error Now");
        jFrame.setSize(300,120);

        jFrame.add(jTextArea);

        jTextArea.setBounds(0,0,300,120);
        jTextArea.setEditable(false);

        jFrame.setResizable(false);

        //获得屏幕大小

        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

        exit.jFrame.setVisible(false);
        MchUI.jFrame.setVisible(false);
        MchUI.jFrame.setVisible(false);

        String er = Arrays.toString(e.getStackTrace()).replace("[","").replace("]","").replace(",","\n");

        if (er.contains("openClipboard")) {
            FileWriter fr = null;
            try {
                fr = new FileWriter(ini.path + "history.txt",false);
            } catch (IOException exception) {
                exception.printStackTrace();
            }
            try {
                fr.write("");
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        }

        System.out.println(er);

        try {
            FileWriter fw = new FileWriter(ini.path + "errors.log",true);
            fw.write("[" + times.format + "]\n" + er + "\n");
            fw.close();
        } catch (IOException exception) {
            exception.printStackTrace();
        }

        jFrame.setVisible(true);
    }

    public static void ClipBoardError() {

    }
}