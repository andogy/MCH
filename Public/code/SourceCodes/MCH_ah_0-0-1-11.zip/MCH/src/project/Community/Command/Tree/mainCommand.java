package project.Community.Command.Tree;

import project.Community.Command.Parsing;
import project.Community.Command.Tree.ProgramCommand.programCommand;
import project.Community.Command.Tree.Slash.slash;
import project.Community.Command.Tree.gameCommand.Gamemode.gameMode;
import project.Community.Command.textLibrary.commandLibrary;
import project.Community.Community;
import project.resources.UI.Lang.language;
import project.resources.UI.MchUI;

public class mainCommand {
    public static void parsingCommand(String command) {
//        如果有斜杠,列出所有命令
        if (command.equals("/")) {
            slash.slashEntry();
        } else {
//            如果没有则进行其他命令对比

//            点符号作为程序命令
            if (command.indexOf(".") != 0 && command.contains(".")) {
                if (Community.LangID == 0) {
                    Parsing.display = "无法找到\"" + MchUI.input_Command.getText() + "\"的相关指令或用法";
                } else if (Community.LangID == 1) {
                    Parsing.display = "Cannot Find usage for \"" + MchUI.input_Command.getText() + "\"";
                }
            } else if (command.indexOf(".") == 0) {

                if (commandLibrary.exit_.contains(command)) {
                    programCommand.program();
                }
            }

//            清除斜杠以同步直接输入
            command = command.replace("/", "");

//            下面基本都是匹配字符然后将display加上自己对应的命令,下面就不标注太多了

            /*
            用字库对比命令(判断字库中是否含有输入的字符),有则输出显示,没有则匹配提示(有的人可能从用法找而不是输入命令字段)
             */

//            用来判断是否显示命令
            boolean HasCommandDisplay = false;

//            匹配gamemode
            if (commandLibrary.gamemode.contains(command) || language.gamemode.contains(command)) {
                Parsing.display = Parsing.display + commandLibrary.gamemode + language.gamemode;
                HasCommandDisplay = true;
            }
//            匹配gamerule
            if (commandLibrary.gamerule.contains(command) || language.gamerule.contains(command)) {
                Parsing.display = Parsing.display + commandLibrary.gamerule + language.gamerule;
                HasCommandDisplay = true;
            }
//            匹配give
            if (commandLibrary.give.contains(command) || language.give.contains(command)) {
                Parsing.display = Parsing.display + commandLibrary.give + language.give;
                HasCommandDisplay = true;
            }

            if (!HasCommandDisplay) {
                if (Community.LangID == 0) {
                    Parsing.display = "无法找到\"" + MchUI.input_Command.getText() + "\"的相关指令或用法";
                } else if (Community.LangID == 1) {
                    Parsing.display = "Cannot Find usage for \"" + MchUI.input_Command.getText() + "\"";
                }
            }

//            以下为全匹配区域,全部符合命令的情况下,输入空格就转到命令分支提示

            /*
            匹配
             */

            String commandMain = "";
            if (command.contains(" ")) {
                commandMain = command.substring(0, command.indexOf(" ") + 1);
                command = command.substring(command.indexOf(" "));
            }

            if (commandMain.equals(commandLibrary.gamemode)) {
//                将命令的修饰给到分支处理
                gameMode.gamemode(command.replaceFirst(" ",""));
            }

        }
    }
}
