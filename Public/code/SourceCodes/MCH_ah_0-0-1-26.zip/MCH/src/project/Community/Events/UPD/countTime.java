package project.Community.Events.UPD;

import project.Community.Community;
import project.Community.UI.MenuUI;

public class countTime extends Thread {
    public static boolean startDUP_count = false;

    public void run() {
        long time_UPD = 0;

        while (true) {
            try {

                Thread.sleep(10);

                {
                    // UPD
                    if (startDUP_count) {
                        time_UPD++;

                        if (Community.LangID == 0) {
                            MenuUI.checkReturn.setText("尝试连接服务器:" + (double) time_UPD / 100 + "s");
                        } else if (Community.LangID == 1) {
                            MenuUI.checkReturn.setText("Connecting\ntry:" + (double) time_UPD / 100 + "s");
                        }

                        if (time_UPD > 700) {
                            cannotUPD_connectFail();
                            startDUP_count = false;
                        }
                    } else {
                        time_UPD = 0;
                    }
                }

            } catch (Exception ignored) {

            }
        }
    }

    public static void cannotUPD_connectFail() {
        if (Community.LangID == 0) {
            MenuUI.checkReturn.setText("连接服务器失败:\n连接超时\n\n请尝试重新连接或更换下载源");
        } else if (Community.LangID == 1) {
            MenuUI.checkReturn.setText("Connect Server Fail:\nTime out\n\nPlease switch source or try again");
        }
    }
}
