package project.Community.Events.mchDir;

import project.Community.Command.ini;
import project.Community.Community;
import project.Community.Events.Errors;
import project.Community.UI.MenuUI;

import java.awt.*;
import java.io.File;

public class dirSize extends Thread {
    public void run() {
        while (!Errors.CannotHandle) {

            try {
                Thread.sleep(50);

                long Size = 0;
                long updCacheSize = 0;
                File[] caches = new File(ini.path).listFiles();
                File[] UPD_caches = new File(ini.path + "cache\\").listFiles();
                try {
                    for (File f : caches) {
                        Thread.sleep(1);
//                            System.out.println(f.getName());
                        Size += f.length();
                    }

                    for (File f : UPD_caches) {
                        Thread.sleep(1);
//                            System.out.println(f.getName());
                        updCacheSize += f.length();
                        Size += f.length();
                    }
                } catch (Exception ignored) {

                }

                String str = String.valueOf(Size / 1024);
                String updStr = String.valueOf(updCacheSize / 1024);

                if (Community.LangID == 0) {
                    MenuUI.mchDirSize.setText("MCH文件占用: " + str + "KB      UPD缓存: " + updStr + "KB");
                } else if (Community.LangID == 1) {
                    MenuUI.mchDirSize.setText("MCH File Size: " + str + "KB      UPD cache: " + updStr + "KB");
                }

                if (Size / 1024 / 1024 > 150) {
                    MenuUI.mchDirSize.setForeground(new Color(181, 61, 58, 200));
                } else if (Size / 1024 / 1024 > 100) {
                    MenuUI.mchDirSize.setForeground(new Color(240, 167, 50, 200));
                } else {
                    MenuUI.mchDirSize.setForeground(new Color(73, 165, 84, 200));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
