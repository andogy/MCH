package project.Community.UI;

import project.Community.Events.Events;

import javax.swing.*;
import java.awt.*;

public class MenuUI2 {
    public static JFrame jFrame = new JFrame();
    public static JPanel c1 = new JPanel();
    static Container c2 = new Container();

    public static JLabel saveCacheOrNot = new JLabel();
    public static JButton saveCache = new JButton();
    public static JButton notSaveCache = new JButton();

    public MenuUI2() {
        UI();
    }

    public static void UI() {

        //        窗口初始化设置
        //获得屏幕大小
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

        jFrame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        jFrame.setSize(650, 350);

        jFrame.setResizable(false);

        {

            c1.add(saveCacheOrNot);
            c1.add(saveCache);
            c1.add(notSaveCache);




            c1.setLayout(new LayoutManager() {
                @Override
                public void addLayoutComponent(String name, Component comp) {
                }

                @Override
                public void removeLayoutComponent(Component comp) {
                }

                @Override
                public Dimension preferredLayoutSize(Container parent) {
                    return null;
                }

                @Override
                public Dimension minimumLayoutSize(Container parent) {
                    return null;
                }

                @Override
                public void layoutContainer(Container parent) {
                    saveCacheOrNot.setBounds(0, 5, 80, 30);

                    saveCache.setBounds(80,5,80,30);
                    notSaveCache.setBounds(170,5,80,30);
                }
            });

            saveCache.addActionListener(e -> Events.switchCacheProcess(true));
            notSaveCache.addActionListener(e -> Events.switchCacheProcess(false));
        }


        jFrame.setContentPane(c1);

        jFrame.setVisible(false);
    }
}
