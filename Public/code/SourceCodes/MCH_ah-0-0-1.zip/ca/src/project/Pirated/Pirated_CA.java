package project.Pirated;

public class Pirated_CA {
    public static void main(String[] args) {

    }
}
