package project.Community.Events.mchDir;

import project.Community.Command.ini;
import project.Community.Community;
import project.Community.Events.Errors;
import project.Community.Events.filesOperator;
import project.Community.UI.MenuUI;

import java.awt.*;
import java.io.File;

public class dirSize extends Thread {

    @Override
    public void run() {
        while (!Errors.CannotHandle) {
            if (!Community.isDaemons) {

                try {
                    Thread.sleep(100);

                    File[] caches = new File(ini.path).listFiles();
                    File[] UPD_caches = new File(ini.path + "save\\").listFiles();
                    long Size = filesOperator.ReadFiles(caches);
                    long updCacheSize = filesOperator.ReadFiles(UPD_caches);
                    //                try {
                    //                    for (File f : caches) {
                    //                        Thread.sleep(1);
                    ////                            System.out.println(f.getName());
                    //                        Size += f.length();
                    //                    }
                    //
                    //                    for (File f : UPD_caches) {
                    //                        Thread.sleep(1);
                    ////                            System.out.println(f.getName());
                    //                        updCacheSize += f.length();
                    //                        Size += f.length();
                    //                    }
                    //                } catch (Exception ignored) {
                    //
                    //                }

                    //                String str = String.valueOf(Size / 1024);
                    //                String updStr = String.valueOf(updCacheSize / 1024);

                    if (Community.LangID == 0) {
                        MenuUI.mchDirSize.setText("MCH文件占用: " + Size / 1024 + "KB         缓存: " + updCacheSize / 1024 + "KB");
                    } else if (Community.LangID == 1) {
                        MenuUI.mchDirSize.setText("MCH File Size: " + Size / 1024 + "KB          cache: " + updCacheSize / 1024 + "KB");
                    }

                    if (Size / 1024 / 1024 > 150) {
                        MenuUI.mchDirSize.setForeground(new Color(181, 61, 58, 200));
                    } else if (Size / 1024 / 1024 > 100) {
                        MenuUI.mchDirSize.setForeground(new Color(240, 167, 50, 200));
                    } else {
                        MenuUI.mchDirSize.setForeground(new Color(73, 165, 84, 200));
                    }

                    //                System.gc();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
