package test.zip;

import java.math.BigDecimal;
import java.util.zip.ZipException;

public class zipThread3 extends Thread{
    public void run() {
        BigDecimal bigDecimal = BigDecimal.valueOf(19999);
        try {
            password.Unzip4j1("G:\\Code-Java\\MCH\\test.zip",bigDecimal , 10000,"2");
        } catch (ZipException e) {
            e.printStackTrace();
        }
    }
}
