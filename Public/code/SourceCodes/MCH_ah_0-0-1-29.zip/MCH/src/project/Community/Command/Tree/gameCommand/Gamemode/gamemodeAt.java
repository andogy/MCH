package project.Community.Command.Tree.gameCommand.Gamemode;

import project.Community.Command.Parsing;
import project.Community.Command.Tree.gameCommand.Selector.selector;
import project.Community.Community;
import project.Community.UI.Lang.language;
import project.Community.UI.MchUI;

public class gamemodeAt {
    public static void gamemode_at(String At) {
        try {
            if (At.equals("") || At.equals("@")) {
                Parsing.display = "@a" + language.Ata + "\n" +
                        "@e" + language.Ate + "\n" +
                        "@p" + language.Atp + "\n" +
                        "@r" + language.Atr + "\n" +
                        "@s" + language.Ats + "\n";
            } else {
//            if (!(At.indexOf("@") == 0)) {
//                if (Community.LangID == 0) {
//                    Parsing.display = "此处必须以\"@\"起头";
//                } else if (Community.LangID == 1) {
//                    Parsing.display = "You Must Start With \"@\" Here";
//                }
//            } else {

//                判断字符长度是否为2
                if (!At.contains(" ") & At.indexOf("[") != 1 & At.indexOf("[") != 2) {
                    if (!(At.indexOf("\\") == 0)) {

                        boolean HasThisSelector = false;

                        if (language.Ata.contains(At)) {
                            Parsing.display = "@a" + language.Ata + "\n";
                            HasThisSelector = true;
                        }

                        if (language.Ate.contains(At)) {
                            Parsing.display = Parsing.display + "@e" + language.Ate + "\n";
                            HasThisSelector = true;
                        }

                        if (language.Atp.contains(At)) {
                            Parsing.display = Parsing.display + "@p" + language.Atp + "\n";
                            HasThisSelector = true;
                        }

                        if (language.Atr.contains(At)) {
                            Parsing.display = Parsing.display + "@r" + language.Atr + "\n";
                            HasThisSelector = true;
                        }

                        if (language.Ats.contains(At)) {
                            Parsing.display = Parsing.display + "@s" + language.Ats + "\n";
                            HasThisSelector = true;
                        }

                        if ("@a".contains(At)) {
                            Parsing.display = "@a" + language.Ata + "\n";
                            HasThisSelector = true;
                        }
                        if ("@e".contains(At)) {
                            Parsing.display = "@e" + language.Ate + "\n";
                            HasThisSelector = true;
                        }
                        if ("@p".contains(At)) {
                            Parsing.display = "@p" + language.Atp + "\n";
                            HasThisSelector = true;
                        }
                        if ("@r".contains(At)) {
                            Parsing.display = "@r" + language.Atr + "\n";
                            HasThisSelector = true;
                        }
                        if ("@s".contains(At)) {
                            Parsing.display = "@s" + language.Ats + "\n";
                            HasThisSelector = true;
                        }

                        if (!HasThisSelector) {
                            if (Community.LangID == 0) {
                                Parsing.display = "无法为\"" + At + "\"匹配到可用选择器\n" +
                                        "如果此处要使用精确玩家名,请在最前面加上反斜杠(\\)进行表达";
                            } else if (Community.LangID == 1) {
                                Parsing.display = "Cannot matching Selector for \"" + At + "\"\n" +
                                        "if used Player's full Name,Please Start with \"\\\"";
                            }
                        }
                    } else {
                        Parsing.display = At.replace("\\", "");
                    }
                } else {

                    if (!At.contains("\\")) {
//                    如果长度不为2,则判断是否是插入参数的符号
                        if (At.indexOf(" ") <= 3) {
                            At = At.replaceFirst(" ", "");
                        }
                        if (At.substring(2).indexOf("[") == 0) {
                            if (At.contains("]")) {
                                if (Community.LangID == 0) {
                                    Parsing.display = "命令已结束";
                                } else if (Community.LangID == 1) {
                                    Parsing.display = "Command Over";
                                }

                                MchUI.tips.setText("");

                                if (!At.substring(At.indexOf("]")).equals("") || !At.substring(At.indexOf("]")).equals(" ")) {
                                    if (At.substring(At.indexOf("]")).length() >= 2) {
                                        if (Community.LangID == 0) {
                                            Parsing.display = "\"" + At.substring(At.indexOf("]") + 1) + "\"是多余的";
                                        } else if (Community.LangID == 1) {
                                            Parsing.display = "\"" + At.substring(At.indexOf("]") + 1) + "\" is redundant";
                                        }
                                    }
                                }
                            }
                            selector.select(At.substring(At.indexOf("[")));
                        } else {
//                        如果不是插入参数,则提示错误
                            Parsing.display = "此处只能选择输入参数或者结束命令";
                        }
//                }
                    } else {
                        Parsing.display = "Name:\n" + At.replace("\\", "");
                        if (Community.LangID == 0) {
                            MchUI.tips.setText("gamemode <模式> <玩家ID>");
                        } else if (Community.LangID == 1) {
                            MchUI.tips.setText("gamemode <mode> <PlayerID>");
                        }

                        if (At.contains("[")) {
                            if (Community.LangID == 0) {
                                MchUI.command1.setText("使用精确玩家名时不可以用选择器参数");
                            } else if (Community.LangID == 1) {
                                MchUI.tips.setText("Selector Parameters Are not Allowed when Using exact Player ID");
                            }
                        }

                        if (At.contains(" ")) {
                            if (Community.LangID == 0) {
                                Parsing.display = "命令已结束\n" +
                                        "结束于:  \"" + At + "\"←";
                            } else if (Community.LangID == 1) {
                                Parsing.display = "Command ended\n" +
                                        "End At:  \"" + At + "\"←";
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) { }
    }
}
