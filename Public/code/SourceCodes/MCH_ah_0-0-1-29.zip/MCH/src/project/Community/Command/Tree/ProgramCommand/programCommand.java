package project.Community.Command.Tree.ProgramCommand;

import project.Community.Command.Parsing;
import project.Community.UI.Lang.language;

public class programCommand {
    public static void program(String command) {
        try {
            if (".exit".contains(command)) {
                Parsing.display = ".exit" + language.exi;
            }
            if (".function".contains(command)) {
                Parsing.display = Parsing.display + ".function" + language.functionEdit;
            }

            if (command.contains(" ")) {
                if (command.substring(0, command.indexOf(" ")).equals(".function")) {
                    if (".function on".contains(command)) {
                        Parsing.display = "on    *开启\n";
                    }
                    if (".function off".contains(command)) {
                        Parsing.display = Parsing.display + "off    *关闭";
                    }
                }
            }
        } catch (Exception ignored) {

        }
    }
}
