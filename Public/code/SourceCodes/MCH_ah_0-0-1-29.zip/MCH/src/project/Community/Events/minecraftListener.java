package project.Community.Events;

import project.Community.Community;
import project.Community.UI.Launcher;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class minecraftListener extends Thread {
    @Override
    public void run() {
        Runtime r = Runtime.getRuntime();
        while (true) {
            try {
                Process p = r.exec("cmd.exe /c tasklist");
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));

                String s = "";
                String all = "";
                while ((s = br.readLine()) != null) {

                    s = s.toLowerCase();

                    all += s + "\n";

                    String displayString = "";
                    displayString = "Minecraft状态\n\n";

                    if (s.contains("minecraft.windows.exe")) {
                        String s1;
                        int c = 0;
                        while (s.contains(" ")) {
                            c++;
                            s1 = s.substring(0, s.indexOf(" "));

                            s = s.substring(s.indexOf(" "));
                            while (s.substring(0, 1).contains(" ")) {
                                s = s.replaceFirst(" ", "");
                            }

                            if (Community.LangID == 0) {
                                switch (c) {
                                    case 1: {
                                        displayString += "软件包名: " + s1 + "\n";
                                        break;
                                    }
                                    case 2: {
                                        displayString += "PID: " + s1 + "\n";
                                        break;
                                    }
                                    case 5: {
                                        displayString += "占用内存: " + s1 + " KB\n";
                                        break;
                                    }
                                }
                            } else {
                                displayString = "Minecraft status\n\n";
                                switch (c) {
                                    case 1: {
                                        displayString += "minecraft name: " + s1 + "\n";
                                        break;
                                    }
                                    case 2: {
                                        displayString += "PID: " + s1 + "\n";
                                        break;
                                    }
                                    case 5: {
                                        displayString += "minecraft ram: " + s1 + "kb\n";
                                        break;
                                    }
                                }
                            }

                            Launcher.McBeStatus.setText(displayString);

                            if (c >= 5) {
                                break;
                            }
                        }
                    }
                }

                if (!all.contains("minecraft.windows.exe")) {
                    if (Community.LangID == 0) {
                        Launcher.McBeStatus.setText("Minecraft基岩版未在运行");
                    } else if (Community.LangID == 1) {
                        Launcher.McBeStatus.setText("Minecraft Bedrock Edition is not running");
                    }
                }

                System.gc();

                Thread.sleep(100);
                if (Errors.CannotHandle) {
                    break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
