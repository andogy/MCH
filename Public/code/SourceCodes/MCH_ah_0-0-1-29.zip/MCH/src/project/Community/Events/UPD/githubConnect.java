package project.Community.Events.UPD;

import project.Community.Community;
import project.Community.UI.MenuUI;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class githubConnect {
    public static void writeHosts() {
        String hosts = "C:\\Windows\\System32\\drivers\\etc\\hosts";
        FileWriter fileWriter = null;
        try {
            BufferedReader bf = new BufferedReader(new FileReader(hosts));

            String s;
            StringBuilder all = new StringBuilder();
            while ((s = bf.readLine()) != null) {
                all.append(s).append("\n");
            }

            if (!all.toString().contains("199.232.68.133  raw.githubusercontent.com")) {
                if (Community.LangID == 0) {
                    MenuUI.checkReturn.setText("尝试添加Hosts中");
                } else {
                    MenuUI.checkReturn.setText("trying add Hosts");
                }
                fileWriter = new FileWriter(hosts,true);
                fileWriter.write("\n199.232.68.133  raw.githubusercontent.com");
                fileWriter.close();
                Thread.sleep(1500);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
