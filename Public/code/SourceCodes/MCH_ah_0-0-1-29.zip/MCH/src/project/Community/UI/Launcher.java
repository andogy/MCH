package project.Community.UI;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Launcher {
    public static JFrame jFrame = new JFrame();

    public static JLabel McBe = new JLabel();

    public static JButton turnOnMcBe = new JButton();
    public static JButton turnOffMcBe = new JButton();

    public static JTextArea McBeStatus = new JTextArea();

    public Launcher() {
        McBeStatus.setEditable(false);

        jFrame.setSize(640, 360);
        jFrame.setResizable(false);

        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        jFrame.setLocation(width / 2 - jFrame.getWidth() / 2, height / 2 - jFrame.getHeight() / 2);

        jFrame.setLayout(new LayoutManager() {
            @Override
            public void addLayoutComponent(String name, Component comp) { }
            @Override
            public void removeLayoutComponent(Component comp) { }
            @Override
            public Dimension preferredLayoutSize(Container parent) { return null; }
            @Override
            public Dimension minimumLayoutSize(Container parent) { return null; }

            @Override
            public void layoutContainer(Container parent) {
                McBe.setBounds(5,5,80,30);
                turnOnMcBe.setBounds(85,5,80,30);
                turnOffMcBe.setBounds(175,5,80,30);
                McBeStatus.setBounds(5,jFrame.getHeight() - 200,250,150);
            }
        });

        jFrame.add(McBe);
        jFrame.add(turnOnMcBe);
        jFrame.add(turnOffMcBe);
        jFrame.add(McBeStatus);

        turnOnMcBe.addActionListener(e -> {
            try {
                Runtime.getRuntime().exec("cmd.exe /k start minecraft:");
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        });

        turnOffMcBe.addActionListener(e -> {
            try {
                Runtime.getRuntime().exec("cmd.exe /k taskkill /f /im minecraft.windows.exe");
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        });

        jFrame.setVisible(true);
    }
}
