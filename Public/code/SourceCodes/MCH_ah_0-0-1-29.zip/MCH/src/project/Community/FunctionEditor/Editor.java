package project.Community.FunctionEditor;

import javax.swing.*;
import java.awt.*;

public class Editor {
    public static JTextArea jTextArea = new JTextArea();
    public static JFrame jFrame = new JFrame("FunctionEditor");

    public Editor() {
        {
            //        窗口初始化设置
            //获得屏幕大小
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            Dimension screenSize = toolkit.getScreenSize();
            int width = screenSize.width;
            int height = screenSize.height;

            //设置窗口位置
            jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

            jFrame.setSize(500,300);
        }
        LayoutManager layoutManager = new LayoutManager() {
            @Override
            public void addLayoutComponent(String name, Component comp) {
            }
            @Override
            public void removeLayoutComponent(Component comp) {
            }
            @Override
            public Dimension preferredLayoutSize(Container parent) {
                return null;
            }
            @Override
            public Dimension minimumLayoutSize(Container parent) {
                return null;
            }

            @Override
            public void layoutContainer(Container parent) {
                int Height = jFrame.getHeight();
                int Width = jFrame.getWidth();

                jTextArea.setBounds(0,0,Width - (Width / 3),Height);
            }
        };

        jFrame.setLayout(layoutManager);

        jFrame.add(jTextArea);

        jFrame.setVisible(false);
    }
}
