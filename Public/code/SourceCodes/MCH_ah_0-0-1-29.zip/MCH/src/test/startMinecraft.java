package test;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class startMinecraft {
    public static void main(String[] args) {
        try {

            Runtime r = Runtime.getRuntime();

            Process p = r.exec("cmd /c tasklist");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String s;
            while ((s = br.readLine()) != null) {
                s = s.toLowerCase();
                System.out.println(s);
                if (s.contains("minecraft.windows.exe")) {
                    System.out.println("MC is Running");
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}