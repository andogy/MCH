package project.resources.UI;

import project.Community.EXIT;
import project.Community.Events.Events;
import project.resources.UI.Color.colors;

import javax.swing.*;
import java.awt.*;

public class CaUI {
    public static int ColorID = 0;

    public CaUI() {
        caUI();
    }

    public static JFrame jFrame = new JFrame();
    public static JTextArea input_Command = new JTextArea();
    public static JButton copy_Command = new JButton();

    public static void caUI() {
//        引入退出类
        new EXIT();

        new colors().start();

//        窗口初始化设置
        //获得屏幕大小
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

        //设置退出时不响应操作,因为要使用自定义退出事件
        jFrame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

        //设置窗口大小和颜色
        jFrame.setSize(500, 300);
        jFrame.getContentPane().setBackground(Color.white);

        //显示窗口
        jFrame.setVisible(true);

        LayoutManager layoutManager = new LayoutManager() {
            @Override
            public void addLayoutComponent(String name, Component comp) {
            }
            @Override
            public void removeLayoutComponent(Component comp) {
            }
            @Override
            public Dimension preferredLayoutSize(Container parent) {
                return null;
            }
            @Override
            public Dimension minimumLayoutSize(Container parent) {
                return null;
            }

            @Override
            public void layoutContainer(Container parent) {
                int Height = jFrame.getHeight();
                int Width = jFrame.getWidth();

                input_Command.setBounds(10, Height - 60, Width - 100, 15);
                copy_Command.setBounds(Width - 100 + 20,Height - 60,50,15);
            }
        };

        jFrame.setLayout(layoutManager);

        jFrame.add(input_Command);
        jFrame.add(copy_Command);

        copy_Command.addActionListener(e -> Events.Copy());
    }
}
