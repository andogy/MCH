package project.resources.UI.Color;

import project.resources.UI.CaUI;

import java.awt.*;

public class colors extends Thread{
    public void run() {
        while (true) {
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (CaUI.ColorID == 0) {
                CaUI.input_Command.setBackground(new Color(214, 214, 214));
            }

        }
    }
}
