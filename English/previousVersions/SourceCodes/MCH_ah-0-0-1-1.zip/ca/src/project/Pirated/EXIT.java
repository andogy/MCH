package project.Pirated;

import project.resources.UI.CaUI;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class EXIT {
    public EXIT() {
        Exit();
    }

    public static void Exit() {
        CaUI.jFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.out.println("PPPPP");

                System.exit(1);
            }
        });
    }
}
