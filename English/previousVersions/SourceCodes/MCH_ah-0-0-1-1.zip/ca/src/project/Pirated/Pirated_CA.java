package project.Pirated;

import project.resources.UI.CaUI;

public class Pirated_CA {
    public static void main(String[] args) {
        /*
        预加载部分
         */

//        显示UI
        CaUI.caUI();

        /*
        指令处理部分
         */
    }
}
