package project.resources.UI;

import project.Pirated.EXIT;

import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class CaUI {

    public static JFrame jFrame = new JFrame();

    public static void caUI() {
//        引入退出类
        new EXIT();

//        窗口初始化设置
        {
            jFrame.setVisible(true);

            Scanner scanner = new Scanner(System.in);
            String str = scanner.next();

            //        获得屏幕大小
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            Dimension screenSize = toolkit.getScreenSize();
            int width = screenSize.width;
            int height = screenSize.height;

            //        设置窗口位置
            jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

            //        设置退出时不响应操作,因为要使用自定义退出事件
            jFrame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        }

        //设置窗口大小
        jFrame.setSize(500, 300);
    }
}
