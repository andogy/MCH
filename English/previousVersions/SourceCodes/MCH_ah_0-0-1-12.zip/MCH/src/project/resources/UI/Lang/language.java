package project.resources.UI.Lang;

import project.Community.Command.ini;
import project.Community.Community;
import project.Community.Events.Errors;
import project.Community.Events.LoadAssembly;
import project.Community.Times.times;
import project.resources.UI.MchUI;
import project.resources.UI.MenuUI;
import project.resources.UI.exit;

public class language extends Thread {
    public static String gamemode = "";
    public static String gamerule = "";
    public static String give = "";
    public static String exi = "";
    public static String guess = "";
    public static String Ata = "";
    public static String Ate = "";
    public static String Ats = "'";
    public static String Atr = "";
    public static String Atp = "";
    public static String ver = "0-0-1-12(ah-12)";
    public static String x = "";
    public static String y = "";
    public static String z = "";
    public static String relative = "";

    @Override
    public void run() {
        System.out.println("[" + times.format + "]\n" + "language:语言就绪");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadSucceed: language\n");
        while (true) {
            if (Errors.CannotHandle) {
                break;
            }
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Language();
        }
    }

    public static void Language() {

//            ID=0为中文
        if (Community.LangID == 0) {
            MchUI.menu.setText("菜单");
            MchUI.jFrame.setTitle("Minecraft命令助手");

            MenuUI.jFrame.setTitle("菜单页");

            gamemode = "    *设定游戏模式\n";
            gamerule = "    *设定游戏规则\n";
            give = "    *给予玩家物品\n";

            exi = "*退出程序\n";

            guess = "是否想输入:";

            Ata = "    *所有玩家";
            Ate = "    *所有实体";
            Atp = "    *距离最近的玩家";
            Atr = "    *随机玩家";
            Ats = "    *执行命令的实体";

            x = "    *x坐标(需要与r或dx、dy、dz之类配合使用)";
            y = "    *y坐标(需要与r或dx、dy、dz之类配合使用)";
            z = "    *z坐标(需要与r或dx、dy、dz之类配合使用)";

            relative = "    *相对坐标";

            exit.jTextArea.setText("\".exit\"是一个在此程序中用于退出的命令,并非游戏内指令\n是否要继续退出?");
            exit.buttonEXIT.setText("退出");
            exit.buttonEXITNot.setText("不退出");

            MenuUI.PATH.setText("配置路径:  " + ini.path);
            MenuUI.exButton.setText("按下退出按钮会:");
            MenuUI.exButtonExit.setText("退出MCH");
            MenuUI.exButtonNarrow.setText("缩小UI");
            MenuUI.Problem.setText("随机问题:");
            MenuUI.randomProblem.setText("试试看");
            MenuUI.Color.setText("颜色:");
            MenuUI.Black.setText("黑色");
            MenuUI.White.setText("白色");
            MenuUI.Language.setText("语言:");
            MenuUI.Chinese.setText("中文");
            MenuUI.English.setText("英文");
            MenuUI.fastLoad.setText("快速加载:");
            MenuUI.fastLoadNo.setText("禁用");
            MenuUI.fastLoadYes.setText("启用");
            MenuUI.fastLoadWarning.setText("注意:\n" +
                    "开启快速加载可以大幅增加加载速度\n" +
                    "但可能会导致内存出现不可控的增加\n" +
                    "(此问题在ah-12版本已优化,但占用可能也不低于300M)\n" +
                    "如果历史文件不大,开启和不开启时的内存占用相差不大");
            MenuUI.Ver.setText("版本: " + ver);

            if (Errors.CannotHandle) {
                Errors.jTextArea.setText("MCH遇到了一个无法自动处理的错误\n" +
                        "如果你需要继续使用MCH\n" +
                        "请关闭此窗口后将其重新启动\n" +
                        "你可以去到MCH的目录查看错误信息");
            }
        } else if (Community.LangID == 1) {
            //英文
            MchUI.menu.setText("Menus");
            MchUI.jFrame.setTitle("Minecraft Command Helper");

            MenuUI.jFrame.setTitle("Menu");

            gamemode = "    *set-gamemode\n";
            gamerule = "    *set-gamerules\n";
            give = "    *give-players-item\n";

            exi = "*Exit-Command-Helper\n";

            guess = "Guess You Want Entry:";

            Ata = "    *all-players";
            Ate = "    *all-entities";
            Atp = "    *the-closest-player";
            Atr = "    *random-player";
            Ats = "    *entity-of-run-command";

            x = "    *x-coordinates(Need To Be Used With r Or dx, dy, dz, etc)";
            y = "    *y-coordinates(Need To Be Used With r Or dx, dy, dz, etc)";
            z = "    *z-coordinates(Need To Be Used With r Or dx, dy, dz, etc)";

            relative = "    *Relative coordinates";

            exit.jTextArea.setText("\".exit\" is a command used by this program to exit,This not an in-game command \nDo you want to continue to exit");
            exit.buttonEXIT.setText("Exit");
            exit.buttonEXITNot.setText("Exit Not");

            MenuUI.PATH.setText("Config path:  " + ini.path);
            MenuUI.exButton.setText("click exit button will do: ");
            MenuUI.exButtonExit.setText("Exit MCH");
            MenuUI.exButtonNarrow.setText("Reduce UI");
            MenuUI.Problem.setText("Random Problem:");
            MenuUI.randomProblem.setText("Try");
            MenuUI.Color.setText("Color:");
            MenuUI.Black.setText("Black");
            MenuUI.White.setText("White");
            MenuUI.Language.setText("Language:");
            MenuUI.Chinese.setText("Chinese");
            MenuUI.English.setText("English");
            MenuUI.fastLoad.setText("Fast Load:");
            MenuUI.fastLoadNo.setText("Disable");
            MenuUI.fastLoadYes.setText("Enable");
            MenuUI.fastLoadWarning.setText("Be Careful:\n" +
                    "Turn on Fast Load can Greatly increase The Lading Speed\n" +
                    "But it may lead to uncontrollable increase of memory\n" +
                    "(ah-12 Version has optimized this ,But Maybe cannot Below 300M)\n" +
                    "if History File large not,Memory use Not Make Much Difference");
            MenuUI.Ver.setText("Version: " + ver);

            if (Errors.CannotHandle) {
                Errors.jTextArea.setText("There are some unhandled errors in the MCH\n" +
                        "if You need To Continue To Use it\n" +
                        "Please Close MCH and Open it Again\n" +
                        "\n" +
                        "You can go to the MCH directory to look the error info");
            }
        }
    }
}
