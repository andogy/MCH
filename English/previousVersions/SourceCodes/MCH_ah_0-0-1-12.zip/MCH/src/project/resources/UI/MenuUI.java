package project.resources.UI;

import project.Community.Command.ini;
import project.Community.Events.Events;

import javax.swing.*;
import java.awt.*;

public class MenuUI {
    public static JLabel PATH = new JLabel();
    public static JFrame jFrame = new JFrame();

    public static boolean OpenMenu = false;

    public static JLabel Color = new JLabel();
    public static JButton Black = new JButton();
    public static JButton White = new JButton();
    public static JButton User_Color = new JButton();

    public static JLabel exButton = new JLabel();
    public static JButton exButtonExit = new JButton();
    public static JButton exButtonNarrow = new JButton();

    public static JLabel Problem = new JLabel();
    public static JButton randomProblem = new JButton();

    public static JLabel Language = new JLabel();
    public static JButton Chinese = new JButton();
    public static JButton English = new JButton();

    public static JTextArea fastLoadWarning = new JTextArea();
    public static JLabel fastLoad = new JLabel();
    public static JButton fastLoadYes = new JButton();
    public static JButton fastLoadNo = new JButton();

    public static JLabel Ver = new JLabel();

    public MenuUI() {
        OpenMenu = true;
        menuUI();
    }

    public static void menuUI() {

        if (ini.iniHas) {

            OpenMenu = false;

            //        窗口初始化设置
            //获得屏幕大小
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            Dimension screenSize = toolkit.getScreenSize();
            int width = screenSize.width;
            int height = screenSize.height;

            //设置窗口位置
            jFrame.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

            jFrame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

            //显示窗口
            jFrame.setVisible(true);

            LayoutManager layoutManager = new LayoutManager() {
                @Override
                public void addLayoutComponent(String name, Component comp) {
                }

                @Override
                public void removeLayoutComponent(Component comp) {
                }

                @Override
                public Dimension preferredLayoutSize(Container parent) {
                    return null;
                }

                @Override
                public Dimension minimumLayoutSize(Container parent) {
                    return null;
                }

                @Override
                public void layoutContainer(Container parent) {
                    PATH.setBounds(0, 0, 150, 30);
                    Ver.setBounds(160,0,150,30);

                    Color.setBounds(0, 35, 40, 30);
                    Black.setBounds(60, 35, 80, 30);
                    White.setBounds(60 + 80 + 10, 35, 80, 30);

                    fastLoad.setBounds(260 ,35,60,30);
                    fastLoadYes.setBounds(270 + 60 + 10,35,80,30);
                    fastLoadNo.setBounds(270 + 60 + 10 + 80 + 10,35,80,30);
                    fastLoadWarning.setBounds(260,70,350,90);

                    Language.setBounds(0, 40 + 35, 60, 30);
                    Chinese.setBounds(60, 35 + 40, 80, 30);
                    English.setBounds(60 + 80 + 10, 35 + 40, 80, 30);

                    exButton.setBounds(0, 40 + 35 + 30, 200, 30);
                    exButtonExit.setBounds(0, 40 + 35 + 30 + 30, 100, 30);
                    exButtonNarrow.setBounds(100 + 10,40 + 35 + 30 + 30,100,30);

                    Problem.setBounds(0, 40 + 35 + 100, 110, 30);
                    randomProblem.setBounds(0, 40 + 35 + 100 + 30, 80, 30);
                }
            };

            jFrame.setLayout(layoutManager);

            jFrame.setSize(640, 300);
            jFrame.setResizable(false);

            jFrame.add(PATH);
            jFrame.add(Ver);
            jFrame.add(Problem);
            jFrame.add(randomProblem);
            jFrame.add(Color);
            jFrame.add(Black);
            jFrame.add(White);
            jFrame.add(Language);
            jFrame.add(Chinese);
            jFrame.add(English);
            jFrame.add(exButton);
            jFrame.add(exButtonExit);
            jFrame.add(exButtonNarrow);
            jFrame.add(fastLoad);
            jFrame.add(fastLoadYes);
            jFrame.add(fastLoadNo);
            jFrame.add(fastLoadWarning);

            fastLoadWarning.setEditable(false);

            Black.addActionListener(e -> Events.switchColor(1));
            White.addActionListener(e -> Events.switchColor(0));

            Chinese.addActionListener(e -> Events.switchLanguage(0));
            English.addActionListener(e -> Events.switchLanguage(1));

            exButtonNarrow.addActionListener(e -> Events.switchExButtonWillExit(false));
            exButtonExit.addActionListener(e -> Events.switchExButtonWillExit(true));

            fastLoadYes.addActionListener(e -> Events.switchFastLoad(true));
            fastLoadNo.addActionListener(e -> Events.switchFastLoad(false));
        }
    }
}
