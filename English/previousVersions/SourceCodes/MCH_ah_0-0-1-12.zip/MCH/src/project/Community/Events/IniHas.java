package project.Community.Events;

import project.Community.Command.*;
import project.resources.UI.*;

import java.io.FileReader;

public class IniHas extends Thread{
  public void run() {
      while (true) {
          if (Errors.CannotHandle) {
              break;
          }
          try {
              Thread.sleep(200);
              FileReader file = new FileReader(ini.path + ini.sets);
          } catch (Exception e) {
              MenuUI.jFrame.setVisible(false);
          }
      }
  }
}
