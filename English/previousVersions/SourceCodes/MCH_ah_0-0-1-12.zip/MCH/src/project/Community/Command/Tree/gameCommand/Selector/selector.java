package project.Community.Command.Tree.gameCommand.Selector;

import project.Community.Command.Parsing;
import project.Community.Command.textLibrary.commandLibrary;
import project.resources.UI.Lang.language;
import project.resources.UI.MchUI;

public class selector {
    public static String tip = "";

    public static void select(String Select) {
//        去除空格方便进行处理
        Select = Select.replace(" ", "");
        if (Select.contains(",")) {
            tip = Select.substring(Select.lastIndexOf(",")).replace(",", "");
        } else {
            tip = Select.replace("[", "");
        }
        System.out.println(tip);

//        将多余的符号变为一个
        if (Select.contains("[[") || Select.contains("!!") || Select.contains("]]")) {
            String slash = MchUI.input_Command.getText().replace("[[", "[").replace("!!", "!").replace("]]", "]");
            MchUI.input_Command.setText(slash);
        }

//        匹配结束选择器参数的符号
        if (!tip.contains("]")) {
//            匹配不到则进行选择器参数符号匹配
            if (tip.equals("")) {
                {
                    if (!Select.contains("x=")) {
                        Parsing.display = Parsing.display + commandLibrary.x + language.x + "\n";
                    }
                    if (!Select.contains("y=")) {
                        Parsing.display = Parsing.display + commandLibrary.y + language.y + "\n";
                    }
                }
            } else {
                if (tip.equals("x")) {
                    Parsing.display = commandLibrary.x + language.x;
                } else if (tip.contains("x=")) {
                    Parsing.display = "~" + language.relative + "\nPrecise coordinates(精确坐标)";
                    if (tip.equals("x=~")) {
                        Parsing.display = "~" + language.relative;
                    }
                }

                if (tip.equals("y")) {
                    Parsing.display =  commandLibrary.y + language.y;
                }
            }
        }
    }
}
