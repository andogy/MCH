package project.Community.Events;

import project.Community.Command.ini;

import java.io.FileWriter;
import java.io.IOException;

public class LoadAssembly {
    public static FileWriter fr;

    static {
        try {
            fr = new FileWriter(ini.path + "run.log",true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void loadAssembly(String Assembly) {
        try {
            fr.write(Assembly);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fr.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
