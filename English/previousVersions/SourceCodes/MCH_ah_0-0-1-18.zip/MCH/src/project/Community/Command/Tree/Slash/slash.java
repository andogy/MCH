package project.Community.Command.Tree.Slash;

import project.Community.Command.Parsing;
import project.Community.Command.textLibrary.commandLibrary;
import project.Community.UI.Lang.language;

public class slash {
    public static void slashEntry() {
        Parsing.display = commandLibrary.gamemode + language.gamemode + commandLibrary.gamerule + language.gamerule + "give" + language.give;
    }
}
