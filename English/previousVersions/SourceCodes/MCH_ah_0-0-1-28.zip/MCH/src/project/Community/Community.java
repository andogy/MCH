package project.Community;

import project.Community.Command.ini;
import project.Community.Events.KeyListener.listener;
import project.Community.Events.LoadAssembly;
import project.Community.Events.UPD.URLs;
import project.Community.Events.UPD.countTime;
import project.Community.Events.filesHas;
import project.Community.Events.historyReader;
import project.Community.Events.mchDir.dirSize;
import project.Community.FunctionEditor.Editor;
import project.Community.Times.times;
import project.Community.UI.Color.colors;
import project.Community.UI.MchUI;
import project.Community.UI.MenuUI;
import project.Community.UI.exit;

import java.io.File;


public class Community {

    public static int ColorID = 0;
    public static int LangID = 0;
    public static boolean exitButtonWillExit = true;
    public static boolean fastLoad = false;
    public static boolean onTop = false;

    public static boolean canUPD = false;

    public static int commandLength = 0;
    public static int nowPoint = 0;

    public static boolean functionEditing = false;

    public static boolean updFromGithub = false;

    public static boolean saveCache = false;

    public static String UPD_ID = "133";
    public static String verID = "111550100128";
    public static String ver = "0-0-1-28(ah-28)";

    public static void main(String[] args) {
        times.Times();
        new times().start();

        File f = new File(ini.path);
        f.mkdirs();

        System.out.println("[" + times.format + "]\n" + "exit:exit事件就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: exit\n");
        new exit();

        //        引入退出类
        System.out.println("[" + times.format + "]\n" + "Exits:退出按钮事件就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: Exits\n");
        new Exits();

        System.out.println("[" + times.format + "]\n" + "ini:配置文件就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: ini\n");
        new ini();

        //        加载颜色
        System.out.println("[" + times.format + "]\n" + "colors:色彩就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: color\n");
        new colors().start();

        new filesHas().start();

        new historyReader().start();

        new Editor();

        new URLs().start();

        new countTime().start();

        new listener().start();

        new dirSize().start();
        if (Community.LangID == 0) {
            MenuUI.mchDirSize.setText("MCH文件占用: 计算中      UPD缓存: 计算中");
        } else if (Community.LangID == 1) {
            MenuUI.mchDirSize.setText("MCH File Size: counting      UPD cache: counting");
        }

        URLs.checkUPD = true;

        /*
        预加载部分
         */

//        显示UI
        System.out.println("[" + times.format + "]\n" + "MchUI:UI就绪中");
        LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadingAssemble: MchUI\n");
        if (ini.canStartUI) {
            new MchUI().start();
        } else {
            System.out.println("[" + times.format + "]\n" + "MchUI:UI无法就绪");
            LoadAssembly.loadAssembly("[" + times.format + "]\n" + "LoadFail: MchUI\n");
        }
    }
}
