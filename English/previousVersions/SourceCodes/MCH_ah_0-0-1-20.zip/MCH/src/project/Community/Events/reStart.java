package project.Community.Events;

import project.Community.Events.UPD.getJar;

import java.io.FileWriter;
import java.io.IOException;

public class reStart {

    public static void restart() {
        try {
            FileWriter f = new FileWriter("C:\\.MCH\\start.bat");
            f.write("java -Xmx100M -Xms100M -jar " + getJar.getOldPath());
            f.close();
            Runtime.getRuntime().exec("cmd.exe /k C:\\.MCH\\start.bat");
            System.exit(0);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
