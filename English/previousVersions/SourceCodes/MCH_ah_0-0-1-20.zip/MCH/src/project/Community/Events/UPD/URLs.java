package project.Community.Events.UPD;

import project.Community.Community;
import project.Community.Events.Errors;
import project.Community.Events.reStart;
import project.Community.UI.MenuUI;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;

public class URLs extends Thread {
    public static boolean UPD = false;
    public static boolean nowUPD = false;

    public static boolean checkUPD = false;

    public void run() {
        while (true) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (checkUPD) {
                UPD = checkUPD();
                checkUPD = false;
            }

            if (nowUPD) {
                UPD();
                nowUPD = false;
            }
        }
    }

    public static boolean checkUPD() {
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection conn = null;
        try {
            URL url = new URL("http://caibiwangluo.eu5.org/mch/atupdc.php");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            //发送POST请求必须设置为true
            conn.setDoOutput(true);
            conn.setDoInput(true);
            //设置连接超时时间和读取超时时间
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(10000);
            //获取输出流
            out = new OutputStreamWriter(conn.getOutputStream());
            //取得输入流，并使用Reader读取
            if (200 == conn.getResponseCode()) {
                in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                String line;
                while ((line = in.readLine()) != null) {
                    result.append(line);
                }
            } else {
                MenuUI.checkReturn.setText("ResponseCode is an error code:" + conn.getResponseCode());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
            conn.disconnect();
        }
        return !result.toString().equals(Community.verID);
    }

    public static void UPD() {
        try {

            String urlPath;
            String downloadDir;
            urlPath = "";
            downloadDir = "C:\\.MCH\\";
            String fileFullName = "UPD.cache";

            File file;
            // 统一资源
            URL url = new URL(urlPath);
            // 连接类的父类，抽象类
            URLConnection urlConnection = url.openConnection();
            // http的连接类
            HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;

            //设置超时
            httpURLConnection.setConnectTimeout(1000 * 5);

            //设置请求方式
            httpURLConnection.setRequestMethod("GET");

            // 设置字符编码
            httpURLConnection.setRequestProperty("Charset", "UTF-8");

            // 打开到此 URL引用的资源的通信链接（如果尚未建立这样的连接）
            httpURLConnection.connect();

            // 获取文件大小
            int fileLength = httpURLConnection.getContentLength();

            // 建立链接从请求中获取数据
            url.openConnection();
            BufferedInputStream bin = new BufferedInputStream(httpURLConnection.getInputStream());

            // 指定存放位置
            String path = downloadDir + File.separatorChar + fileFullName;
            file = new File(path);

            // 校验文件夹目录是否存在，不存在就创建一个目录
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }

            OutputStream out = new FileOutputStream(file);
            int size = 0;
            int len = 0;
            byte[] buf = new byte[2048];
            while ((size = bin.read(buf)) != -1) {
                len += size;
                out.write(buf, 0, size);
                // 控制台打印文件下载的百分比情况
                MenuUI.checkReturn.setText("Downloading:\n" + (float) (len) / 1024 / 1024 + "MB\n" + (float) (fileLength) / 1024 / 1024 + "MB\n" + (double) (len) / fileLength * 100 + "%");
            }
            // 关闭资源
            bin.close();
            out.close();
            MenuUI.checkReturn.setText("Download Finished");

            FileWriter fileWriter = new FileWriter(getJar.getOldPath());
            BufferedReader bufferedReader = new BufferedReader(new FileReader("C:\\.MCH\\UPD.cache"));
//            System.out.println(bufferedReader.readLine());

            String s;
            long length = 0;
            while ((s = bufferedReader.readLine()) != null) {
                length += s.length();
                MenuUI.checkReturn.setText("in transcribing\n" + length + "/" + new File(getJar.getJarName()).length());
                fileWriter.write(s);
                fileWriter.flush();
            }
            fileWriter.close();
            bufferedReader.close();

            File file1 = new File(downloadDir + fileFullName);
            file1.delete();

            reStart.restart();
        } catch (Exception e) {
            e.printStackTrace();
            Errors.errors(null,e,false,"UPD");
            MenuUI.checkReturn.setText("Download Fail :\n" + Arrays.toString(e.getStackTrace()).replace("[","").replace(",","\n    ").replace("]",""));
        }
    }
}
