package project.Community.Command.Tree.gameCommand.Selector;

import project.resources.UI.MchUI;

public class selector {
    public static void select(String Select) {
        if (Select.contains("[[") || Select.contains("!!") || Select.contains("]]")) {
            String slash = MchUI.input_Command.getText().replace("[[", "[").replace("!!", "!").replace("]]","]");
            MchUI.input_Command.setText(slash);
        }

        if (!Select.contains("]")) {

            Select.replace("[","");
//            if ()
        }
    }
}
