package project.Community;

import project.Community.Command.ini;
import project.Community.Events.Gc;
import project.Community.Events.IniHas;
import project.Community.Events.historyReader;
import project.Community.Times.times;
import project.resources.UI.Color.colors;
import project.resources.UI.MchUI;
import project.resources.UI.exit;

public class Community {

    public static int ColorID = 0;
    public static int LangID = 0;
    public static boolean exitButtonWillExit = false;
    public static boolean fastLoad = false;

    public static void main(String[] args) {
        new times().start();

        System.out.println("[" + times.format + "]\n" + "exit:exit事件就绪中");
        new exit();

        System.out.println("[" + times.format + "]\n" + "ini:配置文件就绪中");
        new ini();

        //        加载颜色
        System.out.println("[" + times.format + "]\n" + "colors:色彩就绪中");
        new colors().start();

        new IniHas().start();

        new Gc().start();

        new historyReader().start();

        /*
        预加载部分
         */

//        显示UI
        System.out.println("[" + times.format + "]\n" + "MchUI:UI就绪中");
        if (ini.canStartUI) {
            new MchUI().start();
        } else {
            System.out.println("[" + times.format + "]\n" + "MchUI:UI无法就绪");
        }
    }
}
