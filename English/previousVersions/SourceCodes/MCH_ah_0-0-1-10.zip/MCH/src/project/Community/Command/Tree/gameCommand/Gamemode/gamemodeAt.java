package project.Community.Command.Tree.gameCommand.Gamemode;

import project.Community.Command.Parsing;
import project.Community.Command.Tree.gameCommand.Selector.selector;
import project.Community.Community;
import project.resources.UI.Lang.language;

public class gamemodeAt {
    public static void gamemode_at(String At) {
        if (At.equals("") || At.equals("@")) {
            Parsing.display = "@a" + language.Ata + "\n" +
                    "@e" + language.Ate + "\n" +
                    "@p" + language.Atp + "\n" +
                    "@r" + language.Atr + "\n" +
                    "@s" + language.Ats;
        } else {
            if (!(At.indexOf("@") == 0)) {
                if (Community.LangID == 0) {
                    Parsing.display = "此处必须以\"@\"起头";
                } else if (Community.LangID == 1) {
                    Parsing.display = "You Must Start With \"@\" Here";
                }
            } else {

//                判断字符长度是否为2
                if (!At.contains(" ") & At.indexOf("[") != 1 & At.indexOf("[") != 2) {

                    boolean HasThisSelector = false;
//                因为字符梁少,所以直接全匹配了
                    if ("@a".contains(At)) {
                        Parsing.display = "@a" + language.Ata;
                        HasThisSelector = true;
                    }
                    if ("@e".contains(At)) {
                        Parsing.display = "@e" + language.Ate;
                        HasThisSelector = true;
                    }
                    if ("@p".contains(At)) {
                        Parsing.display = "@p" + language.Atp;
                        HasThisSelector = true;
                    }
                    if ("@r".contains(At)) {
                        Parsing.display = "@r" + language.Atr;
                        HasThisSelector = true;
                    }
                    if ("@s".contains(At)) {
                        Parsing.display = "@s" + language.Ats;
                        HasThisSelector = true;
                    }

                    if (!HasThisSelector) {
                        if (Community.LangID == 0) {
                            Parsing.display = "无法为\"" + At + "\"匹配到可用选择器";
                        } else if (Community.LangID == 1) {
                            Parsing.display = "Cannot matching Selector for \"" + At + "\"";
                        }
                    }

                } else {
//                    如果长度不为2,则判断是否是插入参数的符号
                    if (At.indexOf(" ") <= 3) {
                        At = At.replaceFirst(" ","");
                    }
                    if (At.substring(2).indexOf("[") == 0) {
                        if (At.contains("]")) {
                            Parsing.display = "命令已结束";

                            if (!At.substring(At.indexOf("]")).equals("") || !At.substring(At.indexOf("]")).equals(" ")) {
                                Parsing.display = At.substring(At.indexOf("]")) + "  buyunx";
                            }
                        }
                        selector.select(At);
                    } else {
//                        如果不是插入参数,则提示错误
                        Parsing.display = "此处只能选择输入参数或者结束命令";
                    }
                }
            }
        }
    }
}
