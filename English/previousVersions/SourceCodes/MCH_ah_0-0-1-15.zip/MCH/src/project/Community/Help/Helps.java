package project.Community.Help;

import javax.swing.*;
import java.awt.*;

public class Helps {
    public Helps() {
//        try {
//            String url = null;
//            if (Community.LangID == 0) {
//                url = "C:/.MCH/Helps/cn.html";
//            } else  {
//                url = "C:/.MCH/Helps/en.html";
//            }
//            URI uri = URI.create(url);
//            // 获取当前系统桌面扩展
//            Desktop dp = Desktop.getDesktop();
//            // 判断系统桌面是否支持要执行的功能
//            if (dp.isSupported(Desktop.Action.BROWSE)) {
//                dp.browse(uri);// 获取系统默认浏览器打开链接
//            }
//        } catch (NullPointerException e) {
//            // 此为uri为空时抛出异常
//            e.printStackTrace();
//        } catch (IOException e) {
//            // 此为无法获取系统默认浏览器
//            e.printStackTrace();
//        }

        JFrame jf = new JFrame();
        //获得屏幕大小
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        //设置窗口位置
        jf.setLocation(width / 2 - 500 / 2, height / 2 - 300 / 2);

        jf.setVisible(true);
    }
}
