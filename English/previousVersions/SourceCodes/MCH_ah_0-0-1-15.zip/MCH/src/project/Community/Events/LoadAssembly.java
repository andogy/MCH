package project.Community.Events;

import project.Community.Command.ini;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class LoadAssembly {

    public static void loadAssembly(String Assembly) {
        File f = new File(ini.path + "run.log");
        FileWriter fw = null;
        try {
            fw = new FileWriter(f,true);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            fw.write(Assembly);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (f.length() > 10240000) {
            try {
                FileWriter fileWriter = new FileWriter(f, false);
                fileWriter.write("");
            } catch (Exception ignored) {

            }
        }
    }
}
